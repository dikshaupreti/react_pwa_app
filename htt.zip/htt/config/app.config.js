module.exports = {
  APP_ID: 'app',
}
