// eslint-disable-next-line strict, lines-around-directive
'use strict'

// const chalk = require('chalk');
const path = require('path')

const { BuilderConfig } = require('./webpack/utils')

const webpackPlugins = require('./webpack/plugins')
const webpackOptimization = require('./webpack/optimization')
const webpackEntries = require('./webpack/entries')
const webpackOutput = require('./webpack/output')
const webpackLoaders = require('./webpack/loaders')
const webpackSourceMap = require('./webpack/sourcemap')

const configFactory = (buildTarget, fileName) => {
  const builder = new BuilderConfig(buildTarget)
  const webpackConfig = {
    target: 'web',

    devtool: webpackSourceMap(builder),

    mode: builder.env('production') ? 'production' : 'development',

    entry: {
      ...webpackEntries(builder),
    },

    output: {
      ...webpackOutput(builder),
    },

    module: {
      strictExportPresence: true,
      rules: [...webpackLoaders(builder)],
    },

    plugins: [...webpackPlugins(builder, fileName)],

    optimization: {
      ...webpackOptimization(builder),
    },

    resolve: {
      fallback: {
        buffer: require.resolve('buffer/'),
        events: require.resolve('events/'),
        string_decoder: require.resolve('string_decoder/'),
      },
      extensions: ['.csv', '.ts', '.tsx', '.js', '.json', '.jsx'],
      alias: {
        _assets: path.resolve(__dirname, '../src/app/assets/'),
        _ccl: path.resolve(__dirname, '../src/app/ccl/index'),
        _components: path.resolve(__dirname, '../src/app/components/'),
        _config: path.resolve(__dirname, '../src/app/config/'),
        _constants: path.resolve(__dirname, '../src/app/constants/'),
        _context: path.resolve(__dirname, '../src/app/context/'),
        _gql: path.resolve(__dirname, '../src/app/gql/'),
        _helpers: path.resolve(__dirname, '../src/app/helpers/'),
        _hooks: path.resolve(__dirname, '../src/app/hooks/'),
        _middleware: path.resolve(__dirname, '../src/app/middleware/'),
        _modules: path.resolve(__dirname, '../src/app/modules/'),
        _pages: path.resolve(__dirname, '../src/app/pages/'),
        _root: path.resolve(__dirname, '../src/app/root/'),
        _routes: path.resolve(__dirname, '../src/app/routes/'),
        _services: path.resolve(__dirname, '../src/app/services/'),
        _themes: path.resolve(__dirname, '../src/app/themes/'),
        _types: path.resolve(__dirname, '../src/app/types/'),
        _utils: path.resolve(__dirname, '../src/app/utils/'),
        _validations: path.resolve(__dirname, '../src/app/utils/validations'),
        _styles: path.resolve(__dirname, '../src/app/styles/'),
        _templates: path.resolve(__dirname, '../src/app/templates/'),
      },
    },

    externals: {
      appConfig: 'environmentConfiguration',
    },
  }

  return webpackConfig
}

module.exports = configFactory
