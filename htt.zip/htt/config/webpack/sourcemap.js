function webpackSourceMap(builder) {
  if (builder.target('performance')) {
    return 'source-map'
  }

  if (builder.env('production')) {
    return 'hidden-source-map'
  }

  return 'eval-source-map'
}

module.exports = webpackSourceMap
