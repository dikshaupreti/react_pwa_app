const path = require('path')

const APP_DIR = path.resolve(__dirname, '../../')
const DIST_DIR = path.resolve(APP_DIR, './build')

const rootPath = path.resolve(__dirname, '..')


module.exports = {
  _: rootPath,
  node_modules: path.resolve(rootPath, 'node_modules'),
  APP_DIR,
  DIST_DIR,
}
