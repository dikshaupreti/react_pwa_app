/* eslint-disable quotes */
/* eslint-disable import/no-extraneous-dependencies */
// eslint-disable-next-line strict, lines-around-directive
'use strict'

const path = require('path')
// const chalk = require('chalk')
const webpack = require('webpack')
const Dotenv = require('dotenv-webpack')

const HtmlWebpackPlugin = require('html-webpack-plugin')
// const CopyPlugin = require('copy-webpack-plugin')
const ReactRefreshPlugin = require('@pmmmwh/react-refresh-webpack-plugin')
const { GhostProgressPlugin } = require('ghost-progress-webpack-plugin')
const ProgressPlugin = require('progress-webpack-plugin')
const { CleanWebpackPlugin } = require('clean-webpack-plugin')
const { BundleStatsWebpackPlugin } = require('bundle-stats-webpack-plugin')
const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer')
const MiniCssExtractPlugin = require('mini-css-extract-plugin')

// const LodashModuleReplacementPlugin = require('lodash-webpack-plugin');

const { APP_ID } = require('../app.config')
const paths = require('./paths')
// const preConnectOrigins = require('../../app-config/preConnectOrigins');

const { version: componentsLibraryVersion } = require(`@idfc/ccl-web/package.json`)
const { version: cclCommonsVersion } = require(`@idfc/ccl-commons/package.json`)

const cclVersion = `commons: ${cclCommonsVersion}; web: ${componentsLibraryVersion}`

function htmlWebpackPluginOptions(builder) {
  const options = {
    template: path.resolve(paths.APP_DIR, './src/index.html'),
    favicon: path.resolve(paths.APP_DIR, './src/app/assets/favicon.ico'),

    meta: {
      'theme-color': '#9d1d27',
      'ccl-version': cclVersion,
    },

    templateParameters: {
      APP_ID,
    },

    minify: false,

    // preconnect: preConnectOrigins,
  }

  if (!builder.target('production')) {
    options.meta['build-target'] = process.env.BUILD_TARGET
  }

  if (!builder.env('development')) {
    options.minify = {
      collapseWhitespace: true,
      collapseInlineTagWhitespace: true,
      removeComments: true,
      removeRedundantAttributes: true,
      removeScriptTypeAttributes: true,
      removeStyleLinkTypeAttributes: true,
      useShortDoctype: true,
      minifyCSS: true,
      minifyJS: true,
    }
  }

  return options
}

function webpackPlugins(builder, fileName) {
  const SHOULD_GENERATE_REPORT = process.env.PERF_ANALYSIS || false
  const SHOULD_ANALYSE_BUNDLE = process.env.BUNDLE_ANALYSIS || false

  const plugins = []

  // Common plugins
  plugins.push(
    new webpack.EnvironmentPlugin(['NODE_ENV', 'BUILD_TARGET']),

    new HtmlWebpackPlugin(htmlWebpackPluginOptions(builder)),

    /* new CopyPlugin({
      patterns: [
        { from: path.resolve(paths.APP_DIR, './src/config.js'), to: paths.DIST_DIR },
      ],
    }), */

    new MiniCssExtractPlugin({
      filename: "[name].[contenthash].css",
    }),

    // new webpack.DefinePlugin(envKeys),
    new Dotenv({
      path: fileName,
    }),
  )

  // Development only plugins
  if (builder.env('development')) {
    plugins.push(
      new ReactRefreshPlugin({
        overlay: {
          sockIntegration: 'whm',
        },
      }),
      new CleanWebpackPlugin({
        cleanOnceBeforeBuildPatterns: [path.join(__dirname, "build/*")],
      }),
      new webpack.HotModuleReplacementPlugin(),
      new GhostProgressPlugin(),
    )
  }

  // Production only plugins
  if (builder.env('production')) {
    plugins.push(
      new CleanWebpackPlugin({
        cleanOnceBeforeBuildPatterns: [path.join(__dirname, "build/*")],
      }),
      new ProgressPlugin(),
    )
  }

  if (builder.target('performance') && SHOULD_GENERATE_REPORT) {
    plugins.push(
      new BundleStatsWebpackPlugin({
        outDir: '../reports',
        json: true,
        html: true,
      }),
      new BundleAnalyzerPlugin({
        analyzerMode: 'static',
        reportFilename: '../reports/bundle-analyzer-stats.html',
        openAnalyzer: false,
      }),
    )
  }

  if (builder.target('performance') && SHOULD_ANALYSE_BUNDLE) {
    plugins.push(
      new BundleAnalyzerPlugin(),
    )
  }

  return plugins
}

module.exports = webpackPlugins
