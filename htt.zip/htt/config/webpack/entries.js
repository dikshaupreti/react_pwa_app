// eslint-disable-next-line strict, lines-around-directive
'use strict'

const path = require('path')

const paths = require('./paths')

function webpackEntries(builder) {
  const entries = {}

  // Common Entries
  entries.app = [path.resolve(paths.APP_DIR, './src/index.tsx')]

  // Development only entries
  if (builder.env('development')) {
    Object.keys(entries).forEach((entryName) => {
      entries[entryName].unshift('webpack-hot-middleware/client')
    })
  }

  return entries
}

module.exports = webpackEntries
