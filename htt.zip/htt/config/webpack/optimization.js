/* eslint-disable import/no-extraneous-dependencies */
// eslint-disable-next-line strict, lines-around-directive
'use strict'

const TerserPlugin = require('terser-webpack-plugin')
const CssMinimizerPlugin = require('css-minimizer-webpack-plugin')

function webpackOptimization(builder) {
  const optimization = {}

  // Common optimization
  optimization.runtimeChunk = 'single'
  optimization.emitOnErrors = false

  // Production only optimization
  if (builder.env('production') || builder.env('development')) {
    optimization.splitChunks = {
      chunks: 'all',
      usedExports: true,
      minChunks: 5,
      minSize: 200000,
      maxSize: 244000,
      hidePathInfo: true,
    }

    optimization.concatenateModules = true
    optimization.minimize = true
    optimization.flagIncludedChunks = true
    optimization.mergeDuplicateChunks = true
    optimization.removeEmptyChunks = true
    optimization.removeAvailableModules = true

    optimization.minimizer = [
      new TerserPlugin({
        parallel: true,
        extractComments: false,
        terserOptions: {
          ecma: 5,
          mangle: true,
          ie8: false,
          safari10: false,
        },
      }),
      new CssMinimizerPlugin(),
    ]
  }

  return optimization
}

module.exports = webpackOptimization
