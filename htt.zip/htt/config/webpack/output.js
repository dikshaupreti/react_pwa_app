
// eslint-disable-next-line strict, lines-around-directive
'use strict'
const paths = require('./paths')

function webpackOutput(builder) {
  const output = {}

  output.filename = '[name].[contenthash].js'
  output.path = paths.DIST_DIR
  output.publicPath = '/'

  return output
}

module.exports = webpackOutput
