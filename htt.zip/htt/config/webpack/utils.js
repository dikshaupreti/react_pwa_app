/* eslint-disable class-methods-use-this */
/* eslint-disable no-param-reassign */
/* eslint-disable import/no-extraneous-dependencies */

// eslint-disable-next-line strict, lines-around-directive
'use strict'

const TARGETS = {
  DEV: 'development',
  PROD: 'production',
  PREPROD: 'preprod',
}

const TARGET_ENV_MAP = {
  [TARGETS.DEV]: 'development',
  [TARGETS.PROD]: 'production',
  [TARGETS.PREPROD]: 'preprod',
}

class BuilderConfig {
  #store = new Map()

  constructor(target) {
    let buildTarget = TARGETS.DEV

    if (typeof target !== 'undefined') {
      this.validateTarget(target)
      buildTarget = target
    }

    this.#store.set('target', buildTarget)
    this.#store.set('env', TARGET_ENV_MAP[buildTarget])

    process.env.NODE_ENV = TARGET_ENV_MAP[buildTarget]
    process.env.BABEL_ENV = process.env.BABEL_ENV ?? TARGET_ENV_MAP[buildTarget]
    process.env.BUILD_TARGET = buildTarget
  }

  get(prop) {
    return this.#store.get(prop)
  }

  set(prop, value) {
    return this.#store.set(prop, value)
  }

  env(value) {
    const envName = this.get('env')

    if (typeof value === 'undefined') return envName

    if (!Array.isArray(value)) value = [value]

    return value.some((entry) => entry === envName)
  }

  target(value) {
    const targetName = this.get('target')

    if (typeof value === 'undefined') return targetName

    if (!Array.isArray(value)) value = [value]

    return value.some((entry) => entry === targetName)
  }

  validateTarget(buildTarget) {
    const VALID_BUILD_TARGETS = Object.values(TARGETS)

    if (!VALID_BUILD_TARGETS.some((target) => target === buildTarget)) {
      process.exit(1)
    }
  }
}

module.exports = {
  BuilderConfig,
}
