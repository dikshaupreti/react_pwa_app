// eslint-disable-next-line strict, lines-around-directive
'use strict'

const path = require('path')
// eslint-disable-next-line import/no-extraneous-dependencies
const MiniCssExtractPlugin = require('mini-css-extract-plugin')
const paths = require('./paths')

const configFile = path.resolve(paths.APP_DIR, 'tsconfig.json')
const tsOptions = {
  configFile,
  transpileOnly: true,
  happyPackMode: true,
  // NOTE: TYPESCRIPT WARNINGS aren't disabled by the next 2 lines
  // because they are logged through webpack
  // silent: true,
  // logLevel: 'error',
}
// eslint-disable-next-line camelcase
const Lib_CCLCommons_Path = path.dirname(require.resolve('@idfc/ccl-commons'))

function webpackLoaders(builder) {
  const rules = []

  // JS source files, and few es modules; excluding test files
  rules.push({
    test: /\.js$/,
    exclude: [
      /node_modules\/(?!(react-hook-form|uuidv4|swiper|dom7|@idfc)\/).*/,
      /\.test\.js$/,
    ],
    use: {
      loader: 'babel-loader',
      options: {
        cacheDirectory: true,
        cacheCompression: false,
      },
    },
  })
  rules.push({
    test: /\.tsx?$/,
    use: [
      {
        loader: 'babel-loader',
        options: {
          babelrc: true,
        },
      },
      {
        loader: 'ts-loader',
        options: tsOptions,
      },
    ],
  })

  // CSS files
  const cssLoaders = ['css-loader']
  if (builder.env('production')) {
    cssLoaders.unshift(MiniCssExtractPlugin.loader)
  } else {
    cssLoaders.unshift('style-loader')
  }

  rules.push({
    test: /\.css$/,
    use: cssLoaders,
  })

  // SVG Icons
  rules.push({
    test: /\.svg$/,
    include: [path.resolve(Lib_CCLCommons_Path, './assets/icons/')],
    use: [
      {
        loader: '@svgr/webpack',
        options: {
          configFile: 'svgr.icon.config.js',
        },
      },
    ],
  })

  // SVG Logos
  rules.push({
    test: /\.svg$/,
    include: [
      path.resolve(Lib_CCLCommons_Path, './assets/logos'),
      path.resolve(Lib_CCLCommons_Path, './assets/composed-icons'),
    ],
    use: [
      {
        loader: '@svgr/webpack',
        options: {
          configFile: 'svgr.config.js',
        },
      },
    ],
  })

  // SVGs
  rules.push({
    test: /\.svg$/,
    exclude: [
      path.resolve(Lib_CCLCommons_Path, './assets/icons'),
      path.resolve(Lib_CCLCommons_Path, './assets/logos'),
      path.resolve(Lib_CCLCommons_Path, './assets/composed-icons'),
    ],
    include: [
      path.resolve(paths.APP_DIR, './src'),
      path.resolve(Lib_CCLCommons_Path, './assets/images'),
      path.resolve(Lib_CCLCommons_Path, './assets/patterns'),
    ],
    type: 'asset/resource',
  })

  // Font files
  rules.push({
    test: /\.(woff|woff2)$/,
    type: 'asset/resource',
    generator: {
      filename: 'fonts/[name][ext]',
    },
  })

  // GIFs
  rules.push({
    test: /\.(gif|webp)$/,
    include: [path.resolve(Lib_CCLCommons_Path, './assets')],
    type: 'asset/resource',
  })

  // Other Static files
  rules.push({
    test: /\.(png|jpg|xlsx|mp4)$/,
    type: 'asset/resource',
  })

  return rules
}

module.exports = webpackLoaders
