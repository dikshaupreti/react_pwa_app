let watchPlugins = []
let collectCoverage = true
let testResultsProcessor = null

const coverageThreshold = {
  global: {
    branches: 80,
    functions: 80,
    lines: 80,
    statements: 80,
  },
}

if (process.env.JEST_TDD) {
  watchPlugins = [
    'jest-watch-master',
    'jest-watch-typeahead/filename',
    'jest-watch-typeahead/testname',
  ]

  collectCoverage = false
}

if (process.env.CI) {
  testResultsProcessor = require.resolve('jest-stare')
}

const jestConfig = {
  rootDir: '../',
  testEnvironment: 'jsdom',
  displayName: 'WEB',

  bail: 0,
  cache: true,
  collectCoverage,
  coverageThreshold,
  errorOnDeprecated: true,
  noStackTrace: true,
  collectCoverageFrom: [
    'src/app/components/**/*.{ts,tsx}',
    'src/app/hooks/**/*.{ts,tsx}',
    'src/app/pages/**/*.{ts,tsx}',
    '!**/node_modules/**',
    '!**/modules/**',
    '!src/components/**/index.js',
    '!<rootDir>/src/**/mocks/**'
  ],
  globals: {
    __DEV__: false
  },
  globalSetup: '<rootDir>/tests/jest.global.setup.js',
  setupFilesAfterEnv: ['<rootDir>/tests/jest.setup.js'],
  testTimeout: 30000,
  moduleNameMapper: {
    '\\.(s?css|less)$': 'identity-obj-proxy', // mock css
    '^styled-components': require.resolve(
      'styled-components/dist/styled-components.browser.cjs.js'
    ),
    '^_assets/(.*)': '<rootDir>/src/app/assets/$1',
    '^_ccl': '<rootDir>/src/app/ccl/index',
    '^_components/(.*)': '<rootDir>/src/app/components/$1',
    '^_config/(.*)': '<rootDir>/src/app/config/$1',
    '^_constants/(.*)': '<rootDir>/src/app/constants/$1',
    '^_context/(.*)': '<rootDir>/src/app/context/$1',
    '^_helpers/(.*)': '<rootDir>/src/app/helpers/$1',
    '^_hooks/(.*)': '<rootDir>/src/app/hooks/$1',
    '^_jest(.*)$': '<rootDir>/src/app/jest/$1',
    '^_middleware/(.*)': '<rootDir>/src/app/middleware/$1',
    '^_modules/(.*)': '<rootDir>/src/app/modules/$1',
    '^_pages/(.*)': '<rootDir>/src/app/pages/$1',
    '^_gql/(.*)': '<rootDir>/src/app/gql/$1',
    '^_root/(.*)': '<rootDir>/src/app/root/$1',
    '^_routes/(.*)': '<rootDir>/src/app/routes/$1',
    '^_services/(.*)': '<rootDir>/src/app/services/$1',
    '^_themes/(.*)': '<rootDir>/src/app/themes/$1',
    '^_types/(.*)': '<rootDir>/src/app/types/$1',
    '^_utils/(.*)': '<rootDir>/src/app/utils/$1',
    '^_validations': '<rootDir>/src/app/utils/validations',
    '^_styles/(.*)': '<rootDir>/src/app/styles/$1',
    '^_templates/(.*)': '<rootDir>/src/app/templates/$1',
    'react-pdf/dist/esm/entry.webpack5': 'react-pdf'
  },
  testPathIgnorePatterns: [
    '/node_modules/',
    '/modules/',
    '<rootDir>/src/constants/'
  ],
  testResultsProcessor,

  transform: {
    '^.+\\.js$': 'babel-jest',
    '\\.(png|jpg|jpeg|gif|xlsx|woff|woff2|mp4|webp)$':
      '<rootDir>/tests/fileTransformer.js',
    '\\.svg$': '<rootDir>/tests/svgTransformer.js',
    '^.+\\.tsx?$': 'ts-jest'
  },
  testRegex: '(/__tests__/.*|(\\.|/)(test|spec))\\.(jsx?|tsx?)$',
  moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx', 'json', 'node'],
  transformIgnorePatterns: [
    '/node_modules/(?!(@idfc|lodash-es|@react-dnd|react-dnd|dnd-core|react-dnd-html5-backend)/)',
    '\\.pnp\\.[^\\/]+$'
  ],
  watchPathIgnorePatterns: ['.*jest-stare.*\\.js'],
  watchPlugins
}

module.exports = jestConfig
