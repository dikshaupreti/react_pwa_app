# Getting Started with URL Shortener App

## Available Scripts

In the project directory, you can run:

### `yarn install`

### `yarn start`

Runs the app in the development mode.
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

### `yarn test`

Launches the test runner in the interactive watch mode.

### `yarn build`

Builds the app for production to the `build` folder.

# Folder Structure

```text
src
  └── app
      ├──  assets
      ├──  ccl (Common Component Library)
      ├──  components
      ├──  config
      ├──  helpers
      ├──  middleware
      ├──  pages
      ├──  routes
      ├──  services
      ├──  themes
      └──  utils
```

## assets

assets folder mostly consist of images(.png,.svg..) and any other static files that might be needed.

## ccl

ccl consist of file file imports from ccl. This folder doesn't have any logic. This helps having a single place for all the imports from ccl and not to be scattered around in components.

## config

config consist of file containing the api endpoints. This folder doesn't have any logic. This helps having a single place for all api url end points and not to be scattered around in components, mostly inside useEffects.

## pages

1. Contains Page Components. Each Page Component is associated with a route.
2. Page Components compose the content of a page by importing Components and Feature Components.
3. A Page Component should rarely include side-effects, and should instead delegate side-effects to Feature Components.

---

## Guidelines

## Names

1.  Use PascalCase for type names.
2.  Use PascalCase for enum values.
3.  Use camelCase for function names.
4.  Use camelCase for property names and local variables.
5.  Do not use "\_" as a prefix for private properties.
6.  Use whole words in names when possible.
7.  Use `isXXXing` or `hasXXXXed` for variables representing states of things (e.g. `isLoading`, `hasCompletedOnboarding`).
8.  Give folders/files/components/functions unique names.

## Exports

1.  Only use named exports. The only exceptions are a tool requires default exports (e.g `React.lazy()`)

### TSX File Names
TSX File names should be PascalCase. It’s best to have a standard for file naming to keep folders easy to read.

Do:

```
MyFile.tsx
```
Don’t:

```
myFile.tsx
my-file.tsx
my_file.tsx
My_File.tsx
```

### useState Naming
useState variables should have descriptive names, with the update function name being set + {variable name}

Do:

``` const [name, setName] = useState("") ```

Don’t:

``` const [name, updateName] = useState("") ```

## When to use `any`

1.  If something takes you longer than 10 minutes to type or you feel the need to read through TS Advanced Types docs, you should take a step back and ask for help, or use `unknown`.
2.  Custom typings of 3rd-party modules should be added to a `.d.ts` file in a `typings` directory. Document the date and version of the module you are typing at the top of the file.
3.  Consider rewriting tiny modules in typescript if types are too hard to think through.
4.  Use `unknown`

### Equality Operators
When comparing two values, always use === . In JavaScript, ==performs type coercion which can lead to very odd bugs. For example: 1 == “1”will equate to true.

Do:
```
if (var1 === var2) {}
```
Don’t:
```
if (var1 == var2) {}
```

### Component Property Interfaces
When defining interfaces for component properties, always define variables first and functions second, separated by a space.

Do:

```
interface IProps {
  var1: string
  var2: boolean
 
  function1(): void
}
const MyComponent: React.FunctionComponent = (props: IProps) => {}
```
Don’t:
```
interface IProps { 
  var1: string
  function1(): void
  var2: boolean
}
const MyComponent: React.FunctionComponent = (props: IProps) => {}
```

Below are code patterns that we should follow, and always discuss if there are exceptions that needs to be implemented.


1)Do not use ternary unless absolutely necessary. No nested ternary
2)Avoid Anonymous functions inside render/return as much as possible
3)Do not try to sync props with internal state - if really necessary use prop as deafult for internal state
4)No if blocks and value assignments inside components unless necessary. Use functions instead
5)Use minimal `div`. This is mostly for the code readability and can have minor performance hit in a complex screen with multiple complex components.
6)Primitive components should not be connected to the store
7)Use optional chaining, array destructuring & null coalescing everywhere
8)No commented code & console logs in commits
9)Don't use logic inside render/return to render jsx. Move it to a function outside the return
10)Use state should be at a max of 2-3 inside a particular comp. If you need more, consider using a object rather than individual state value. Also, look into using useReducer.
11)Use hide prop rather than using {someCondtion && <Component>}
12)Write TODO where implementation is not complete / Needs refactoring / needs styling change / is hack / not sure of implementation

### Conditional Rendering
When using a shorthand method for conditional rendering, use a full ternary operator, rather than the logical &&. It’s rare, but the local && operator can return odd values in jsx when certain conditions are met.

Do:
```
const MyComponent: React.FunctionComponent = () => {
  const authenticated = true
  return (
    <div>
      {authenticated ? <p> You're Logged In </p> : null}
    </div>
  )
}
```
Don’t:
```
const MyComponent: React.FunctionComponent = () => {
  const authenticated = true
    return (
      <div>
        {authenticated && <p> You're Logged In </p>}
      </div>
    )
}
```

### Functional Component Declaration
I prefer const declarations for their succinct nature. Always include the FunctionComponent type to gain access to properties like children

Do:
```
const MyComponent: React.FunctionComponent = () => {}
```
Don’t:
```
const MyComponent = () => {}
function MyComponent() {}
```

### Named Exports
Named exports should be used when a component is part of a component library or any other configuration with many similar exports.
```
export const MyComponent1: React.FunctionComponent = () => {}
export const MyComponent2: React.FunctionComponent = () => {}
```
### Default Exports

Default exports should be used when a component is used once, or if a file has one export that is not bundled with the rest of a directory.
```
const MyComponent: React.FunctionComponent = () => {}
export default MyComponent
```
## Style

0.  Use prettier and eslint.
1.  Use arrow functions over anonymous function expressions.
1.  Only surround arrow function parameters when necessary. <br />For example, `(x) => x + x` is wrong but the following are correct:
    1.  `x => x + x`
    2.  `(x,y) => x + y`
    3.  `<T>(x: T, y: T) => x === y`
1.  Always surround loop and conditional bodies with curly braces. Statements on the same line are allowed to omit braces.
1.  Open curly braces always go on the same line as whatever necessitates them.
1.  Parenthesized constructs should have no surrounding whitespace. <br />A single space follows commas, colons, and semicolons in those constructs. For example:
    1.  `for (var i = 0, n = str.length; i < 10; i++) { }`
    2.  `if (x < 10) { }`
    3.  `function f(x: number, y: string): void { }`
1.  Use a single declaration per variable statement <br />(i.e. use `var x = 1; var y = 2;` over `var x = 1, y = 2;`).
1.  Use 2 spaces per indentation.

## formatOnSave
update your Workspace settings by adding the following to your .vscode/settings.json:
```
{
    "editor.formatOnSave": true
}
```
This will allow VS Code to work its magic and fix your code when you save. It’s beautiful!


## Redux Usage

In our application we have used `@reduxjs/toolkit` latest version

1. First provide the store to entire application in index file like this below
  <Provider store={store}>
    <Root />
  </Provider>
2. Add all the applicaiton reducers into reduxjs combineReducer
  `const rootReducer = combineReducers({`
    `......`
    `})`
3. Configure all the reducer and middleware into configureStore
  `export const store = configureStore({`
    `reducer: rootReducer,`
    `middleware,`
    `})`

4. Write the reducer with create slice method, this is enough for all the actions/reducers (actionTypes, actions, reducers not required)
  create the method with name and initial State values
  reducers and extra reducers are optional
  eg: `export const customerSearchResults = createSlice({})`

5. If you want to use any API call use createAsyncThunk and give the api fetch URL
  eg: `export const getDetail = createAsyncThunk('customerSearchResults/getDetail')........,`

6. From component for trigger the actions first import the required states
  `import { AppDispatch, AppState } from '@store/store';`

7. Using Hooks declare the dispatch event
  `const dispatch: AppDispatch = useDispatch();`

8. Import the Reducer method and then Call the Reducers method using dispatch event with needed arguments
  `import { getDetail } from '@store/reducers/customer/searchReducers';`
  `dispatch(getDetail({client, accountNumber, mobileNumber, panNumber}))`

9. Once received API data automatically store values will get update based the api staus (fulfilled, pending, rejected)

10. If you want to get the store value in same component or some other component import the useSelector and use it
  `const customerDetails = useSelector((stateValue: AppState) => stateValue.customers.customers);`

11. If api got success Dispaly the result or else display the error message based on the api status
  `const postStatus = useSelector((stateValue: AppState) => stateValue?.customers?.status)`




  Converting Base64 to PDF

   There are three approaches which looks good and fit for use case

  Approach 1:
      const base64 = ""
      const base64Val = `data:application/pdf;base64,${base64}`
      const base64toBlob = async (data: string) => {
        const base64Conversion = await fetch(data)
        const blob = await base64Conversion.blob()
        return new Blob([blob], { type: pdfContentType })
      }
      const [url, setUrl] = useState('')
      useEffect(() => {
        base64toBlob(base264).then((res) => {
          const pUrl = URL.createObjectURL(res)
          setUrl(pUrl)
        })
      }, [])

 Approach 2:
  const base64 = ""
  const base64Val = `data:application/pdf;base64,${base64}`
  const base64toBlob = async (data: string) => {
    const base64WithoutPrefix = data.substr(
      `data:${pdfContentType};base64,`.length
    )

    const bytes = window.atob(base64WithoutPrefix)
    let { length } = bytes
    const out = new Uint8Array(length)
    while (length--) {
      out[length] = bytes.charCodeAt(length)
    }
    return new Blob([out], { type: pdfContentType })
  }
  const [url, setUrl] = useState('')
  const url = base64toBlob(base64Val)

Approach 3:
    const base64 = ""
    const base64Val = `data:application/pdf;base64,${base64}`
    <ViewFile
        file={base64Val}
        title={Agreement.document.title}
        subtitle={Agreement.document.subTitle}
        hide={!isModalOpen}
        hideViewModel={() => setIsModalOpen(false)}
      />  
       <Button buttonType="secondary" href={base64Val} download>
          <img alt="" src={pdf} />
          {' '}
          {CUSTOMERDOCUMENTS.DOWNLOAD}
        </Button>
