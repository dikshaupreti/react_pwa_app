Features	Google Analytics or	Adobe Analytics 	
			
			
Pricing:
 	- Google Analytics - Free of cost 
        A site with higher web traffic needs to upgrade to the premium version of Google Analytics 360, which costs a hefty sum of $150,000.	
    - Adobe Analytics - Paid tool more than $100,000 a year or $500 per month. 	
			
Usage: 	
    - 53% of the applications used
    - 0.20%	of the applications used
			
User friendly: 	
    - Quite easy to install and activate on your site, making the implementation process relaxed and useful for users.	
    - Adobe Analytics is reasonably harder to use and needs a command in programming and expertise	
			
Customization: 	
    - Google Analytics 360 offers a lot of customization	
    - Adobe also uses a system similar to Google Analytics with Adobe Data Warehouse	
			
Integration: 	
    - Google Analytics can merge with Google Ads, Adsense, Ad Manager, Ad Exchange, and many others. 	
    - Adobe Analytics Integrations are Adobe Experience Manager, Adobe Campaign, and Data Connectors.	
			
Goal tracking:  	
    - can track only four goals. 	
    - can track hundreds of goals simultaneously	
			
Advantages: 	
    - Google Analytics is the strongest when it comes to multi-channel attribution	
        Works on a real-time basis.
        Support for real-time business decisions
        Structured business reporting tools
    - Adobe Analytics for its vigorous user pathing and reporting.	
        eCommerce tracking is much better in Adobe Analytics
        Can track over 100 goals
        Access to personal visitor data
        	
			
disadvantages: 
	- Does not capture such personal information.
        reports should be treated as approximations.	
	 Google Analytics provides it for 24 months only	

    - Adobe Analytics does provide businesses with customer lifetime data storage
        provides businesses with visitors’ data like email address
			
			
			
			
			
References:

https://blog.saeloun.com/2022/02/17/how-to-integrate-react-app-with-google-analytics.html

https://medium.datadriveninvestor.com/comparing-google-analytics-vs-adobe-analytics-vs-ibm-coremetrics-for-web-analytics-6d97415566d8

			
			
			
			
