
# Webpack Bundle Analyzer

### Steps to generate web analyze report

```
    1.  
        # NPM
        npm install --save-dev webpack-bundle-analyzer
        # Yarn
        yarn add -D webpack-bundle-analyzer

    2. 	Add a --stats flag at the end of "build" script in package.json [step 3]
    3.
        "scripts": {
                "build": "react-scripts build --stats"
        }
```

### Usage (as a plugin)
    In `webpack.config.js` declare:

```
   const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;

    module.exports = {
        plugins: [
            new BundleAnalyzerPlugin()
        ]
    }

```
### Run and check output 

```
   run npm run build or yarn build

```

### It will create an interactive tree map visualization of the contents of all your bundles
<br />

![tree-map-view-image](https://cloud.githubusercontent.com/assets/302213/20628702/93f72404-b338-11e6-92d4-9a365550a701.gif)

<br />

### We observed there total size of bundle is 42.32MB 
<br />

 There are couple of fix we found and try to reduce bundle size

1.	To update existing lib version

```
    eg. react/pdf to 

    Current version react/pdf@5.7.2 : 435.5kB

    New version react/pdf@6.2.2  : 312.4kB

```

2. We can make changes in dev-tool setting in web-config-dev file

``` 
    devtool: 'inline-source-map'

    to

    devtool: 'source-map'

```

3. We try to update existing ccl lib 

```
   eg. @idfc/ccl-web @idfc/ui-commons @idfc/ccl-commons

    But we get bundle error, we don't find exact fix for this at this moment

```

