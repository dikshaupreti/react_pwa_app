module.exports = {
  sourceType: 'unambiguous',
  presets: [
    ['@babel/preset-env', {
      useBuiltIns: 'usage',
      corejs: {
        version: 3,
        proposals: true,
      },

    }],
    '@babel/preset-react',
    '@babel/preset-typescript',
  ],
  plugins: [
    ['@babel/plugin-proposal-decorators', { legacy: true }],
    '@babel/plugin-proposal-class-properties',
    '@babel/plugin-proposal-object-rest-spread',
    '@babel/plugin-proposal-nullish-coalescing-operator',
    '@babel/plugin-proposal-optional-chaining',
    '@babel/plugin-proposal-export-default-from',
    'jsx-control-statements',
    ['babel-plugin-styled-components',
      {
        ssr: false, displayName: false, pure: true,
      }],
    ['babel-plugin-module-resolver', {
      root: ['./src/'],
      alias: {
        tests: './tests/',
        config: './config/',
        app: './src/app',
      },
    }],
  ],
  env: {
    development: {
      plugins: ['react-refresh/babel', ['babel-plugin-styled-components', { ssr: false, displayName: true }]],
    },
    test: {
      plugins: [
        '@babel/plugin-transform-modules-commonjs',
      ],
    },
    production: {
      plugins: ['transform-remove-console', 'transform-react-remove-prop-types'],
    },
  },
};
