/* eslint-disable import/no-extraneous-dependencies */
// eslint-disable-next-line strict, lines-around-directive
'use strict'

const webpack = require('webpack')

const configFactory = require('../config/webpack.config.dev')

const buildTarget = 'development'

const fileName = process.env.NODE_ENV

const config = configFactory(buildTarget, fileName)

let compiler

const callback = (error, stats) => {
  if (error) {
    process.exit(1)
  }

  const statsOptions = compiler?.options.stats
  statsOptions.colors = true

  if (stats.hasErrors()) {
    process.exit(1)
  }
}

try {
  compiler = webpack(config, callback)
} catch (error) {
  process.exit(2)
}
