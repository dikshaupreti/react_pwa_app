/* eslint-disable consistent-return */
/* eslint-disable import/no-extraneous-dependencies */
// eslint-disable-next-line strict, lines-around-directive
'use strict'

const path = require('path')
const express = require('express')
const webpack = require('webpack')
const webpackDevMiddleware = require('webpack-dev-middleware')
const webpackHotMiddleware = require('webpack-hot-middleware')

const { printBanner } = require('./script-helper')

const configFactory = require('../config/webpack.config')

printBanner()

const file = process.env.NODE_ENV ?? '.env'

const config = configFactory('development', file)
const app = express()
const compiler = webpack(config)

const DEV_PORT = process.env.DEV_PORT ?? '3000'
const DEV_HOST = process.env.DEV_HOST ?? 'localhost'

app.use(
  webpackDevMiddleware(compiler, {
    publicPath: config.output.publicPath,
  }),
)

app.use(webpackHotMiddleware(compiler, {
  log: false,
  path: '/__webpack_hmr',
  heartbeat: 10 * 1000,
}))


app.use('*', (req, res, next) => {
  if (req.method !== 'GET') {
    return next()
  }

  const indexFilePath = path.join(compiler.outputPath, './index.html')
  compiler.outputFileSystem.readFile(indexFilePath, (err, result) => {
    res.set('content-type', 'text/html')
    res.set('Access-Control-Allow-Origin', '*')
    res.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS')
    res.set('Access-Control-Allow-Headers', 'X-Requested-With, content-type, Authorization')

    if (err) {
      res.send(`<meta http-equiv="refresh" content="1">
        <h1 style="line-height: 100vh; text-align: center;">Hold your horses! Still bundling the files…</h1>`)
    } else {
      res.send(result)
    }

    res.end()
  })
})

const devServer = app.listen(DEV_PORT, DEV_HOST, (err) => {
  if (err) {
    throw err
  }
})

devServer.on('error', (e) => {
  if (e.code === 'EADDRINUSE') {
    process.exit(1)
  }
})

function shutDown() {
  devServer.close()

  process.exit()
}

process.on('SIGTERM', shutDown)
process.on('SIGINT', shutDown)
