/* eslint-disable import/no-extraneous-dependencies */
// eslint-disable-next-line strict, lines-around-directive
'use strict';

const fs = require('fs');
const path = require('path');

const chalk = require('chalk');
const clear = require('console-clear');

const BANNERS = {
  large: {
    IDFC: `
    ─────────────────────────────────────────────────────────
    ─██████████─████████████───██████████████─██████████████─
    ─██░░░░░░██─██░░░░░░░░████─██░░░░░░░░░░██─██░░░░░░░░░░██─
    ─████░░████─██░░████░░░░██─██░░██████████─██░░██████████─
    ───██░░██───██░░██──██░░██─██░░██─────────██░░██─────────
    ───██░░██───██░░██──██░░██─██░░██████████─██░░██─────────
    ───██░░██───██░░██──██░░██─██░░░░░░░░░░██─██░░██─────────
    ───██░░██───██░░██──██░░██─██░░██████████─██░░██─────────
    ───██░░██───██░░██──██░░██─██░░██─────────██░░██─────────
    ─████░░████─██░░████░░░░██─██░░██─────────██░░██████████─
    ─██░░░░░░██─██░░░░░░░░████─██░░██─────────██░░░░░░░░░░██─
    ─██████████─████████████───██████─────────██████████████─
    ─────────────────────────────────────────────────────────
    `,
    TM: `
    ▀▀█▀▀ ░█▀▄▀█
    ─░█── ░█░█░█
    ─░█── ░█──░█
    `,
  },
  regular: {
    IDFC: `
    ▀█▀ ░█▀▀▄ ░█▀▀▀ ░█▀▀█
    ░█─ ░█─░█ ░█▀▀▀ ░█───
    ▄█▄ ░█▄▄▀ ░█─── ░█▄▄█
    `,
    TM: `
    ▀█▀ █▀▄▀█
    ░█░ █░▀░█ 
    `,
  },
};

const REPORT_DIR = path.resolve('./reports');

function isTTY() {
  return process.stdout.isTTY;
}

function printBanner(size = 'regular') {
  if (isTTY() && (size in BANNERS)) {
    clear(true);
  }
}

function writeReport(fileName, data) {
  const outputFilePath = path.resolve(REPORT_DIR, fileName);

  fs.writeFileSync(outputFilePath, data);
}

module.exports = {
  printBanner,
  writeReport,
  isTTY,
};
