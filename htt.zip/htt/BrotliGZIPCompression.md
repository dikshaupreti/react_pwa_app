# Enabling Brotli and GZIP Compression to reduce bundle size

## Getting the required packages:
Add `compression-webpack-plugin` for GZIP compression and `brotli-webpack-plugin` for Brotli compression by running command `yarn add -D compression-webpack-plugin && yarn add -D brotli-webpack-plugin`

## Enable compression of files:
In `webpack.config.js` declare:

```
    const CompressionPlugin = require('compression-webpack-plugin')
    const BrotliPlugin = require('brotli-webpack-plugin')
```

Add the following to `plugins` defined in `configFactory`:

```
    new CompressionPlugin(),
    new BrotliPlugin({
        asset: '[path][query].br',
        test: /\.(js|css|html|svg|ts|tsx|webp|gif|png|map)$/,
        threshold: 256,
        minRatio: 0.7,
        deleteOriginalAssets: true
    })
```

Based on this plugin configuration, for each source file in `/build` `CompressionPlugin` will generate a `.gz` file and `BrotliPlugin` will generate a `.br` file for files that are greater than 256 bytes and have a minimum Compression Ratio of 0.7

## Serving the files(not verified)

### Using expressStaticGzip:
Add `express-static-gzip` for serving using command `yarn add -D express-static-gzip`
Include the package import: `const expressStaticGzip = require('express-static-gzip')`
Use the module:
```
    app.use('/build', expressStaticGzip('/build', {
        enableBrotli: true,
        orderPreference: ['br', 'gz'],
        setHeaders: (res) => {
            res.setHeader('Cache-Control', 'public, max-age=31536000')
        }
    }))
```

### By modifying nginx configuration:
Add the following code snippet to nginx server configuration:
```
    server {
        gzip on;
        gzip_static on;    
        gzip_types text/plain text/css application/json application/x-javascript text/xml application/xml application/xml+rss text/javascript;
        gzip_proxied  any;
        gzip_vary on;
        gzip_comp_level 9;
        gzip_buffers 16 8k;
        gzip_http_version 1.1; 

        brotli on;
        brotli_static on;    
        brotli_types text/plain text/css application/json application/x-javascript text/xml application/xml application/xml+rss text/javascript;
        brotli_comp_level 11;
        ...
    }
```