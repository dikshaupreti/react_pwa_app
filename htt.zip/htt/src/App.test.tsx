import React from 'react';
import { render, screen } from '@testing-library/react';
import App from './App';

test('renders prompt to user', () => {
  // render(<App />);
  /* const pElement = screen.findAllByText('')
  expect(pElement).toBeInTheDocument(); */
})
