/* eslint-disable import/no-unresolved */
// eslint-disable-next-line import/no-unresolved
import React, { lazy } from 'react'
import {
  BrowserRouter as Router
} from 'react-router-dom'
import { RoutesComp as Routes } from '_routes/Routes'

const BasePresentationLayer = lazy(() => import('_components/BasePresentationLayer'))
export default function App() {
  return (
    <BasePresentationLayer>
      <Router>
        <Routes />
      </Router>
    </BasePresentationLayer>
  )
}
