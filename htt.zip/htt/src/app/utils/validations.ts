import * as Yup from 'yup'
import { Regex } from '_ccl'
import { ACCOUNT_NO_MAX_LENGTH } from '_constants/constants'
import { VALIDATION } from '_constants/Validations/constants'

enum VALIDATION_TYPE {
  REQUIRED = 'required',
  PATTERN = 'pattern',
  MIN = 'min',
  MAX = 'max'

}

const REQUIRED = Yup.string().trim().required(VALIDATION.REQUIRED)

const PAN = Yup.string().matches(Regex.PAN, VALIDATION.PAN)

const MOBILE_NUMBER = Yup.string()
  .required(VALIDATION.REQUIRED)
  .min(8, VALIDATION.PHONE)
  .max(12, VALIDATION.PHONE)
  .matches(/^[0-9]*$/, VALIDATION.PHONE)

const MOBILE_NUMBER_LENGTH = Yup.string()
  .min(8, VALIDATION.PHONE)
  .matches(/^[0-9]*$/, VALIDATION.PHONE)

const MOBILE_NUMBER_LENGTH_AND_REQUIRED = Yup.string()
  .required(VALIDATION.REQUIRED)
  .min(10, VALIDATION.PHONE)
  .matches(/^[0-9]*$/, VALIDATION.PHONE)


const EMAIL = Yup.string().matches(Regex.EMAIL, VALIDATION.EMAIL)

const URL = Yup.string().matches(Regex.URL, VALIDATION.URL)

const NUMBER = Yup.string()
  .required(VALIDATION.REQUIRED)
  .min(1, VALIDATION.NUMBER_MIN)
  .matches(/^[0-9]*$/, VALIDATION.NUMBER)

const ACCOUNT_NUMBER = Yup.string()
  .min(ACCOUNT_NO_MAX_LENGTH, VALIDATION.ACCOUNT_NUMBER)
  .matches(/^[0-9]*$/, VALIDATION.ACCOUNT_NUMBER)

const CRN_NUMBER = Yup.string()
  .min(10, VALIDATION.CRN_NUMBER)
  .matches(/^[0-9]*$/, VALIDATION.CRN_NUMBER)

const ALPHABETIC = Yup.string()
  .min(4, VALIDATION.NAME)
  .matches(/^[a-zA-Z ]*$/, VALIDATION.NAME)

const ALPHABETIC_AND_REQUIRED = Yup.string()
  .required(VALIDATION.REQUIRED)
  .min(4, VALIDATION.NAME)
  .matches(/^[a-zA-Z ]*$/, VALIDATION.NAME)

const PASSPORT = Yup.string().matches(
  /^[A-PR-WYa-pr-wy][1-9]\d\s?\d{4}[1-9]$/,
  VALIDATION.PASSPORT
)


const REQUEST_ID = /^OPSREQ[a-zA-Z0-9]{9,15}$/
const CUSTOMER_NAME = /^([a-zA-Z]*)$/
const CRN = /^[0-9]{10}$/
const LAN = /^[0-9]{10}$/
const BATCH_ID = /^OPSBID[a-zA-Z0-9 ]{9,15}$/
const ALPHA_NUMERIC = /^([a-zA-Z0-9 ]*)$/
const NUMERIC = /^([0-9]*)$/
const ALPHA_NUMERIC_AND_MAXLENGTH = /^([a-zA-Z0-9 ]{1,15})$/
const CRN_AND_MAX_LENGHT = /^[0-9]{0,10}$/
const LAN_AND_MAX_LENGTH = /^[0-9]{0,12}$/
const ALPHABETS = /^([a-zA-Z ]*)$/

export {
  VALIDATION_TYPE,
  REQUIRED,
  PAN,
  MOBILE_NUMBER,
  MOBILE_NUMBER_LENGTH,
  EMAIL,
  URL,
  NUMBER,
  ACCOUNT_NUMBER,
  CRN_NUMBER,
  ALPHABETIC,
  PASSPORT,
  ALPHABETIC_AND_REQUIRED,
  REQUEST_ID, CUSTOMER_NAME, CRN, LAN, BATCH_ID, ALPHA_NUMERIC,
  NUMERIC, ALPHA_NUMERIC_AND_MAXLENGTH, CRN_AND_MAX_LENGHT, LAN_AND_MAX_LENGTH, ALPHABETS,
  MOBILE_NUMBER_LENGTH_AND_REQUIRED
}

