/* eslint-disable no-unused-vars */
/* eslint-disable no-undef */
// tslint:disable-next-line:no-any
export const debounce = (timeOut: number, callBack: (...callbackArguments: any[]) => void) => {
  let timeOutRef: NodeJS.Timeout
  // tslint:disable-next-line:no-any
  return (...callbackArguments: any[]) => {
    clearTimeout(timeOutRef)
    timeOutRef = setTimeout(() => {
      callBack(...callbackArguments)
    }, timeOut)
  }
}

export const asyncTimeout = (asyncCallback: () => void, ms: number) => {
  setTimeout(() => {
    (async () => {
      await asyncCallback()
    })()
  }, ms)
}

// tslint:disable-next-line:no-any
export const asyncDebounce = (timeOut: number, callBack: (...callbackArguments: any[]) => void) => {
  let timeOutRef: NodeJS.Timeout
  // tslint:disable-next-line:no-any
  return (...callbackArguments: any[]) => {
    clearTimeout(timeOutRef)
    timeOutRef = setTimeout(() => {
      const cb = async () => {
        await callBack(...callbackArguments)
      }
      cb()
    }, timeOut)
  }
}
