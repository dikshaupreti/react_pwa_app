import { v4 as uuidv4 } from 'uuid'
import { FILE_FORMATS } from '_constants/AccountDetails/constants'
import { componentMapper } from '_constants/common_template/constants'
import { FILE_SIZE_2MP } from '_constants/constants'
import { IFileContent } from '_hooks/DebitFreezeUnfreeze/types'
import { IRequestData, IViewData, IViewDataItem } from '_hooks/PDE/RequestDetails/types'
import { IFormItem, IRootObject } from '_pages/CreateRequest/IndividualRequest/PDE/NewTemplate/types'
import { IFluxAction, IState, ObjectKeyValueAddress } from '_types/index'

interface IObject {
  [name: string]: string
}

export const convertFileToBase64 = (bulkFile: File | undefined) => new Promise((resolve: (value: IFileContent) => void, reject) => {
  if (bulkFile) {
    const reader = new FileReader()
    reader.onload = () => {
      const base64 = (reader.result as string).substring((reader.result as string).indexOf(',') + 1)
      resolve({
        documentTitle: bulkFile.name,
        mimeType: bulkFile.type,
        content: base64
      })
    }
    reader.onerror = (fileError) => reject(fileError)
    reader.readAsDataURL(bulkFile)
  }
})

export const getCorrelationId = () => uuidv4()

export const isEmptyObject = (object : IObject) => {
  let isEmpty = true
  if (Object.keys(object)?.length === 0) {
    isEmpty = true
  } else {
    const keys = Object.keys(object)
    keys.forEach((key: string) => {
      if (!Object[key]) {
        isEmpty = false
      }
    })
  }
  return isEmpty
}
export const convertHexToRGBA = (hexCode: string, opacity: number) => {
  let hex = hexCode.replace('#', '')

  if (hex.length === 3) {
    hex = `${hex[0]}${hex[0]}${hex[1]}${hex[1]}${hex[2]}${hex[2]}`
  }

  const r = parseInt(hex.substring(0, 2), 16)
  const g = parseInt(hex.substring(2, 4), 16)
  const b = parseInt(hex.substring(4, 6), 16)

  return `rgba(${r},${g},${b},${opacity / 100})`
}

let diffkeys = {}
const arrayDiff = (arr1: any, arr2: any) => {
  if (arr1.length !== arr2.length) {
    return false
  }
  arr1.forEach((i:any) => {
    if (arr1[i] !== arr2[i]) {
      return false
    }
    return false
  })

  return true
}

const diff = (obj1: any, obj2: any) => {
  if (!obj2 || Object.prototype.toString.call(obj2) === '[object, Undefined]') {
    return obj1
  }

  Object.keys(obj1).forEach((key) => {
    if (Object.prototype.hasOwnProperty.call(obj1, key)) {
      // eslint-disable-next-line no-use-before-define
      compare(obj1[key], obj2[key], key)
    }
  })
  Object.keys(obj2).forEach((key) => {
    if (Object.prototype.hasOwnProperty.call(obj2, key)) {
      if (!obj1[key] && obj1[key] !== obj2[key]) {
        diffkeys[key] = obj2[key]
      }
    }
  })
  return diffkeys
}

const compare = (item1: { toString: () => any }, item2: { toString: () => any }, key: string) => {
  const type1 = Object.prototype.toString.call(item1)
  const type2 = Object.prototype.toString.call(item2)

  if (!type2 || type2 === '[object, Undefined]') {
    diffkeys[key] = null
  } else if (type1 !== type2) {
    diffkeys[key] = item2
  } else if (type1 === '[object,Object]') {
    const objectDiff = diff(item1, item2)
    if (Object.keys(objectDiff).length > 0) {
      diffkeys[key] = objectDiff
    }
  } else if (type1 === '[object,Array]') {
    if (!arrayDiff(item1, item2)) {
      diffkeys[key] = item2
    }
  } else if (type1 === '[object,Function]') {
    if (item1.toString() !== item2.toString()) {
      diffkeys[key] = item2
    }
  } else if (item1 !== item2) {
    diffkeys[key] = item2
  }
}

/*
 * It converts the date to "01 Oct, 2020" kind of format
 */
export const dateConversion = (date: Date) => {
  const newDate = new Date(date)
  const selecteDate = newDate.getDate()
  const month = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ][newDate.getMonth()]
  const finalDate = `${selecteDate} ${month}, ${newDate.getFullYear()}`
  return finalDate
}

export const isObjectEqual = (objc1: any, objc2: any) => {
  diffkeys = {}
  const res = diff(objc1, objc2)
  const isEqual = Object.keys(res).length === 0
  return isEqual
}

export const defaultStateReducer = (state: IState, action: IFluxAction) => {
  const { payload } = action
  const newState = { ...state, ...payload }
  return {
    ...newState,
  }
}
/*
* It will convert file size in KB,MB
*/
export const validateFileDetails = (file: File) => {
  const { name, type, size } = file
  const isvalidExcel = type === 'application/vnd.ms-excel' || name?.toLowerCase()?.indexOf('.xlsx') > -1
  const decimals = 2
  const sizesLimit = FILE_SIZE_2MP
  if (!+size) {
    return {
      actualSize: '0 Bytes', docName: name, isvalidExcel, invalidSize: false
    }
  }
  if (size > sizesLimit) {
    return {
      actualSize: '0 Bytes', docName: name, isvalidExcel: false, invalidSize: true
    }
  }
  const k = 1024
  const dm = decimals < 0 ? 0 : decimals
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
  const i = Math.floor(Math.log(size) / Math.log(k))
  const actualSize = `${parseFloat((size / k ** i).toFixed(dm))} ${sizes[i]}`
  return {
    actualSize, docName: name, isvalidExcel, invalidSize: false
  }
}
export const validateFileSize = (file: File, fileSizeLimit: number = FILE_SIZE_2MP) => {
  const { size } = file
  const sizesLimit = fileSizeLimit
  if (size > sizesLimit) {
    return { invalidSize: true }
  }
  return { invalidSize: false }
}
/*
* It will convert date which we received from BE to UX Date format
*/
export const convertDateForAccountInfo = (date: string) => {
  if (date) {
    const dateParts: any = date.split('/')
    const newDate = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0])
    const updatedDate = dateConversion(newDate)
    return updatedDate
  }
  return date
}

/*
/*
* It will convert date - which we received from BE to UX Date format
*/
export const convertDateForAccountDetailsInfo = (date: string) => {
  if (date) {
    const dateParts: any = date.split('-')
    const newDate = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0])
    const updatedDate = dateConversion(newDate)
    return updatedDate
  }
  return date
}

/*
* It will convert date which we received from BE to UX Date format
*/
export const convertDate = (date: string) => {
  if (date) {
    const dateParts: any = date.split('/')
    const newDate = new Date(+dateParts[2], dateParts[1] - 1, +dateParts[0])
    const updatedDate = dateConversion(newDate)
    return updatedDate
  }
  return date
}

export const getDefautAnalyticsFromDate = () => new Date(new Date().setDate(new Date().getDate() - 7))

export const getDefautAnalyticsToDate = () => new Date()

export const convertToDateFormat = (value: string) => {
  if (!value || !value.includes(' ')) {
    return value
  }
  const months = {
    jan: 0,
    feb: 1,
    mar: 2,
    apr: 3,
    may: 4,
    jun: 5,
    jul: 6,
    aug: 7,
    sep: 8,
    oct: 9,
    nov: 10,
    dec: 11
  }
  const splitVal: any = value.split(' ')
  const monthName = splitVal?.[1].split(',')?.[0]
  return new Date(splitVal?.[2], months[monthName.toLowerCase()], splitVal?.[0])
}

const nthFormat = (d: number) => {
  if (d > 3 && d < 21) return 'th'
  switch (d % 10) {
    case 1: return 'st'
    case 2: return 'nd'
    case 3: return 'rd'
    default: return 'th'
  }
}

/*
 * It converts the date to "1st October 2020" kind of format
 */
export const dateConversionFormat = (date: Date) => {
  const newDate = new Date(date)
  const selecteDate = newDate.getDate()
  const month = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ][newDate.getMonth()]
  const finalDate = `${selecteDate}${nthFormat(selecteDate)} ${month} ${newDate.getFullYear()}`
  return finalDate
}

export const dateConversionForAPI = (dateVal: string) => {
  if (!dateVal) {
    return dateVal
  }
  const date = new Date(dateVal)

  const day = date.getDate()
  const month = date.getMonth() + 1
  const year = date.getFullYear()
  return `${day > 9 ? day : `0${day}`}-${month > 9 ? month : `0${month}`}-${year}`
}

export const convertDateFormat = (date: Date) => {
  const newDate = new Date(date)
  const selecteDate = String(newDate.getDate()).padStart(2, '0')
  const month = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ][newDate.getMonth()]
  const finalDate = `${selecteDate} ${month}, ${newDate.getFullYear()}`
  return finalDate
}

export const isValidDate = (date: string) => {
  const newDate = new Date(date)
  return !!newDate.getTime()
}
export const convertDateToYYMMDD = (date: string) => {
  const newDate = new Date(date?.split('-')?.reverse()?.join('-'))
  return newDate
}
export const getDownloadFilelink = (format : string, base64String : string) => {
  if (format === FILE_FORMATS.HTML) return `data:text/html;base64,${base64String}`
  if (format === FILE_FORMATS.EXCEL) return `data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,${base64String}`
  return `data:application/pdf;base64,${base64String}`
}

export const getAvatarInitials = (name: string | undefined) => {
  const [first, last] = name?.split(' ') || ''
  const avatarInitial = (first && first.charAt(0)) + (last && last.charAt(0))
  return avatarInitial
}
export const generateString = (length: number) => {
  let result = ' '
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
  const charactersLength = characters.length

  for (let i = 0; i < length; i += 1) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength))
  }

  return result
}

export const convertTimeFormat = (time: string) => {
  let hours: number = 0
  let minutes: string | number = ''
  let newformat: string = ''
  const timeArray = time?.split(':')
  if (timeArray?.length > 0) {
    const [hour, minute] = timeArray
    hours = Number(hour)
    minutes = Number(minute)
    newformat = hours >= 12 ? 'PM' : 'AM'
    hours %= 12
    hours = hours || 12
    minutes = minutes < 10 ? `0${minutes}` : minutes
  }

  return `${hours}:${minutes} ${newformat}`
}

export const formatDate = (inputDate: Date) => {
  let date; let month
  date = inputDate.getDate()
  month = inputDate.getMonth() + 1
  const year = inputDate.getFullYear()

  date = date
    .toString()
    .padStart(2, '0')

  month = month
    .toString()
    .padStart(2, '0')

  return `${date}-${month}-${year}`
}


/* To find the particular key and value is present in nested object and return the count number of time match the key value
eg: checkNestedObjectByKeyValue({}, 'mailingAddress', 'Yes') */

let count = 0
export const checkNestedObjectByKeyValue = (obj: ObjectKeyValueAddress, objKey: string, objValue: string, isRecursive: boolean = false) => {
  if (!isRecursive) {
    count = 0
  }
  if (typeof obj !== 'object') return false
  if (Object.prototype.hasOwnProperty.call(obj, objKey) && JSON.stringify(obj[objKey]?.[1]) === JSON.stringify(objValue)) {
    return true
  }
  Object.values(obj).forEach((value) => {
    if (checkNestedObjectByKeyValue(value, objKey, objValue, true)) {
      if (Object.prototype.hasOwnProperty.call(value, objKey)
      && (typeof value === 'object')
      && JSON.stringify(value?.[objKey]?.[1]) === JSON.stringify(objValue)) { count += 1 }
    }
  })
  return count
}

/* To find the particular key is present in nested object
eg: checkNestedObjectByKey({}, 'mailingAddress') */

export const checkNestedObjectByKey = (obj: ObjectKeyValueAddress, objKey: string) => {
  let isMailingAddressUpdated = false
  if (typeof obj !== 'object') return false
  if (Object.prototype.hasOwnProperty.call(obj, objKey)) {
    isMailingAddressUpdated = true
  }
  Object.values(obj).forEach((value) => {
    if (checkNestedObjectByKey(value, objKey)) { isMailingAddressUpdated = true }
  })
  return isMailingAddressUpdated
}

/* This function work as below
const title = 'personalDetails'
getTitle(title) ==> return {'Personal Details'}
*/
export const getTitle = (title: string) => {
  if (title) {
    const titleWithSpace = title.replace(/([a-z])([A-Z])/g, '$1 $2')
    return titleWithSpace.charAt(0).toUpperCase() + titleWithSpace.slice(1)
  }
  return ''
}
export const getFormDataFromJSON = (formdata: any, handleChange: any, handleRevert: any) => {
  const AddressDetails: IFormItem[] = []
  const items: IRootObject[] = []
  const initialValues: any = {}
  let formDescription: string = ''
  let accordionTitle = ''
  const details = formdata?.product?.details || []
  details.forEach((item: any) => {
    const data: IRootObject = {
      fieldName: '',
      label: '',
      readOnly: false,
      ComponentName: undefined
    }

    // Display conditions for Personal details
    const conditions = item.metadata.displayCondition || false
    const keyName = (conditions && Object.keys(conditions)?.[0]) || ''
    const keyValue = (conditions && Object.values(conditions)?.[0]) || ''
    const result = details.find((list: { name: string, value: string }) => (list.name === keyName && list.value === keyValue))

    if (componentMapper[item.type]) {
      data.fieldName = item.name
      data.ComponentName = componentMapper[item.type]
      data.handleChange = handleChange
      data.handleRevert = handleRevert
      data.label = item.placeholder
      data.readOnly = (conditions && !result) || item.validation_metadata.isDisabled
      data.options = item.metadata?.displayValues ?? undefined
      initialValues[item.name] = item.value
      items.push(data)
    } else if (item.name === 'accordion') {
      accordionTitle = item.placeholder
    } else {
      formDescription = item.placeholder
    }
  })
  const newData = { formItems: items }
  AddressDetails.push(newData)

  return [AddressDetails, formDescription, initialValues, accordionTitle]
}

export const getFormDetailsFromJSON = (formdata: any) => {
  const formDetails: IFormItem[] = []
  const items: IRootObject[] = []
  const initialValues: any = {}
  formdata.forEach((item: any) => {
    const data: IRootObject = {
      fieldName: '',
      label: '',
      readOnly: false,
      ComponentName: undefined
    }

    if (componentMapper[item?.type]) {
      data.fieldName = item?.name
      data.ComponentName = componentMapper[item?.type]
      data.label = item?.placeholder ? item?.placeholder : item?.placeHolder
      data.readOnly = item?.metadata ? item?.metadata?.disabled : true
      initialValues[item?.name] = item?.value
      items.push(data)
    }
  })
  const newData = { formItems: items }
  formDetails.push(newData)
  return [formDetails, initialValues]
}

/* render persona/kyc/address details data with old/new value
IN ==> ['Rama','Radha'],
OUT ==> {
    id: 1,
    field: name,
    existingRecord: 'Ram',
    newRecord: 'Raj'
  }
*/
const getFieldBaseObj = (obj:Record<string, string[]> | {} | undefined) => {
  const objArray: IViewDataItem[] = []
  if (!obj) {
    return objArray
  }
  return Object.keys(obj).map((key) => {
    if (Object.keys(obj)?.length !== 0) {
      const [oldVal, newVal] = obj[key]
      return {
        id: key,
        field: key,
        existingRecord: oldVal,
        newRecord: newVal
      }
    }
    return objArray
  })
}
/*
IN ==> personalDetails: {
        firstName: ['Rama','Radha']
       }
OUT ==> personalDetails: [
          firstName: {
              id: 1,
              field: name,
              existingRecord: 'Ram',
              newRecord: 'Raj'
          }
        ]
*/
export const createRequestDetailsReadOnlyData = (response:IRequestData) => {
  const data: IViewData = {
    personalDetails: [],
    kycDetails: [],
    addressAndContactDetails: {
      residenceAddress: {},
      permanentAddress: {},
      gstAddress: {},
      officeAddress: {},
      contactDetails: {},
      gstDetails: {}
    },
    residenceAddress: [],
    permanentAddress: [],
    gstAddress: [],
    officeAddress: [],
    contactDetails: [],
    gstDetails: []
  }

  if (response) {
    const requestData:IRequestData = { ...response }
    if (requestData) {
      if ('personalDetails' in requestData) {
        data.personalDetails = getFieldBaseObj(requestData.personalDetails) as IViewDataItem[]
      }
      if ('kycDetails' in requestData) {
        data.kycDetails = getFieldBaseObj(requestData.kycDetails) as IViewDataItem[]
      }
      if ('addressAndContactDetails' in requestData) {
        const addressObj = requestData.addressAndContactDetails

        if (addressObj) {
          if ('residenceAddress' in addressObj) {
            data.addressAndContactDetails.residenceAddress = getFieldBaseObj(addressObj.residenceAddress)
          }
          if ('permanentAddress' in addressObj) {
            data.addressAndContactDetails.permanentAddress = getFieldBaseObj(addressObj.permanentAddress)
          }
          if ('gstAddress' in addressObj) {
            data.addressAndContactDetails.gstAddress = getFieldBaseObj(addressObj.gstAddress)
          }
          if ('officeAddress' in addressObj) {
            data.addressAndContactDetails.officeAddress = getFieldBaseObj(addressObj.officeAddress)
          }
          if ('contactDetails' in addressObj) {
            data.addressAndContactDetails.contactDetails = getFieldBaseObj(addressObj.contactDetails)
          }
          if ('gstDetails' in addressObj) {
            data.addressAndContactDetails.gstDetails = getFieldBaseObj(addressObj.gstDetails)
          }
        }
      }
    }
  }
  return { ...data }
}


/*
  This function converts camel case string to UI Label Format i.e:
  extractBatchRecordHeader('testColumnAbc') will return 'Test Column Abc'
*/
export const extractBatchRecordHeader = (column: string) => {
  const charArr = [...column]
  let header = charArr[0]?.toString().toUpperCase()

  charArr.forEach((character, index) => {
    if (index !== 0) {
      if (character === character?.toUpperCase()) header = `${header} ${character}`
      else header = `${header}${character}`
    }
  })

  return header
}
