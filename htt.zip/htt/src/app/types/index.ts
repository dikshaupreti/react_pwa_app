interface Customer {
    accountNumber: string
    crn: string
    mobileNumber: string
    panNumber: string
    customerName: string
    dateOfBirth: string
}

const CustomerObj: Customer = {
  accountNumber: 'accountNumber',
  crn: 'crn',
  mobileNumber: 'mobileNumber',
  panNumber: 'panNumber',
  customerName: 'customerName',
  dateOfBirth: 'dateOfBirth',
}
interface IFluxAction {
  type: string
  payload?: any // tslint:disable-line no-any
  meta?: any // tslint:disable-line no-any
}
interface FormInitialValues {
  [name: string]: string
}
interface ResidenceAddress {
  [name: string]: string[]
}
interface PermanentAddress {
  [name: string]: string[]
}
interface GstAddress {
  [name: string]: string[]
}
interface OfficeAddress {
  [name: string]: string[]
}
interface ContactDetails {
  [name: string]: string[]
}
interface GstDetails {
  [name: string]: string[];
}
interface AddressAndContactDetails {
  residenceAddress: ResidenceAddress
  permanentAddress: PermanentAddress
  gstAddress: GstAddress
  officeAddress: OfficeAddress
  contactDetails: ContactDetails
  gstDetails: GstDetails
}

export interface ObjectKeyValueAddress {
  addressAndContactDetails?: AddressAndContactDetails
}


interface FormValues {
  label: string
  form: any
  initialValues: FormInitialValues
}

interface FormValuesTabs {
  label: string
  form?: any
  initialValues?: any
  tabstype?:string
  tabs?:any
}

interface FormUpdateValues {
  existingValues: any
  fieldName: string
  newValue: string | number
}

// tslint:disable-next-line: no-any
type IState = any

export type {
  Customer, IFluxAction, IState, FormInitialValues, FormValues, FormValuesTabs, FormUpdateValues, AddressAndContactDetails
}
export { CustomerObj }

