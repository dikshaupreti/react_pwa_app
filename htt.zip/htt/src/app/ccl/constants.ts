export const LOGIN = 'VALUE'
