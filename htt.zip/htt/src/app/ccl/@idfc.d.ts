declare module '@idfc/ui-commons/*';
declare module '@idfc/ccl-web/*';
declare module '@idfc/ccl-commons/*';
