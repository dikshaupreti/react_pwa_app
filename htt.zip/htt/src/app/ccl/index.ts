import * as ALL_ICONS from '@idfc/ccl-commons/assets/icons'
import DarkMode from '@idfc/ccl-commons/assets/images/dark-mode.svg'
import LightMode from '@idfc/ccl-commons/assets/images/light-mode.svg'
import SystemMode from '@idfc/ccl-commons/assets/images/system-mode.svg'
import PageBg from '@idfc/ccl-commons/assets/patterns/full-pattern-gray-10opacity.svg'
import {
  AvatarSize,
  ButtonSize,
  ButtonType,
  FontColor,
  FontSize,
  IconCategory,
  IconColor,
  IconSize,
  LineHeight,
  Regex,
  Spacing,
  TabsType
} from '@idfc/ccl-commons/enums'
import { LogoFull } from '@idfc/ccl-commons/logos'
import palette, * as colors from '@idfc/ccl-commons/palette'
import {
  deepCheckObjectKeys,
  hasOwnProperty,
  hexToRgb,
  isObject
} from '@idfc/ccl-commons/utils'
import Accordion from '@idfc/ccl-web/components/Accordion'
import Avatar from '@idfc/ccl-web/components/Avatar'
import CallToAction from '@idfc/ccl-web/components/CallToAction'
import DateInputV1 from '@idfc/ccl-web/components/DateInput'
import HorizontalLine from '@idfc/ccl-web/components/HorizontalLine'
import Icon from '@idfc/ccl-web/components/Icon'
import IconButton from '@idfc/ccl-web/components/IconButton'
import Input from '@idfc/ccl-web/components/Input'
import ListGroup from '@idfc/ccl-web/components/ListGroup'
import Loader from '@idfc/ccl-web/components/Loader'
import Modal from '@idfc/ccl-web/components/Modal'
import NavigationHeader from '@idfc/ccl-web/components/NavigationHeader'
import ProgressBar from '@idfc/ccl-web/components/ProgressBar'
import RadioButton from '@idfc/ccl-web/components/RadioButton'
import SearchInput from '@idfc/ccl-web/components/SearchInput'
import Tabs from '@idfc/ccl-web/components/Tabs'
import Text from '@idfc/ccl-web/components/Text'
import ScreenSizeProvider, * as providers from '@idfc/ccl-web/providers'
import { DesktopApplicationGlobalStyles } from '@idfc/ccl-web/styles'
import breakpoints from '@idfc/ccl-web/styles/breakpoints'
import { ALL_THEMES } from '@idfc/ccl-web/themes'
import Alert from '@idfc/ccl-web/v2/components/Alert'
import Box from '@idfc/ccl-web/v2/components/Box'
import Button from '@idfc/ccl-web/v2/components/Button'
import DateInput from '@idfc/ccl-web/v2/components/DateInput'
import NumberInput from '@idfc/ccl-web/v2/components/NumberInput'
import RadioButtonGroup from '@idfc/ccl-web/v2/components/RadioButtonGroup'
import Select from '@idfc/ccl-web/v2/components/Select'
import Stepper from '@idfc/ccl-web/v2/components/Stepper'
import StyledText from '@idfc/ccl-web/v2/components/StyledText'
import Tags from '@idfc/ccl-web/v2/components/Tags'
import TextInput from '@idfc/ccl-web/v2/components/TextInput'
import Toast from '@idfc/ccl-web/v2/components/Toast'

export {
  PageBg,
  Button,
  Alert,
  Text,
  Input,
  Loader,
  FontColor,
  FontSize,
  LogoFull,
  ScreenSizeProvider,
  DesktopApplicationGlobalStyles,
  ALL_ICONS,
  IconCategory,
  Spacing,
  breakpoints,
  isObject,
  hasOwnProperty,
  deepCheckObjectKeys,
  Modal,
  ALL_THEMES,
  CallToAction,
  hexToRgb,
  palette,
  LightMode,
  DarkMode,
  SystemMode,
  DateInputV1,
  RadioButton,
  TextInput,
  Icon,
  NavigationHeader,
  Accordion,
  StyledText,
  Box,
  AvatarSize,
  Avatar,
  Tags,
  colors,
  providers,
  HorizontalLine,
  ButtonType,
  ButtonSize,
  Regex,
  Toast,
  SearchInput,
  DateInput,
  NumberInput,
  LineHeight,
  Tabs,
  TabsType,
  IconColor,
  IconSize,
  RadioButtonGroup,
  Select,
  Stepper,
  ProgressBar,
  ListGroup,
  IconButton
}
