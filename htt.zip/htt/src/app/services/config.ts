import { todoConstants } from '_constants/todoConstants'
import {
  getAccountSearchApolloQuery, getAuthenticationQuery, getCustomerSearchDetailsApolloQuery,
  getCustWorkflowServiceApolloQuery, getDocumentApolloQuery,
  getDownLoadDocumentApolloQuery, getFeeDetailsApolloQuery,
  getFetchWorkflowApolloQuery, getPMDSApolloQuery,
  getProductFieldDataApolloQuery, getWorkFlowDetailsApolloQuery,
  getWorkFlowProcessingApolloQuery
} from '_middleware/http-fetcher'

export const APIPath = {
  customerSearch: '/account/search',
  customerOverView: '/customer/overview',
  accountDetails: '/productdetails',
  makerCheckerQueue: '/queue',
  customerDetails: '/customers/details',
  feeDetails: '/feeDetails',
  requestCount: '/count',
  makerCheckerAnalytics: '/analytics',
  customerOneView: '/customers/oneview',
  getDocumentData: '/viewdocument',
  createDebitFreezeUnfreezeRequest: '/bulk/createrequest',
  authorizeBulkRequest: '/bulk/authorizerequest',
  getCustomerDocuments: '/customers/documents',
  getRequestDetails: '/bulk/requestdetails',
  viewActivity: '/activitydetails',
  validateDocument: '/bulk/validatedocument',
  batchRecordDetails: '/batchrecorddetails',
  getAttachments: '/documents',
  viewDocuments: '/download',
  codeMasterHelp: '/referencedata',
  authorisePDERequest: '/pdeupdate/individual/authorizerequest',
  createRequestPDE: '/pdeupdate/individual',
  panValidation: '/pdeupdate/panvalidation',
  verifyName: '/pdeupdate/verifyname',
  pdeRequestDetails: '/requestdetails',
  bulkUploadTemplate: '/productdetails',
  batchRecordsTemplate: '/productdetails',
  createBulkUploadRequest: '', // /bulk/request
  validate: '', // /bulk/validate
  login: '/login',
  accountDetailsTemplate: '/productdetails'
}

export const RESPONSE_KEY = {
  customerSearch: 'customer',
  customerOverView: 'customerOverView',
  accountDetails: 'loanAccountDetails',
  makerCheckerQueue: 'makerCheckerQueue',
  customerDetails: 'customerinfoDetails',
  feeDetails: 'customersfeeDetails',
  requestCount: 'makerCheckerCount',
  makerCheckerAnalytics: 'makerCheckerAnalytics',
  customerOneView: 'customerOneView',
  getDocumentData: 'getDocumentData',
  createDebitFreezeUnfreezeRequest: 'createDebitFreezeUnfreezeRequest',
  authorizeBulkRequest: 'authorizeBulkRequest',
  getCustomerDocuments: 'getCustomerDocuments',
  getRequestDetails: 'getRequestDetails',
  viewActivity: 'viewActivity',
  validateDocument: 'validateDocument',
  batchRecordDetails: 'batchRecordDetails',
  getAttachments: 'getAttachments',
  viewDocuments: 'viewDocuments',
  codeMasterHelp: 'codeMasterHelp',
  authorisePDERequest: 'authorisePDERequest',
  createRequestPDE: 'createRequestPDE',
  panValidation: 'panValidation',
  verifyName: 'verifyName',
  pdeRequestDetails: 'pdeRequestDetails',
  bulkUploadTemplate: 'bulkUploadTemplate',
  batchRecordsTemplate: 'batchRecordsTemplate',
  bulkUploadTemplateTwo: 'bulkUploadTemplateTwo',
  createBulkUploadRequest: 'createBulkUploadRequest',
  validate: 'validate',
  login: 'login',
  accountDetailsTemplate: 'accountDetailsTemplate'
}

type Keys = keyof typeof RESPONSE_KEY

// 👇️ type Values = 1 | "James Doe" | 100
type Values = typeof RESPONSE_KEY[Keys]

const endpoint = 'v1'
const METHOD_POST = 'POST'
const METHOD_GET = 'GET'

const getQuery = (key: Values, apiEndpoint?: string, requestMethod?: string) => {
  let QUERY: any
  switch (key) {
    case RESPONSE_KEY.login:
      QUERY = getAuthenticationQuery({
        endpoint,
        method: METHOD_POST,
        path: APIPath.login,
        responseKey: RESPONSE_KEY.login,
        responseFieldsList: [''],
        queryParams: {}
      })
      break
    case RESPONSE_KEY.customerSearch:
      QUERY = getAccountSearchApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.customerSearch,
        responseKey: RESPONSE_KEY.customerSearch,
        responseFieldsList: [''],
        queryParams: {}
      })
      break
    case RESPONSE_KEY.customerOverView:
      QUERY = getCustomerSearchDetailsApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.customerOverView,
        responseKey: RESPONSE_KEY.customerOverView,
        responseFieldsList: [''],
        queryParams: {}
      })
      break
    case RESPONSE_KEY.accountDetails:
      QUERY = getProductFieldDataApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.accountDetails,
        responseKey: RESPONSE_KEY.accountDetails,
        responseFieldsList: [''],
        queryParams: {}
      })
      break
    case RESPONSE_KEY.customerDetails:
      QUERY = getCustomerSearchDetailsApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.customerDetails,
        responseKey: RESPONSE_KEY.customerDetails,
        responseFieldsList: [''],
        queryParams: {}
      })
      break
    case RESPONSE_KEY.feeDetails:
      QUERY = getFeeDetailsApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.feeDetails,
        responseKey: RESPONSE_KEY.feeDetails,
        responseFieldsList: [''],
        queryParams: {}
      })
      break
    case RESPONSE_KEY.requestCount:
      QUERY = getWorkFlowDetailsApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.requestCount,
        responseKey: RESPONSE_KEY.requestCount,
        responseFieldsList: [''],
        queryParams: {}
      })
      break
    case RESPONSE_KEY.makerCheckerQueue:
      QUERY = getWorkFlowDetailsApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.makerCheckerQueue,
        responseKey: RESPONSE_KEY.makerCheckerQueue,
        responseFieldsList: [''],
        queryParams: {}
      })
      break
    case RESPONSE_KEY.makerCheckerAnalytics:
      QUERY = getWorkFlowDetailsApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.makerCheckerAnalytics,
        responseKey: RESPONSE_KEY.makerCheckerAnalytics,
        responseFieldsList: [''],
        queryParams: {}
      })
      break
    case RESPONSE_KEY.customerOneView:
      QUERY = getCustomerSearchDetailsApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.customerOneView,
        responseKey: RESPONSE_KEY.customerOneView,
        responseFieldsList: [''],
        queryParams: {}
      })
      break
    case RESPONSE_KEY.getCustomerDocuments:
      QUERY = getDocumentApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.getCustomerDocuments,
        responseKey: RESPONSE_KEY.getCustomerDocuments,
        responseFieldsList: [''],
        queryParams: {}
      })
      break
    case RESPONSE_KEY.getDocumentData:
      QUERY = getDocumentApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.getDocumentData,
        responseKey: RESPONSE_KEY.getDocumentData,
        responseFieldsList: [''],
        queryParams: {}
      })
      break
    case RESPONSE_KEY.authorizeBulkRequest:
      QUERY = getWorkFlowProcessingApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.authorizeBulkRequest,
        responseKey: RESPONSE_KEY.authorizeBulkRequest,
      })
      break
    case RESPONSE_KEY.viewActivity:
      QUERY = getWorkFlowDetailsApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.viewActivity,
        responseKey: RESPONSE_KEY.viewActivity,
        responseFieldsList: [''],
        queryParams: {}
      })
      break
    case RESPONSE_KEY.validateDocument:
      QUERY = getWorkFlowProcessingApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.validateDocument,
        responseKey: RESPONSE_KEY.validateDocument,
        responseFieldsList: [''],
        queryParams: {},
      })
      break
    case RESPONSE_KEY.batchRecordDetails:
      QUERY = getWorkFlowDetailsApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.batchRecordDetails,
        responseKey: RESPONSE_KEY.batchRecordDetails,
        responseFieldsList: [''],
        queryParams: {}
      })
      break
    case RESPONSE_KEY.batchRecordsTemplate:
      QUERY = getProductFieldDataApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.batchRecordsTemplate,
        responseKey: RESPONSE_KEY.batchRecordsTemplate,
        responseFieldsList: [''],
        queryParams: {}
      })
      break
    case RESPONSE_KEY.getAttachments:
      QUERY = getWorkFlowDetailsApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.getAttachments,
        responseKey: RESPONSE_KEY.getAttachments,
        responseFieldsList: [''],
        queryParams: {}
      })
      break
    case RESPONSE_KEY.viewDocuments:
      QUERY = getDownLoadDocumentApolloQuery({
        endpoint,
        method: requestMethod || METHOD_GET,
        path: apiEndpoint || APIPath.viewDocuments,
        responseKey: RESPONSE_KEY.viewDocuments,
        responseFieldsList: [''],
        queryParams: {}
      })
      break
    case RESPONSE_KEY.createDebitFreezeUnfreezeRequest:
      // TODO: Change responseFieldsList once BE makes API follow response format
      QUERY = getWorkFlowProcessingApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.createDebitFreezeUnfreezeRequest,
        responseKey: RESPONSE_KEY.createDebitFreezeUnfreezeRequest,
        responseFieldsList: todoConstants.RESPONSE_FIELDS_LIST,
        queryParams: {},
      })
      break
    case RESPONSE_KEY.codeMasterHelp:
      QUERY = getProductFieldDataApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.codeMasterHelp,
        responseKey: RESPONSE_KEY.codeMasterHelp,
        responseFieldsList: [''],
        queryParams: {}
      })
      break
    case RESPONSE_KEY.authorisePDERequest:
      QUERY = getCustWorkflowServiceApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.authorisePDERequest,
        responseKey: RESPONSE_KEY.authorisePDERequest,
      })
      break
    case RESPONSE_KEY.createRequestPDE:
      QUERY = getCustWorkflowServiceApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.createRequestPDE,
        responseKey: RESPONSE_KEY.createRequestPDE,
        responseFieldsList: [''],
        queryParams: {}
      })
      break
    case RESPONSE_KEY.verifyName:
      QUERY = getCustWorkflowServiceApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.verifyName,
        responseKey: RESPONSE_KEY.verifyName,
        responseFieldsList: [''],
        queryParams: {}
      })
      break
    case RESPONSE_KEY.panValidation:
      QUERY = getCustWorkflowServiceApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.panValidation,
        responseKey: RESPONSE_KEY.panValidation,
        responseFieldsList: [''],
        queryParams: {}
      })
      break
    case RESPONSE_KEY.pdeRequestDetails:
      QUERY = getFetchWorkflowApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.pdeRequestDetails,
        responseKey: RESPONSE_KEY.pdeRequestDetails,
        responseFieldsList: [''],
        queryParams: {},
      })
      break
    case RESPONSE_KEY.bulkUploadTemplate:
      QUERY = getPMDSApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.bulkUploadTemplate,
        responseKey: RESPONSE_KEY.bulkUploadTemplate,
        responseFieldsList: [''],
        queryParams: {},
      })
      break
    case RESPONSE_KEY.bulkUploadTemplateTwo:
      QUERY = getPMDSApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.bulkUploadTemplate,
        responseKey: RESPONSE_KEY.bulkUploadTemplateTwo,
        responseFieldsList: [''],
        queryParams: {},
      })
      break
    case RESPONSE_KEY.createBulkUploadRequest:
      QUERY = getWorkFlowProcessingApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.createBulkUploadRequest,
        responseKey: RESPONSE_KEY.createBulkUploadRequest,
        responseFieldsList: [''],
        queryParams: {},
      })
      break
    case RESPONSE_KEY.validate:
      QUERY = getWorkFlowProcessingApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.validate,
        responseKey: RESPONSE_KEY.validate,
        responseFieldsList: [''],
        queryParams: {},
      })
      break
    case RESPONSE_KEY.accountDetailsTemplate:
      QUERY = getProductFieldDataApolloQuery({
        endpoint,
        method: requestMethod || METHOD_POST,
        path: apiEndpoint || APIPath.accountDetailsTemplate,
        responseKey: RESPONSE_KEY.accountDetailsTemplate,
        responseFieldsList: [''],
        queryParams: {},
      })
      break
    default:
      break
  }
  return QUERY
}


export { getQuery }

