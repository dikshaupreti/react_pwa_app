import React from 'react'

export const FeatureToggleContext = React.createContext({
  enabledFeatures: [] as string[],
})
