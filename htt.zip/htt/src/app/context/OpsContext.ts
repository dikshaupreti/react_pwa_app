
import { createContext } from 'react'
import { EUserRole } from '_constants/RequestQueue/constants'
import { todoConstants } from '_constants/todoConstants'
import { getDefautAnalyticsFromDate, getDefautAnalyticsToDate } from '_utils/util'
import { CustomerDetails } from './types'

const defaultCustomerInfo: CustomerDetails = {
  accountNumber: '',
  crn: '',
  mobileNumber: '',
  panNumber: '',
  customerName: '',
  dateOfBirth: '',
  selectedCRN: '',
  selectedCustomerInfo: {
    customerName: '',
    accountNumber: '',
    accountOpeningDate: '',
  },
  makerCheckerDateRange: {
    fromDate: new Date(),
    toDate: new Date(),
  },
  makerIndividualDateRange: {
    fromDate: getDefautAnalyticsFromDate(),
    toDate: getDefautAnalyticsToDate(),
  },
  makerBulkDateRange: {
    fromDate: getDefautAnalyticsFromDate(),
    toDate: getDefautAnalyticsToDate(),
  },
  checkerIndividualDateRange: {
    fromDate: getDefautAnalyticsFromDate(),
    toDate: getDefautAnalyticsToDate(),
  },
  checkerBulkDateRange: {
    fromDate: getDefautAnalyticsFromDate(),
    toDate: getDefautAnalyticsToDate(),
  },
  isCustomerPage: false,
  batchId: null,
  setCustomerInfo: () => null,
  setSelectedCRN: () => null,
  setSelectedCustomerInfo: () => null,
  userRole: EUserRole.maker,
  // TODO will changes once user login functionality added
  makerId: todoConstants.MAKER_ID,
  setMakerId: () => null,
  setUserRole: () => null,
  updateIsCustomerPage: () => null,
  updateMakerCheckerDateRange: () => null,
  updateMakerIndividualDateRange: () => null,
  updateMakerBulkDateRange: () => null,
  updateCheckerIndividualDateRange: () => null,
  updateCheckerBulkDateRange: () => null,
  setBatchId: () => null,
  setProductName: () => null,
  setBulkMaker: () => null,
  productName: 'ACEPL',
  bulkMakerData: [],
  sourceName: 'OPPS',
  action: 'ACCOUNT',
  typeOfOperation: '',
  typeOfRequest: '',
  requestType: '',
  workFlowType: '',
  JWT: '',
  setRequestType: () => null,
  setWorkFlowType: () => null,
  setJWT: () => null
}

const OpsContext = createContext(defaultCustomerInfo)

export { OpsContext, defaultCustomerInfo }

