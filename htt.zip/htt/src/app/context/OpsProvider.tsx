import React from 'react'
import { defaultCustomerInfo, OpsContext } from './OpsContext'
import {
  CustomerDetails, CustomerInfo, MakerCheckerDateRange, SelectedCustomerInfo
} from './types'

interface IState extends CustomerDetails {}

interface IAction {
  type?: string
  payload: any
  meta?: any
}

export function stateReducer(state: IState, action: IAction) {
  const { payload } = action
  const newState: IState = { ...state, ...payload }

  const nextState = {
    ...newState,
  }
  return nextState
}

const OpsProvider = ({ children }: {children: React.ReactNode}) => {
  const [state, dispatch] = React.useReducer(stateReducer, defaultCustomerInfo)

  const setCustomerInfo = (customerInfo: CustomerInfo) => {
    dispatch({
      payload: {
        ...customerInfo,
      },
    })
  }

  const setSelectedCRN = (crn: string) => {
    dispatch({
      payload: {
        selectedCRN: crn,
      },
    })
  }
  const updateIsCustomerPage = (isCustomerPage: boolean) => {
    dispatch({
      payload: {
        isCustomerPage
      },
    })
  }
  const updateMakerCheckerDateRange = (dateRange: MakerCheckerDateRange) => {
    dispatch({
      payload: {
        makerCheckerDateRange: {
          fromDate: dateRange.fromDate,
          toDate: dateRange.toDate
        }
      },
    })
  }
  const updateMakerIndividualDateRange = (dateRange: MakerCheckerDateRange) => {
    dispatch({
      payload: {
        makerIndividualDateRange: {
          fromDate: dateRange.fromDate,
          toDate: dateRange.toDate
        }
      },
    })
  }
  const updateMakerBulkDateRange = (dateRange: MakerCheckerDateRange) => {
    dispatch({
      payload: {
        makerBulkDateRange: {
          fromDate: dateRange.fromDate,
          toDate: dateRange.toDate
        }
      },
    })
  }
  const updateCheckerIndividualDateRange = (dateRange: MakerCheckerDateRange) => {
    dispatch({
      payload: {
        checkerIndividualDateRange: {
          fromDate: dateRange.fromDate,
          toDate: dateRange.toDate
        }
      },
    })
  }
  const updateCheckerBulkDateRange = (dateRange: MakerCheckerDateRange) => {
    dispatch({
      payload: {
        checkerBulkDateRange: {
          fromDate: dateRange.fromDate,
          toDate: dateRange.toDate
        }
      },
    })
  }
  const setUserRole = (userRole:string) => {
    dispatch({
      payload: {
        userRole
      },
    })
  }
  const setSelectedCustomerInfo = (customerInfo: SelectedCustomerInfo) => {
    dispatch({
      payload: {
        selectedCustomerInfo: {
          ...customerInfo
        }
      },
    })
  }
  const setBatchId = (batchId:number) => {
    dispatch({
      payload: {
        batchId
      },
    })
  }
  const setMakerId = (makerId:string) => {
    dispatch({
      payload: {
        makerId
      },
    })
  }
  const setProductName = (productName:string) => {
    dispatch({
      payload: {
        productName
      },
    })
  }
  const setBulkMaker = (bulkMakerData:string[]) => {
    dispatch({
      payload: {
        bulkMakerData
      },
    })
  }

  const setRequestType = (requestType: string) => {
    dispatch({
      payload: {
        requestType
      },
    })
  }

  const setWorkFlowType = (workFlowType: string) => {
    dispatch({
      payload: {
        workFlowType
      },
    })
  }

  const setJWTType = (jwt: string) => {
    dispatch({
      payload: {
        jwt
      },
    })
  }

  const value = React.useMemo(
    () => ({
      ...state,
      setCustomerInfo,
      setSelectedCRN,
      setSelectedCustomerInfo,
      setUserRole,
      updateIsCustomerPage,
      updateMakerCheckerDateRange,
      updateMakerIndividualDateRange,
      updateMakerBulkDateRange,
      updateCheckerIndividualDateRange,
      updateCheckerBulkDateRange,
      setBatchId,
      setMakerId,
      setProductName,
      setBulkMaker,
      setRequestType,
      setWorkFlowType,
      setJWTType
    }),
    [state, setCustomerInfo],
  )
  return (
    <OpsContext.Provider value={value}>
      {children}
    </OpsContext.Provider>
  )
}

export { OpsProvider }

