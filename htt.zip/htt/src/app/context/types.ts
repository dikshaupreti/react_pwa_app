import { ReactElement } from 'react'

interface CustomerInfo {
  accountNumber: string
  crn: string
  mobileNumber: string
  panNumber: string
  customerName: string
  dateOfBirth: string
}
interface SelectedCustomerInfo {
  accountNumber: string
  customerName: string
  accountOpeningDate?: string | undefined
}
interface QuickSearch {
  mobileNumber: ''
  accountNumber: ''
  panNumber: ''
}

interface MakerCheckerDateRange {
  fromDate: Date,
  toDate: Date
}

interface CustomerDetails extends CustomerInfo {
  selectedCRN: string
  userRole: string
  makerId?: string
  selectedCustomerInfo: SelectedCustomerInfo
  isCustomerPage: boolean
  makerCheckerDateRange: MakerCheckerDateRange
  makerIndividualDateRange: MakerCheckerDateRange
  makerBulkDateRange: MakerCheckerDateRange
  checkerIndividualDateRange: MakerCheckerDateRange
  checkerBulkDateRange: MakerCheckerDateRange
  batchId?: number | null
  setCustomerInfo: (customerInfo: CustomerInfo) => void
  setSelectedCRN: (crn: string) => void
  setSelectedCustomerInfo: (customerInfo: SelectedCustomerInfo) => void
  setUserRole: (userRole: string) => void
  updateIsCustomerPage: (isCustomerPage: boolean) => void
  updateMakerCheckerDateRange: (dateRange: MakerCheckerDateRange) => void
  updateMakerIndividualDateRange: (dateRange: MakerCheckerDateRange) => void
  updateMakerBulkDateRange: (dateRange: MakerCheckerDateRange) => void
  updateCheckerIndividualDateRange: (dateRange: MakerCheckerDateRange) => void
  updateCheckerBulkDateRange: (dateRange: MakerCheckerDateRange) => void
  setBatchId?: (batchId:number) => void
  setMakerId?: (makerId: string) => void
  productName: string,
  sourceName: string,
  action: string,
  typeOfOperation: string,
  typeOfRequest: string
  bulkMakerData: string []
  requestType: string,
  workFlowType: string,
  JWT: string
  setProductName: (productName:string) => void
  setBulkMaker: (bulkMakerData:string[]) => void
  setRequestType: (requestType: string) => void
  setWorkFlowType: (workFlowType: string) => void
  setJWT: (jwt: string) => void
}

interface IFeatureToggleContext {
  enabledFeatures: string[]
}

interface IFeatureToggleProvider {
  children: ReactElement
  value: IFeatureToggleContext
}

type ValueOf<T> = T[keyof T]

type StateType = { state: 'pending' | 'fullfilled' | 'rejected' }
interface IFileInfo {
  fileName: string
  size:string | null
}
interface IAction {
  type?: string
  payload: any
  meta?: any
}
export type {
  QuickSearch,
  CustomerInfo,
  CustomerDetails,
  StateType,
  ValueOf,
  SelectedCustomerInfo,
  IFeatureToggleContext,
  IFeatureToggleProvider,
  MakerCheckerDateRange,
  IFileInfo,
  IAction,

}

