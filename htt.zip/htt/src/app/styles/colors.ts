// TODO: Find out a way to not use hardcoded strings for colors while also not raising console warnings

import { colors } from '_ccl'

export const approvedIconColor = 'NEW_GREEN_300'
export const approvedLegendColor = 'NEW_GREEN_300'
export const rejectedLegendColor = 'NEW_MAROON_300'
export const pendingLegendColor = 'NEW_ORANGE_200'
export const filterTextColor = 'NEW_GREY_600'
export const titleTextColor = 'NEW_GREY_800'
export const transparentColor = 'transparent'
export const avatarBackgroundGreyColor = filterTextColor
export const filteredIconColor = 'NEW_GREY_400'

export const OPS_COLOR = {
  NEW_GREY_800: colors.NEW_GREY_800,
  NEW_GREY_600: colors.NEW_GREY_600,
  NEW_GREY_100: colors.NEW_GREY_100,
  NEW_RED_100: colors.NEW_RED_100,
  NEW_RED_200: colors.NEW_RED_200,
  NEW_WHITE_100: colors.NEW_WHITE_100,
  NEW_MAROON_100: colors.NEW_MAROON_100,
  NEW_GREY_400: colors.NEW_GREY_400,
  NEW_MAROON_400: colors.NEW_MAROON_400,
  NEW_GREY_300: colors.NEW_GREY_300,
  NEW_GREEN_300: colors.NEW_GREEN_300,
  NEW_MAROON_300: colors.NEW_MAROON_300,
  NEW_ORANGE_200: colors.NEW_ORANGE_200,
  NEW_MAROON_200: colors.NEW_MAROON_200,
  NEW_BLACK_100: colors.NEW_BLACK_100,
  NEW_ROSE_100: colors.NEW_ROSE_100,
  NEW_GREY_200: colors.grey200,
  NEW_GREEN_100: colors.NEW_GREEN_100,
  TINT_RED: colors.TINT_RED,
  NEW_ORANGE_100: colors.NEW_ORANGE_100,
  NEW_WHITE: colors.white,
}
