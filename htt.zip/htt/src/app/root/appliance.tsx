import {
  ApolloClient, ApolloLink, ApolloProvider, concat, InMemoryCache,
  ServerError
} from '@apollo/client'
import { onError } from '@apollo/client/link/error'
import { RestLink } from 'apollo-link-rest'
import { getAppHeaders, getJWT } from 'app/middleware/http-fetcher'
import React, { lazy } from 'react'
import { useNavigate } from 'react-router-dom'
import { SnackbarProvider } from '_components/Snackbar/SnackbarProvider'
import { pages } from '_constants/Root/constants'
import { RoutesComp as Routes } from '_routes/Routes'
import {
  REACT_APP_CLOUD_AUTHENTICATION_ENDPOINT,
  REACT_APP_CLOUD_REST_ENDPOINT,
  REACT_APP_CLOUD_REST_ENDPOINT_ACCOUNT_SEARCH,
  REACT_APP_CLOUD_REST_ENDPOINT_ACCSERVICE,
  REACT_APP_CLOUD_REST_ENDPOINT_CDSMSERVICE,
  REACT_APP_CLOUD_REST_ENDPOINT_CUSTOMERSEARCH_DETAILS,
  REACT_APP_CLOUD_REST_ENDPOINT_CUSTOMER_WORKFLOW,
  REACT_APP_CLOUD_REST_ENDPOINT_DOCUMENT,
  REACT_APP_CLOUD_REST_ENDPOINT_FEE_DETAILS,
  REACT_APP_CLOUD_REST_ENDPOINT_FETCH_WORKFLOW,
  REACT_APP_CLOUD_REST_ENDPOINT_MCSERVICE,
  REACT_APP_CLOUD_REST_ENDPOINT_OPSSERVICE,
  REACT_APP_CLOUD_REST_ENDPOINT_PMDSERVICE,
  REACT_APP_CLOUD_REST_ENDPOINT_PRODUCT_DOWNLOAD_DOCUMENT,
  REACT_APP_CLOUD_REST_ENDPOINT_PRODUCT_FIELD_DATA,
  REACT_APP_CLOUD_REST_ENDPOINT_WORKFLOW_DETAILS,
  REACT_APP_CLOUD_REST_ENDPOINT_WORKFLOW_PROCESSING,
} from '../config'
import { Helmet } from './helmet'
import { IBulkUploadFileData } from './types'

const BasePresentationLayer = lazy(
  () => import('_components/BasePresentationLayer')
)
// const restLink = new RestLink({ endpoints: { v1: 'http://localhost:8080/api/v1/cds' } })
const restLink = new RestLink({
  endpoints: {
    cds: REACT_APP_CLOUD_REST_ENDPOINT,
    mcService: REACT_APP_CLOUD_REST_ENDPOINT_MCSERVICE,
    productMetaDataService: REACT_APP_CLOUD_REST_ENDPOINT_PMDSERVICE,
    accountService: REACT_APP_CLOUD_REST_ENDPOINT_ACCSERVICE,
    cdsCaseManagementService: REACT_APP_CLOUD_REST_ENDPOINT_CDSMSERVICE,
    authenticationServices: REACT_APP_CLOUD_AUTHENTICATION_ENDPOINT,
    customerWorkflow: REACT_APP_CLOUD_REST_ENDPOINT_CUSTOMER_WORKFLOW,
    accountSearch: REACT_APP_CLOUD_REST_ENDPOINT_ACCOUNT_SEARCH,
    feeDetails: REACT_APP_CLOUD_REST_ENDPOINT_FEE_DETAILS,
    customerSearchDetails: REACT_APP_CLOUD_REST_ENDPOINT_CUSTOMERSEARCH_DETAILS,
    opsService: REACT_APP_CLOUD_REST_ENDPOINT_OPSSERVICE,
    fetchWorkflow: REACT_APP_CLOUD_REST_ENDPOINT_FETCH_WORKFLOW,
    workFlowDetails: REACT_APP_CLOUD_REST_ENDPOINT_WORKFLOW_DETAILS,
    document: REACT_APP_CLOUD_REST_ENDPOINT_DOCUMENT,
    workFlowProcessing: REACT_APP_CLOUD_REST_ENDPOINT_WORKFLOW_PROCESSING,
    productFieldData: REACT_APP_CLOUD_REST_ENDPOINT_PRODUCT_FIELD_DATA,
    downloadDocument: REACT_APP_CLOUD_REST_ENDPOINT_PRODUCT_DOWNLOAD_DOCUMENT
  },
  bodySerializers: {
    // TODO change data type to any for File Uploads using FormData in the future
    fileEncode: (data: IBulkUploadFileData, headers: Headers) => {
      const formData = new FormData()
      Object.keys(data).forEach((key) => formData.append(key, data[key]))
      headers.set('Accept', '*/*')
      return { body: formData, headers }
    }
  }
})

const authMiddleware = new ApolloLink((operation, forward) => {
  operation.setContext(({ headers = {} }) => ({
    headers: {
      ...headers,
      ...(getJWT() && getAppHeaders())
    }
  }))
  return forward(operation)
})

const memoryCache = new InMemoryCache()
function Appliance() {
  const navigate = useNavigate()
  // here we check api is token expire on global level
  const logoutLink = onError(({ networkError }) => {
    if (networkError) {
      if (networkError && (networkError as ServerError).statusCode === 401) {
        navigate(pages.login) // redirect page
      }
    }
  })

  const client = new ApolloClient({
    cache: memoryCache,
    link: logoutLink.concat(concat(authMiddleware, restLink)),
  })

  return (
    /*
     * BasePresentationLayer TAG is mandatory for CCL Library
     */
    <BasePresentationLayer>
      <Helmet />
      <ApolloProvider client={client}>
        <SnackbarProvider>
          <Routes />
        </SnackbarProvider>
      </ApolloProvider>
    </BasePresentationLayer>
  )
}


export { Appliance }

