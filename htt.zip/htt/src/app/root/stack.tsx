import React, { lazy } from 'react'
import { Appliance } from './appliance'
import { WindowLoading as Loading } from './loading'

const Middlewares = lazy(() => import('../middleware').then((module) => ({ default: module.Middlewares })))
function Stack() {
  return (
    <React.StrictMode>
      <Middlewares>
        <Loading>
          <Appliance />
        </Loading>
      </Middlewares>
    </React.StrictMode>
  )
}
export { Stack }
