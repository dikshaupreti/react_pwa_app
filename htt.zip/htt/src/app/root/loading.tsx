import * as React from 'react'
import { Loader } from '_ccl'
import { renderChildren } from '_modules/renderChildren'

const AppLoader = () => (
  <div style={{ display: 'flex', justifyContent: 'center', height: '100vh' }}>
    <Loader />
  </div>
)
function WindowLoading({ children }: { children: React.ReactNode }) {
  return <React.Suspense fallback={<AppLoader />}>{renderChildren(children)}</React.Suspense>
}

export { WindowLoading }
