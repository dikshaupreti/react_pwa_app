// global helmet settings
import * as React from 'react'
import { Helmet as ReactHelmet } from 'react-helmet'

export function Helmet() {
  return (
    <ReactHelmet>
      <title>Operations Portal | IDFC</title>
      <link rel="canonical" data-testid="helmet_3" href="beta.idfc.io" />
      <meta name="description" content="Operations Portal for IDFC" />
    </ReactHelmet>
  )
}
