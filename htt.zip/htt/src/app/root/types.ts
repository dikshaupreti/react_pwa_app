export interface IBulkUploadFileData {
  bulkUploadFile: File
}
