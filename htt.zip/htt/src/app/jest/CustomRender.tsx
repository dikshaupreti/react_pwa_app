/* eslint-disable no-restricted-imports */

import { render } from '@testing-library/react'
import React from 'react'
import { ThemeProvider } from 'styled-components'
// eslint-disable-next-line import/no-extraneous-dependencies
import base from '@idfc/ccl-web/themes/base'
import { MemoryRouter } from 'react-router-dom'

const appContainer = document.createElement('div')
appContainer.id = 'app'

document.body.appendChild(appContainer)

// eslint-disable-next-line react/prop-types
function CustomRenderContainer({ children }: {children : any}) {
  return (
    <MemoryRouter>
      <ThemeProvider theme={{ ...base }}>
        {children}
      </ThemeProvider>
    </MemoryRouter>
  )
}

const CustomRender = (node: any, ...options: any) => {
  const rendered = render(
    <CustomRenderContainer>{node}</CustomRenderContainer>,
    ...options,
  )

  return {
    ...rendered,
    rerender: (newUi: any) => CustomRender(
      newUi,
      {
        container: rendered.container,
        baseElement: rendered.baseElement,
      },
    ),
  }
}

// Re-export everything
export * from '@testing-library/react'
// export userEvent from '@testing-library/user-event';
// Override render method
export { CustomRender as render }

