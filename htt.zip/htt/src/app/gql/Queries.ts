// Provide resolver functions for your schema fields
const Queries = {
  hello: () => 'Hello world!',
}

export { Queries }

// getSelectedHubId: (_, {cache}) => {
//   console.log({arguments})
//   // return 'test'
//   const query = gql`
//     query getSelectedHubIdQuery {
//       tmp {
//         selectedHubId
//       }
//     }
//   `
//   return cache.readQuery({ query })
// }
