export const defaultValues = {}

export const Mutations = {}
