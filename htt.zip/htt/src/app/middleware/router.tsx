import * as React from 'react'
import { BrowserRouter } from 'react-router-dom'
import { renderChildren } from '_modules/renderChildren'

export function ApolloRouter({ children }: { children: React.ReactChild }) {
  return <BrowserRouter>{renderChildren(children)}</BrowserRouter>
}
