import { ApolloClient } from '@apollo/client'

interface IFetchBaseOptions {
  // tslint:disable-next-line: no-any
  customHeaders: any
  // tslint:disable-next-line: no-any
  queryParams?: any
  // tslint:disable-next-line: no-any
  input?: any
}

interface IFetchResponse<RESPONSE_TYPE> {
  data: RESPONSE_TYPE
}
interface IGQLQueryParams {
  // tslint:disable-next-line: no-any
  client?: ApolloClient<any>
  cacheQuery?: boolean
  endpoint?: string
  // tslint:disable-next-line: no-any
  input?: any
  method?: string
  path: string
  responseKey?: string
  responseFieldsList?: string[]
  // tslint:disable-next-line: no-any
  queryParams?: any
  // tslint:disable-next-line: no-any
  customHeaders?: any
  responseType?: string,
  content?: string
}

interface IBaseResponse {
  data: any
  status: string
}

export type {
  IBaseResponse, IFetchResponse, IFetchBaseOptions, IGQLQueryParams,
}
