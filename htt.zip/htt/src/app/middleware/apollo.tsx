/* eslint-disable react/destructuring-assignment */
/* eslint-disable no-underscore-dangle */
import { InMemoryCache } from 'apollo-cache-inmemory'
import { ApolloClient } from 'apollo-client'
import { ApolloLink } from 'apollo-link'
import { onError } from 'apollo-link-error'
import { HttpLink } from 'apollo-link-http'
import { RestLink } from 'apollo-link-rest'
import { RetryLink } from 'apollo-link-retry'
import * as React from 'react'
import { ApolloProvider } from 'react-apollo'
import { renderChildren } from '_modules/renderChildren'
// TODO
import {
  REACT_APP_CLOUD_REST_ENDPOINT
} from '_config/environment'
import { Resolvers } from '../gql'
import { errorCodes } from './errorCodes'

interface IProps {
    graphqlURL: string
    children: React.ReactNode
}

export const ApolloCache = new InMemoryCache()

export class ApolloClientProvider extends React.Component<IProps> {
  constructor(props: IProps) {
    super(props)

    const links : any = [
      this._middleware,
      this._retryLink,
      this._restLink(),
      this._errorLink,
      // this._terminatingLink,
      this._httpLink,
    ]

    this._apolloClient = new ApolloClient({
      cache: this._cache,
      connectToDevTools: true,
      // fetchOptions: { mode: 'no-cors' }, // TODO
      link: ApolloLink.from(links),
      resolvers: Resolvers,
      // typedefs: Schema, //TODO
    })
  }

  // setup your `RestLink` with your endpoint
  // eslint-disable-next-line class-methods-use-this
  handleResponse = async (response: Response) => {
    if (!response) {
      throw new Error('Response is Empty')
    }
    if (response && (response.status === 204 || response.status === 202)) {
      return { result: 'SUCCESS' }
    }
    let result = {}
    try {
      result = await response.json()
    } catch (_error) {
      result = {}
    }
    return result
  }

  // eslint-disable-next-line react/sort-comp
  private _apolloClient: ApolloClient<any> // tslint:disable-line:no-any

  private _cache = ApolloCache

  private _httpLink = new HttpLink({
    // eslint-disable-next-line react/destructuring-assignment
    uri: this.props.graphqlURL,
  })

  private _retryLink = new RetryLink({
    attempts: {
      max: 5,
      retryIf: (error, _operation) => errorCodes.includes(error.statusCode),
    },
    delay: {
      initial: 300,
      jitter: true,
      max: Infinity,
    },
  })

  // Create error handler link
  // https://github.com/apollographql/apollo-client/blob/master/docs/source/features/error-handling.md
  private _errorLink = onError(({ graphQLErrors, networkError }) => {
    if (graphQLErrors) {
      graphQLErrors.forEach(({ message, locations, path }) => {
        console.error(`[GraphQL] Message: ${message}, Location: ${locations}, Path: ${path}`)
      })
    }

    if (networkError) {
      console.error(`[Network] ${networkError}`)
    }
  })

  private _middleware = new ApolloLink((operation, forward) => {
    const customHeaders = operation?.variables?.customHeaders
    if (customHeaders) {
      // eslint-disable-next-line no-param-reassign
      delete operation.variables.customHeaders
    }
    // const token = 'test'
    // const productName = 'TM'
    operation.setContext(({ headers = {} }) => ({
      headers: {
        // 'App-Id': productName && productName.length ? productName : '',
        //  Authorization: token ? `Bearer ${token}` : '',
        // sourceApp: 'web',
        ...(customHeaders || {}),
        ...headers,
      },
    }))
    return (
      forward
            && forward(operation).map((result: any) => {
              const { restResponses } = operation.getContext()
              if (result && result.data && restResponses && (restResponses[0].status === 204 || restResponses[0].status === 202)) {
                // eslint-disable-next-line no-param-reassign
                result.data.responseHeader.statusCode = restResponses[0].status
                return result
              }
              return result
            })
    )
  })

  private _restLink = () => new RestLink({
    responseTransformer: this.handleResponse,
    uri: REACT_APP_CLOUD_REST_ENDPOINT,
  })

  public render() {
    return (
      <ApolloProvider data-test-id="apollo_2" client={this._apolloClient}>
        {renderChildren(this.props.children)}
      </ApolloProvider>
    )
  }
}
