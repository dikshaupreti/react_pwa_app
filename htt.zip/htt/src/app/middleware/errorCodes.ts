export const errorCodes: number[] = [503, 504, 521, 524]
