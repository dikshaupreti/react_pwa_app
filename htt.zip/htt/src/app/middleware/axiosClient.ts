import axios, { AxiosPromise, AxiosRequestConfig } from 'axios'
import { errorCodes } from './errorCodes'
// tslint:disable-next-line:no-var-requires
const axiosRetry = require('axios-retry')

const axiosClientActual = axios.create()
const axiosClient = (config: AxiosRequestConfig): AxiosPromise => {
  const defaultHeaders = {
    // TODO - Replace test with UseConext value
    Authorization: `Bearer ${'test'}`,
  }
  const preparedConfig = {
    ...config,
    headers: {
      ...defaultHeaders,
      ...config.headers,
    },
  }
  return axiosClientActual(preparedConfig)
}

axiosRetry(axiosClientActual, {
  retries: 5,
  retryCondition: (result: { response: { status: number } }): boolean => errorCodes.includes(result.response.status),
})

export { axiosClient }
