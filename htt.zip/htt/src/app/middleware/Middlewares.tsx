import * as React from 'react'
import { renderChildren } from '_modules/renderChildren'
import { ApolloRouter as Router } from './router'

export function Middlewares({ children }: { children: React.ReactNode }) {
  // ROUTER must come before ALL OTHER middleware
  return (
    <Router>

      <>{renderChildren(children)}</>

    </Router>
  )
}
