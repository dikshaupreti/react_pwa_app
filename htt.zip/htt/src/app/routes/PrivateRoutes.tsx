import React, { lazy } from 'react'
import { Route, Routes } from 'react-router-dom'
import { pages } from '_constants/Root/constants'


const ErrorBoundary = lazy(
  () => import('_components/ErrorBoundary').then((module) => ({ default: module.ErrorBoundary }))
)
const Page = lazy(
  () => import('_components/Page')
)

const Home = lazy(() => import('_pages/Home'))
const CustomerOverView = lazy(() => import('_pages/CustomerOverView'))
const Login = lazy(() => import('_pages/Login'))
const CustomerSearch = lazy(() => import('_pages/CustomerSearch'))
// Removed the existing loan details route
// const AccountDetails = lazy(() => import('_pages/AccountDetails'))
const CustomerDetails = lazy(() => import('_pages/CustomerDetails'))
const RequestQueueIndividual = lazy(() => import('_pages/RequestQueue/Individual'))
const RequestQueueMakerBulk = lazy(() => import('_pages/RequestQueue/BulkRequest'))
const RequestQueueCheckerIndividual = lazy(() => import('_pages/RequestQueue/Individual'))
const RequestQueueCheckerBulk = lazy(() => import('_pages/RequestQueue/BulkRequest'))
const CreateIndividualRequest = lazy(() => import('_pages/CreateRequest/IndividualRequest'))
const CreateBulkRequest = lazy(() => import('_pages/CreateRequest/BulkRequest/TemplateBulkRequest'))
// TODO temporary route for loat details template integration
const AccountDetailsTemp = lazy(() => import('_pages/AccountDetails/TemplateAccountDetailsLeftNav'))
const PageNotFound = lazy(() => import('_pages/PageNotFound'))
const CustomerOneView = lazy(() => import('_pages/CustomerOneView'))
const CustomerDocumentView = lazy(() => import('_pages/CustomerDocumentView'))
const BulkRequestDetails = lazy(() => import('_pages/RequestDetails/Bulk'))
const PDERequestDetails = lazy(() => import('_pages/RequestDetails/Individual/PDERequestDetails'))
const TransactionViewer = lazy(() => import('_pages/TransactionViewer'))
const PDEMultiAccount = lazy(() => import('_pages/CreateRequest/IndividualRequest/PDE/MultiAccount'))
// TODO: once integration done will remove url if not needed

export const Routers = [
  {
    path: '/',
    component: Login,
    name: 'Login',
    isLeftNavBarVisible: false,
    isHeaderVisible: true,
  },
  {
    path: '*',
    component: PageNotFound,
    name: 'PageNotFound',
    isLeftNavBarVisible: false,
    isHeaderVisible: true,
  },
  {
    path: pages.login,
    component: Login,
    name: 'Login',
    isLeftNavBarVisible: false,
    isHeaderVisible: true,
  },
  {
    path: pages.home,
    component: Home,
    name: 'Home',
    isLeftNavBarVisible: true,
    isHeaderVisible: true,
  },
  {
    path: pages.customerSearch,
    component: CustomerSearch,
    name: 'CustomerSearch',
    isLeftNavBarVisible: true,
    isHeaderVisible: true,
  },
  {
    path: pages.overview,
    component: CustomerOverView,
    name: 'CustomerOverView',
    isLeftNavBarVisible: true,
    isHeaderVisible: true,
  },
  {
    path: pages.details,
    component: CustomerDetails,
    name: 'CustomerDetails',
    isLeftNavBarVisible: true,
    isHeaderVisible: true,
  },
  // remove the existing route
  // {
  //   path: pages.accountDetails,
  //   component: AccountDetails,
  //   name: 'AccountDetails',
  //   isLeftNavBarVisible: true,
  //   isHeaderVisible: true,
  // },
  {
    path: pages.accountDetails,
    component: AccountDetailsTemp,
    name: 'AccountDetailsTemp',
    isLeftNavBarVisible: true,
    isHeaderVisible: true,
  },
  {
    path: pages.requestQueueIndividual,
    component: RequestQueueIndividual,
    name: 'RequestQueueIndividual',
    isLeftNavBarVisible: true,
    isHeaderVisible: true,
  },
  {
    path: pages.requestQueueBulk,
    component: RequestQueueMakerBulk,
    name: 'RequestQueueMakerBulk',
    isLeftNavBarVisible: true,
    isHeaderVisible: true,
  },
  {
    path: pages.createIndividualRequest,
    component: CreateIndividualRequest,
    name: 'CreateIndividualRequest',
    isLeftNavBarVisible: true,
    isHeaderVisible: true,
  },
  {
    path: pages.authorizeRequestIndividual,
    component: RequestQueueCheckerIndividual,
    name: 'RequestQueueCheckerIndividual',
    isLeftNavBarVisible: true,
    isHeaderVisible: true,
  },
  {
    path: pages.createBulkRequest,
    component: CreateBulkRequest,
    name: 'CreateBulkRequest',
    isLeftNavBarVisible: true,
    isHeaderVisible: true,
  },
  // commented the existing route
  // {
  //   path: pages.accountDetailsTemp,
  //   component: AccountDetailsTemp,
  //   name: 'AccountDetailsTemp',
  //   isLeftNavBarVisible: true,
  //   isHeaderVisible: true,
  // },

  {
    path: pages.authorizeRequestBulk,
    component: RequestQueueCheckerBulk,
    name: 'RequestQueueCheckerBulk',
    isLeftNavBarVisible: true,
    isHeaderVisible: true,
  },
  {
    path: pages.customerOneView,
    component: CustomerOneView,
    name: 'CustomerOneView',
    isLeftNavBarVisible: true,
    isHeaderVisible: true,
  },
  {
    path: pages.customerDocumentView,
    component: CustomerDocumentView,
    name: 'CustomerDocumentView',
    isLeftNavBarVisible: true,
    isHeaderVisible: true,
  },
  {
    path: pages.BulkRequestDetails,
    component: BulkRequestDetails,
    name: 'BulkRequestDetails',
    isLeftNavBarVisible: true,
    isHeaderVisible: true,
  },
  {
    path: pages.PDERequestDetails,
    component: PDERequestDetails,
    name: 'PDERequestDetails',
    isLeftNavBarVisible: true,
    isHeaderVisible: true,
  },
  {
    path: pages.TransactionViewer,
    component: TransactionViewer,
    name: 'TransactionViewer',
    isLeftNavBarVisible: true,
    isHeaderVisible: true
  },
  {
    path: pages.PDEMultiAccount,
    component: PDEMultiAccount,
    name: 'MultiAccount',
    isLeftNavBarVisible: true,
    isHeaderVisible: true,
  }
]

function PrivateRoutes() {
  return (
    <Page>
      <Routes>
        {
            Routers.map(
              ({
                path, component: Comp
              }) => (
                <Route
                  key={path}
                  path={path}
                  element={<ErrorBoundary><Comp /></ErrorBoundary>}
                />
              )
            )
         }
      </Routes>
    </Page>
  )
}
export { PrivateRoutes }

