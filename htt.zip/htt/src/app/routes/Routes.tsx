
import React, { lazy, useContext, useEffect } from 'react'
import { Route, Routes, useNavigate } from 'react-router-dom'
import { Container } from '_components/CommonStyle.styles'
import { useSnackbar } from '_components/Snackbar/SnackbarProvider'
import { REACT_APP_BUILD_TARGET } from '_config/environment'
import { isLoggedIn, RIGHT_CLICK_TEXT } from '_constants/constants'
import { pages } from '_constants/Root/constants'
import { OpsContext } from '_context/OpsContext'
import { PrivateRoutes } from './PrivateRoutes'

const Login = lazy(() => import('_pages/Login'))
const Header = lazy(
  () => import('_components/Header').then((module) => ({ default: module.Header }))
)
function RoutesComp() {
  const { showSnackbar } = useSnackbar()
  const navigate = useNavigate()
  const { JWT } = useContext(OpsContext)

  // handle if context empty if technical glitch or
  // page refresh then redirect to login page

  useEffect(() => {
    if (!JWT) {
      navigate(pages.login)
    }
  }, [JWT])

  const handleContextmenu = (e: any) => {
    if (REACT_APP_BUILD_TARGET === RIGHT_CLICK_TEXT.PRODUCTION) {
      showSnackbar({ title: RIGHT_CLICK_TEXT.SORRY_TEXT, subTitle: RIGHT_CLICK_TEXT.MSG })
      e.preventDefault()
    }
  }
  if (isLoggedIn) {
    return (
      <div onContextMenu={(e) => handleContextmenu(e)}>
        <PrivateRoutes />
      </div>
    )
  }

  return (
    <div>
      <Header />
      <Container>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="*" element={<Login />} />
        </Routes>
      </Container>
    </div>
  )
}

export { RoutesComp }
