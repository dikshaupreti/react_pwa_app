import React from 'react'
import { PrivateRoutes } from './PrivateRoutes'

describe('Unit testing for <PrivateRoutes> component', () => {
  beforeEach(() => {
    jest.clearAllTimers()
    jest.clearAllMocks()
  })
  it('Page Component Should be defined ', () => {
    expect(<PrivateRoutes />).toBeDefined()
  })
  test('Page Component Should be defined ', () => {
    expect(<PrivateRoutes />).toBeDefined()
  })
})
