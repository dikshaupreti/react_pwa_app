const THEME_NAMES = { LIGHT: 'LIGHT', DARK: 'DARK', SYSTEM: 'SYSTEM' }
const THEME_NAME = 'themeName'
const SCREEN_NAMES = {
  THEME_OPTIONS: 'CDS_SwitchTheme_ThemeOptions',
}

export { THEME_NAMES, THEME_NAME, SCREEN_NAMES }
