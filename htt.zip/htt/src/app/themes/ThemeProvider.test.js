import React, { useContext } from 'react'
import { Button, Text } from '_ccl'
import { getLocalStorage, setLocalStorage } from '_helpers/storageHelpers'
import { act, fireEvent, render } from '_jest/CustomRender'
import '../../../tests/mocks/matchMedia'
import ThemeProvider from './ThemeProvider'
import { THEME_NAME, THEME_NAMES } from './ThemesConstants'
import ThemesContext from './ThemesContext'

jest.mock('app/helpers/storageHelpers', () => ({
  setLocalStorage: jest.fn(),
  getLocalStorage: jest.fn(),
}))

describe('ThemeProvider', () => {
  function TestComponent() {
    const { selectedThemeName, setSelectedThemeName, isDarkMode } = useContext(ThemesContext)

    return (
      <>
        <Button
          data-testid="lightTheme"
          onClick={() => {
            setSelectedThemeName(THEME_NAMES.LIGHT)
          }}
        >
          Light
        </Button>
        <Button
          data-testid="darkTheme"
          onClick={() => {
            setSelectedThemeName(THEME_NAMES.DARK)
          }}
        >
          Dark
        </Button>
        <Button
          data-testid="systemTheme"
          onClick={() => {
            setSelectedThemeName(THEME_NAMES.SYSTEM)
          }}
        >
          System
        </Button>
        <Text data-testid="selected-theme">{selectedThemeName}</Text>
        <Text data-testid="dark-mode-status">{isDarkMode.toString()}</Text>
      </>
    )
  }

  afterEach(() => {
    setLocalStorage.mockClear()
    getLocalStorage.mockClear()
  })

  it('should set the value of context based on the click of respective theme button', async () => {
    const { getByTestId } = render(
      <ThemeProvider>
        <TestComponent />
      </ThemeProvider>,
    )

    expect(getLocalStorage).toHaveBeenCalledWith(THEME_NAME)
    expect(getByTestId('selected-theme')).toHaveTextContent(THEME_NAMES.LIGHT)

    act(() => {
      fireEvent.click(getByTestId('lightTheme'))
    })

    expect(setLocalStorage).toHaveBeenCalledWith(THEME_NAME, THEME_NAMES.LIGHT)
    expect(getByTestId('selected-theme')).toHaveTextContent(THEME_NAMES.LIGHT)
    expect(getByTestId('dark-mode-status')).toHaveTextContent('false')

    act(() => {
      fireEvent.click(getByTestId('darkTheme'))
    })
    expect(setLocalStorage).toHaveBeenCalledWith(THEME_NAME, THEME_NAMES.DARK)
    expect(getByTestId('selected-theme')).toHaveTextContent(THEME_NAMES.DARK)
    expect(getByTestId('dark-mode-status')).toHaveTextContent('true')

    act(() => {
      fireEvent.click(getByTestId('systemTheme'))
    })
    expect(setLocalStorage).toHaveBeenCalledWith(THEME_NAME, THEME_NAMES.SYSTEM)
    expect(getByTestId('selected-theme')).toHaveTextContent(THEME_NAMES.SYSTEM)
    expect(getByTestId('dark-mode-status')).toHaveTextContent('false')
  })

  it('should set fallback theme in local storage if feature toggle is off', async () => {
    render(
      <ThemeProvider>
        <TestComponent />
      </ThemeProvider>,
    )

    expect(setLocalStorage).toHaveBeenCalledWith(THEME_NAME, THEME_NAMES.LIGHT)
  })
})
