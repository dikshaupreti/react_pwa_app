import { deepCheckObjectKeys, hasOwnProperty, isObject } from '_ccl'
import WEB_THEMES from './Json/index'
import THEME_CONFIG from './ThemeConfig'

const { baseTheme, darkTheme } = WEB_THEMES

describe('themes', () => {
  const baseThemeKeys = Object.keys(baseTheme)
  const darkThemeKeys = Object.keys(darkTheme)

  it('should return true when base and dark theme has equal keys by shallow comparison', () => {
    expect(baseThemeKeys).toHaveLength(darkThemeKeys.length)
  })

  it.each(baseThemeKeys)(
    'should return true when the key %p and its nested keys are present in both baseTheme and darkTheme',
    (key) => {
      if (isObject(baseTheme[key])) {
        expect(deepCheckObjectKeys(baseTheme[key], darkTheme[key])).toBe(true)
      } else {
        expect(hasOwnProperty(baseTheme, key)).toBe(true)
        expect(hasOwnProperty(darkTheme, key)).toBe(true)
      }
    },
  )
})

describe('merged Themes', () => {
  const mergedThemekeys = Object.keys(THEME_CONFIG)
  it.each(mergedThemekeys)('should match %p json snapshots', (key) => {
    expect(THEME_CONFIG[key]).toMatchSnapshot()
  })
})
