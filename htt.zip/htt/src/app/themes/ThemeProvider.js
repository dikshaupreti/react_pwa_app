import PropTypes from 'prop-types'
import React, { useEffect, useState } from 'react'
import { ThemeProvider } from 'styled-components'
import { getLocalStorage, setLocalStorage } from '_helpers/storageHelpers'
import THEME_CONFIG from './ThemeConfig'
import { THEME_NAME, THEME_NAMES } from './ThemesConstants'
import ThemesContext from './ThemesContext'

const DEFAULT_THEME_NAME = THEME_NAMES.LIGHT

function ThemeContextProvider({ children }) {
  const mediaQuery = window?.matchMedia('(prefers-color-scheme: dark)')
  const initialSystemThemeName = mediaQuery.matches ? THEME_NAMES.DARK : THEME_NAMES.LIGHT
  const currentTheme = getLocalStorage(THEME_NAME)

  const [selectedThemeName, setSelectedThemeName] = useState(currentTheme || DEFAULT_THEME_NAME)
  const [currentSystemThemeName, setCurrentSystemThemeName] = useState(initialSystemThemeName)

  const onSystemThemeChange = () => {
    if (mediaQuery.matches) {
      setCurrentSystemThemeName(THEME_NAMES.DARK)
    } else {
      setCurrentSystemThemeName(THEME_NAMES.LIGHT)
    }
  }

  useEffect(() => {
    if (mediaQuery.addEventListener) {
      mediaQuery.addEventListener('change', onSystemThemeChange)
    } else {
      mediaQuery.addListener(onSystemThemeChange)
    }
    return () => {
      if (mediaQuery.removeEventListener) {
        mediaQuery.removeEventListener('change', onSystemThemeChange)
      } else {
        mediaQuery.removeListener(onSystemThemeChange)
      }
    }
  }, [mediaQuery, onSystemThemeChange])

  useEffect(() => {
    setLocalStorage(THEME_NAME, selectedThemeName)
  }, [selectedThemeName])

  // eslint-disable-next-line max-len
  const selectedThemeData = selectedThemeName === THEME_NAMES.SYSTEM ? THEME_CONFIG[currentSystemThemeName] : THEME_CONFIG[selectedThemeName]

  const isDarkMode = selectedThemeName === THEME_NAMES.SYSTEM
    ? currentSystemThemeName === THEME_NAMES.DARK
    : selectedThemeName === THEME_NAMES.DARK

  return (
    // eslint-disable-next-line react/jsx-no-constructed-context-values
    <ThemesContext.Provider value={{ selectedThemeName, setSelectedThemeName, isDarkMode }}>
      <ThemeProvider data-testid="theme-provider" theme={selectedThemeData}>
        {children}
      </ThemeProvider>
    </ThemesContext.Provider>
  )
}

ThemeContextProvider.propTypes = {
  children: PropTypes.element,
}

ThemeContextProvider.defaultProps = {
  children: null,
}

export default ThemeContextProvider
