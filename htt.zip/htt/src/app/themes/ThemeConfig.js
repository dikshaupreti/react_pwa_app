import { ALL_THEMES } from '_ccl'
// eslint-disable-next-line import/no-extraneous-dependencies
import merge from 'lodash.merge'
import WEB_THEMES from './Json'
import { THEME_NAMES } from './ThemesConstants'

const THEME_CONFIG = {
  [THEME_NAMES.DARK]: merge(ALL_THEMES.dark, WEB_THEMES.darkTheme),
  [THEME_NAMES.LIGHT]: merge(ALL_THEMES.base, WEB_THEMES.baseTheme),
}

export default THEME_CONFIG
