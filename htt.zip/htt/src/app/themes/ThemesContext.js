import { createContext } from 'react'

const ThemesContext = createContext({})

export default ThemesContext
