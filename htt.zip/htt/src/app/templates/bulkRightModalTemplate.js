export const rightModalTemplate = {
  product: {
    id: 'prodid',
    name: 'ACEPL',
    source: 'OPPS',
    action: 'bulkupload',
    templateName: 'bulkRightModalTemplate',
    section: [
      {
        name: 'bulkUploadModalHeader',
        type: 'headerText',
        field: [
          {
            name: 'bulkUploadModalTitle',
            type: 'header',
            value: 'Freeze & Unfreeze Code Master'
          }
        ]
      },
      {
        name: 'bulkUploadModalRight',
        type: 'rightContainer',
        field: [
          {
            name: 'CrossSmall',
            type: 'buttonIcon',
            metadata: {
              type: 'cancel'
            }
          }
        ]
      },
      {
        name: 'freezeTab',
        type: 'tabs',
        field: [
          {
            name: 'freezeTab',
            type: 'tab',
            value: 'Freeze',
            metadata: {
              columnName: [
                'Reason',
                'Code'
              ]
            }
          },
          {
            name: 'unFreezeTab',
            type: 'tab',
            value: 'UnFreeze',
            metadata: {
              columnName: [
                'Reason',
                'Code'
              ]
            }
          }
        ]
      }
    ]
  }
}
