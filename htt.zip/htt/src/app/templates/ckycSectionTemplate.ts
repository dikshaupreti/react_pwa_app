export const ckycSectionTemplate = {
  product: {
    id: 'prodid',
    name: 'ACEPL',
    source: 'OPPS',
    action: 'ckycSecrionDetailsData',
    templateName: 'ckycSectionTemplate',
    section: [
      {
        name: 'customerInformationDetails',
        type: 'customerInfo',
        field: [
          {
            name: 'avatar',
            type: 'Avatar',
            value: '#{avatar}'
          },
          {
            name: 'customerName',
            type: 'titleSubtitle',
            value: 'Customer Name',
            metadata: {
              subTitle: '#{customerName}',
              type: 'primary'
            }
          },
          {
            name: 'accountNumber',
            type: 'titleSubtitle',
            value: 'Account Number',
            metadata: {
              subTitle: '#{accountNumber}',
              type: 'primary'
            }
          },
          {
            name: 'accountType',
            type: 'titleSubtitle',
            value: 'Account Type',
            metadata: {
              subTitle: '#{accountType}',
              type: 'primary'
            }
          },
          {
            name: 'accountOpeningDate',
            type: 'titleSubtitle',
            value: 'Account Opening Date',
            metadata: {
              subTitle: '#{accountOpeningDate}',
              type: 'primary'
            }
          },
          {
            name: 'status',
            type: 'titleSubtitle',
            value: 'Status',
            metadata: {
              subTitle: '#{status}', //Active
              type: 'secondary',
            }
          },
          {
            name: 'branchId',
            type: 'titleSubtitle',
            value: 'Branch ID',
            metadata: {
              subTitle: '#{branchId}',
              type: 'primary'
            }
          },
          {
            name: 'branchName',
            type: 'titleSubtitle',
            value: 'Branch Name',
            metadata: {
              subTitle: '#{branchName}',
              type: 'primary'
            }
          }
        ]
      },
      // ckyc details
      {
        name: 'ckycDetailsAccordion',
        type: 'accordion',
        value: 'CKYC Details',
        field: [
          {
            name: 'ckycNumber',
            type: 'textInput',
            placeHolder: 'CKYC No',
            value: '#{ckycNumber}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'acknowledgementNumber',
            type: 'textInput',
            placeHolder: 'Acknowledgement No',
            value: '#{acknowledgementNumber}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'ckycExpiryDate',
            type: 'textInput',
            placeHolder: 'CKYC Expiry Date',
            value: '#{ckycExpiryDate}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'ckycLastVerifyDate',
            type: 'textInput',
            placeHolder: 'CKYC Last Verify Date',
            value: '#{ckycLastVerifyDate}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'ckycOccupation',
            type: 'textInput',
            placeHolder: 'CKYC Occupation',
            value: '#{ckycOccupation}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'ckycUpdatesPOI',
            type: 'textInput',
            placeHolder: 'CKYC Updated POI',
            value: '#{ckycUpdatesPOI}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'ckycUpdatesPOA',
            type: 'textInput',
            placeHolder: 'CKYC Updated POA',
            value: '#{ckycUpdatesPOA}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'ckycReopeningDate',
            type: 'textInput',
            placeHolder: 'CKYC Reopening Date',
            value: '#{ckycReopeningDate}',
            metadata: {
              disabled: true,
            }
          },
        ],
      },
      // personal
      {
        name: 'personalDetailsAccordion',
        type: 'accordion',
        value: 'Personal Details',
        field: [
          {
            name: 'customerType',
            type: 'textInput',
            placeHolder: 'Customer Type',
            value: '#{customerType}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'applicantName',
            type: 'textInput',
            placeHolder: 'Applicant Name',
            value: '#{applicantName}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'dateOfBirth',
            type: 'textInput',
            placeHolder: 'Date of Birth',
            value: '#{dateOfBirth}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'gender',
            type: 'textInput',
            placeHolder: 'Gender',
            value: '#{gender}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'placeOfBirth',
            type: 'textInput',
            placeHolder: 'Place of Birth',
            value: '#{placeOfBirth}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'maritalStatus',
            type: 'textInput',
            placeHolder: 'Marital Status',
            value: '#{maritalStatus}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'citizenship',
            type: 'textInput',
            placeHolder: 'Citizenship',
            value: '#{citizenship}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'nationality',
            type: 'textInput',
            placeHolder: 'Nationality',
            value: '#{nationality}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'educationalQualification',
            type: 'textInput',
            placeHolder: 'Educational Qualification',
            value: '#{educationalQualification}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'occupationType',
            type: 'textInput',
            placeHolder: 'Occupation Type',
            value: '#{occupationType}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'maidenName',
            type: 'textInput',
            placeHolder: 'Maiden Name',
            value: '#{maidenName}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'fatherFirstName',
            type: 'textInput',
            placeHolder: 'Father\'s Name',
            value: '#{fatherFirstName}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'spouseFirstName',
            type: 'textInput',
            placeHolder: 'Spouse\'s First Name',
            value: '#{spouseFirstName}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'motherFirstName',
            type: 'textInput',
            placeHolder: 'Mother\'s First Name',
            value: '#{motherFirstName}',
            metadata: {
              disabled: true,
            }
          },
        ],
      },
      // address
      {
        name: 'addressDetailsAccordion',
        type: 'accordionTab',
        value: 'Address',
        tab: [
          {
            name: 'correspondanceAddress',
            type: 'tab',
            value: 'Correspondance Address',
            field: [
              {
                name: 'correspondanceAddressType',
                type: 'textInput',
                placeHolder: 'Correspondance Address Type',
                value: '#{correspondanceAddressType}',
                metadata: {
                  disabled: true,
                }
              },
              {
                name: 'correspondanceAddressLine1',
                type: 'textInput',
                placeHolder: 'Correspondance Address Line 1',
                value: '#{correspondanceAddressLine1}',
                metadata: {
                  disabled: true,
                }
              },
              {
                name: 'correspondanceAddressLine2',
                type: 'textInput',
                placeHolder: 'Correspondance Address Line 2',
                value: '#{correspondanceAddressLine2}',
                metadata: {
                  disabled: true,
                }
              },
              {
                name: 'correspondanceCity',
                type: 'textInput',
                placeHolder: 'Correspondance City',
                value: '#{correspondanceCity}',
                metadata: {
                  disabled: true,
                }
              },
              {
                name: 'correspondanceDistrict',
                type: 'textInput',
                placeHolder: 'Correspondance District',
                value: '#{correspondanceDistrict}',
                metadata: {
                  disabled: true,
                }
              },
              {
                name: 'correspondanceState',
                type: 'textInput',
                placeHolder: 'Correspondacne State',
                value: '#{correspondanceState}',
                metadata: {
                  disabled: true,
                }
              },
              {
                name: 'correspondancePinCode',
                type: 'textInput',
                placeHolder: 'Correspondance Pin Code',
                value: '#{correspondancePinCode}',
                metadata: {
                  disabled: true,
                }
              },
              {
                name: 'correspondanceCountry',
                type: 'textInput',
                placeHolder: 'Correspondance Country',
                value: '#{correspondanceCountry}',
                metadata: {
                  disabled: true,
                }
              }
            ]
          },
          {
            name: 'permanentAddress',
            type: 'tab',
            value: 'Permanent Address',
            field: [
              {
                name: 'permanentAddressType',
                type: 'textInput',
                placeHolder: 'Permanent Address Type',
                value: '#{permanentAddressType}',
                metadata: {
                  disabled: true,
                }
              },
              {
                name: 'permanentAddressLine1',
                type: 'textInput',
                placeHolder: 'Permanent Address Line 1',
                value: '#{permanentAddressLine1}',
                metadata: {
                  disabled: true,
                }
              },
              {
                name: 'permanentAddressLine2',
                type: 'textInput',
                placeHolder: 'Permanent Address Line 2',
                value: '#{permanentAddressLine2}',
                metadata: {
                  disabled: true,
                }
              },
              {
                name: 'permanentCity',
                type: 'textInput',
                placeHolder: 'Permanent City',
                value: '#{permanentCity}',
                metadata: {
                  disabled: true,
                }
              },
              {
                name: 'permanentDistrict',
                type: 'textInput',
                placeHolder: 'Permanent District',
                value: '#{permanentDistrict}',
                metadata: {
                  disabled: true,
                }
              },
              {
                name: 'permanentState',
                type: 'textInput',
                placeHolder: 'Permanent State',
                value: '#{permanentState}',
                metadata: {
                  disabled: true,
                }
              },
              {
                name: 'permanentPinCode',
                type: 'textInput',
                placeHolder: 'Permanent Pin Code',
                value: '#{permanentPinCode}',
                metadata: {
                  disabled: true,
                }
              },
              {
                name: 'permanentCountry',
                type: 'textInput',
                placeHolder: 'Permanent Country',
                value: '#{permanentCountry}',
                metadata: {
                  disabled: true,
                }
              }
            ]
          }
        ]
      },
      // contact details
      {
        name: 'contactDetailsAccordion',
        type: 'accordion',
        value: 'Contact Details',
        field: [
          {
            name: 'mobileNumber1',
            type: 'textInput',
            placeHolder: 'Mobile Number 1',
            value: '#{mobileNumber1}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'mobileNumber2',
            type: 'textInput',
            placeHolder: 'Mobile Number 2',
            value: '#{mobileNumber2}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'telOff',
            type: 'textInput',
            placeHolder: 'Tel (Off)',
            value: '#{telOff}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'telRes',
            type: 'textInput',
            placeHolder: 'Tel (Res)',
            value: '#{telRes}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'personalEmailId',
            type: 'textInput',
            placeHolder: 'Personal Email ID',
            value: '#{personalEmailId}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'officeEmailId',
            type: 'textInput',
            placeHolder: 'Office Email ID',
            value: '#{officeEmailId}',
            metadata: {
              disabled: true,
            }
          },
        ],
      },
      // kyc details
      {
        name: 'kycDetailsAccordion',
        type: 'accordion',
        value: 'KYC Details',
        field: [
          {
            name: 'panNumber',
            type: 'textInput',
            placeHolder: 'PAN',
            value: '#{panNumber}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'panStatus',
            type: 'textInput',
            placeHolder: 'PAN Status',
            value: '#{panStatus}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'aadharNumber',
            type: 'textInput',
            placeHolder: 'Aadhar Number',
            value: '#{aadharNumber}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'drivingLicenseNumber',
            type: 'textInput',
            placeHolder: 'Driving License No',
            value: '#{drivingLicenseNumber}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'drivingLicenseExpiryDate',
            type: 'textInput',
            placeHolder: 'Driving License Expiry Date',
            value: '#{drivingLicenseExpiryDate}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'voterIdNo',
            type: 'textInput',
            placeHolder: 'Voter Id No',
            value: '#{voterIdNo}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'passportNumber',
            type: 'textInput',
            placeHolder: 'Passport No',
            value: '#{passportNumber}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'passportExpiryDate',
            type: 'textInput',
            placeHolder: 'Passport Expiry Date',
            value: '#{passportExpiryDate}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'naregaJobCard',
            type: 'textInput',
            placeHolder: 'Narega Job Card',
            value: '#{naregaJobCard}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'kycStatus',
            type: 'textInput',
            placeHolder: 'KYC Status',
            value: '#{kycStatus}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'kycDocumentType',
            type: 'textInput',
            placeHolder: 'KYC Document Type',
            value: '#{kycDocumentType}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'kycWaiverId',
            type: 'textInput',
            placeHolder: 'KYC Waiver Id',
            value: '#{kycWaiverId}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'ovdCaptured',
            type: 'textInput',
            placeHolder: 'OVD Captured',
            value: '#{ovdCaptured}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'kycDigitalDocs',
            type: 'textInput',
            placeHolder: 'KYC Digital Docs',
            value: '#{kycDigitalDocs}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'kycPhysicalDocs',
            type: 'textInput',
            placeHolder: 'KYC Physical Docs',
            value: '#{kycPhysicalDocs}',
            metadata: {
              disabled: true,
            }
          },
        ],
      },
      // kyc verifiers
      {
        name: 'kycVerifiersDetailsAccordion',
        type: 'accordion',
        value: 'KYC Verifiers Details',
        field: [
          {
            name: 'osvDate',
            type: 'textInput',
            placeHolder: 'OSV Date',
            value: '#{osvDate}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'osvEmployeeName',
            type: 'textInput',
            placeHolder: 'OSV Employee Name',
            value: '#{osvEmployeeName}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'osvEmployeeCode',
            type: 'textInput',
            placeHolder: 'OSV Employee Code',
            value: '#{osvEmployeeCode}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'osvEmployeeDesignation',
            type: 'textInput',
            placeHolder: 'OSV Employee Designation',
            value: '#{osvEmployeeDesignation}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'osvEmployeeBranch',
            type: 'textInput',
            placeHolder: 'OSV Employee Branch',
            value: '#{osvEmployeeBranch}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'institutionName',
            type: 'textInput',
            placeHolder: 'Institution Name',
            value: '#{institutionName}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'institutionCode',
            type: 'textInput',
            placeHolder: 'Institution Code',
            value: '#{institutionCode}',
            metadata: {
              disabled: true,
            }
          },
        ]
      },
    ]
  }
}

