export const bulkUploadTemplateOne = {
  product: {
    id: 'prodid',
    name: 'ACEPL',
    source: 'OPPS',
    action: 'bulkupload',
    templateName: 'bulkuploadTemplateOne',
    section: [
      {
        name: 'bulkUploadHeader',
        type: 'headerText',
        field: [
          {
            name: 'debitFreezeeUnfreezeTitle',
            type: 'header',
            value: 'Debit Freeze & Unfreeze'
          }
        ]
      },

      {
        name: 'bulkUploadRightText',
        type: 'rightText',
        field: [
          {
            name: 'downLoadSample',
            type: 'downLoad',
            value: 'Download Sample',
            metadata: {
              endPoint: 'downloadFile/Download_Sample_DebitFreeze.xlsx',
              method: 'POST'
            }
          },
          {
            name: 'codeMasterHelp',
            type: 'link',
            value: 'Code Master Help',
            metadata: {
              type: 'primary',
              endPoint: '/help',
              method: 'POST'
            }
          }
        ]
      },

      {
        name: 'bulkUploadInputText',
        type: 'inputTextData',
        field: [
          {
            name: 'noOfRecords',
            type: 'numberInput',
            value: '',
            placeHolder: 'Enter number of records in the file',
            metadata: {
            },
            validation: [
              {
                type: 'maxLength',
                pattern: '6',
                message: 'Max 100000 allowed'
              },
              {
                type: 'max',
                pattern: '100000',
                message: 'No of records should not be more than 100000'
              },
            ],
          },
          {
            name: 'submit',
            type: 'button',
            value: 'Submit',
            metadata: {
              type: 'primary',
              disabled: true,
              displayRule: [
                {
                  rule: "fieldMap?.get('noOfRecords')?.length>0",
                  disabled: false
                },
                {
                  rule: "fieldMap?.get('noOfRecords')?.length===0",
                  disabled: true
                }
              ]
            },
          }
        ],
        displayRule: [
          {
            rule: "fieldMap?.get('isCountSet')",
            display: false
          },
          {
            rule: "fieldMap?.get('isCountSet')",
            display: true
          }
        ]
      },

      {
        name: 'recordCountText',
        type: 'fileCount',
        field: [
          {
            name: 'noOfRecordsLabel',
            type: 'label',
            value: 'Number of records in file :',
            metadata: {
              type: 'primary',
            }
          },
          {
            name: 'inputValue',
            type: 'label',
            value: 'fieldMap?.get("noOfRecords")',
            metadata: {
              type: 'primaryBoldMedium',
              isExpression: true
            }
          },
          {
            name: 'edit',
            type: 'link',
            value: 'Edit',
            metadata: {
              type: 'primary',
              displayRule: [
                {
                  rule: "fieldMap?.get('isUploading')",
                  display: false
                },
                {
                  rule: "!fieldMap?.get('isUploading')",
                  display: true
                }
              ]
            }
          }
        ],
        displayRule: [
          {
            rule: "fieldMap?.get('isCountSet')",
            display: true
          },
          {
            rule: "!fieldMap?.get('isCountSet')",
            display: false
          }
        ]
      },

      {
        name: 'bulkUploadZone',
        type: 'dragZone',
        field: [
          {
            name: 'dragYourFile',
            type: 'dragAndDrop',
            value: '',
            metadata: {
              type: '',
            }
          },
          {
            name: 'dragYourFile',
            type: 'label',
            value: 'Drag your file here',
            metadata: {
              type: 'tertiaryLarge',
            }
          },
          {
            name: 'dragYourFileDescription',
            type: 'label',
            value: 'Or, you can browse and select the file',
            metadata: {
              type: 'primary',
            }
          },
          {
            name: 'browseFile',
            type: 'button',
            value: 'Browse File',
            metadata: {
              supportingFormat: ['.xls', '.xlsx'],
            },
          },
          {
            name: 'dragYourFileDescription',
            type: 'label',
            value: 'Only .xls, .xlsx format allowed',
            metadata: {
              type: 'tertiary',
            }
          },
        ],
        displayRule: [
          {
            rule: "fieldMap?.get('isUploading')",
            display: false
          },
          {
            rule: "!fieldMap?.get('isUploading') && fieldMap?.get('isCountSet')",
            display: true
          }
        ]
      },

      {
        name: 'proceedPrompt',
        type: 'waitForUploadLabel',
        field: [
          {
            name: 'waitForUpload',
            type: 'label',
            value: 'Please wait. File upload is under progress.',
            metadata: {
              type: 'primaryBoldLarge',
            }
          }
        ],
        displayRule: [
          {
            rule: "!fieldMap?.get('isUploading')",
            display: false
          },
          {
            rule: "fieldMap?.get('isUploading')",
            display: true
          }
        ]
      },

      {
        name: 'uploadingInprogress',
        type: 'uploadProcess',
        field: [
          {
            name: 'icon',
            type: 'fileIcon',
            value: 'EXCEL',
          },
          {
            name: 'fileName',
            type: 'label',
            value: 'fieldMap?.get("browseFile")?.docName',
            metadata: {
              type: 'primaryBoldMedium',
              isExpression: true
            }
          },
          {
            name: 'fileSize',
            type: 'label',
            value: 'fieldMap?.get("browseFile")?.actualSize',
            metadata: {
              type: 'tertiaryBoldMedium',
              isExpression: true
            }
          },
          {
            name: 'cancelUpload',
            type: 'buttonIcon',
            value: 'CrossSmall'
          },
          {
            name: 'progressBar',
            type: 'progressBar',
            value: '',
          }
        ],
        displayRule: [
          {
            rule: "fieldMap?.get('isUploading')",
            display: true
          },
          {
            rule: "!fieldMap?.get('isUploading')",
            display: false
          }
        ]
      },

      {
        name: 'inputFileParameters',
        type: 'fileParameterInfo',
        field: [
          {
            name: 'noOfRecordsLabel',
            type: 'label',
            value: 'Number of Records Required: '
          },
          {
            name: 'noOfRecordsValue',
            type: 'label',
            value: 'fieldMap?.get("noOfRecords")',
            metadata: {
              type: 'primaryBoldMedium',
              isExpression: true
            }
          }
        ]
      },

      {
        name: 'uploadedFile',
        type: 'uploadedFileInfo',
        field: [
          {
            name: 'icon',
            type: 'fileIcon',
            value: 'EXCEL'
          },
          {
            name: 'title',
            type: 'label',
            value: 'fieldMap?.get("browseFile")?.docName',
            metadata: {
              type: 'primaryBoldLarge',
              isExpression: true
            }
          },
        ],
        displayRule: [
          {
            rule: "fieldMap?.get('isUploadSuccessfull')",
            display: true
          },
          {
            rule: "!fieldMap?.get('isUploadSuccessfull')",
            display: false
          }
        ]
      },

      {
        name: 'uploadedFile',
        type: 'uploadedFileAction',
        field: [
          {
            name: 'fileRemove',
            type: 'buttonIcon',
            value: 'Delete2'
          }
        ],
        displayRule: [
          {
            rule: "fieldMap?.get('isUploadSuccessfull')",
            display: true
          },
          {
            rule: "!fieldMap?.get('isUploadSuccessfull')",
            display: false
          }
        ]
      },

      {
        name: 'validationPrompt',
        type: 'validateLabelAction',
        field: [
          {
            name: 'validatePromptLabel',
            type: 'label',
            value: 'Please validate the file to proceed further.',
            metadata: {
              type: 'primaryBoldMedium'
            }
          },
          {
            name: 'validateBtn',
            type: 'button',
            value: 'Validate',
            metadata: {
              type: 'primary',
              endPoint: '/bulk/validate',
              method: 'POST'
            }
          }
        ],
        displayRule: [
          {
            rule: "fieldMap?.get('isUploadSuccessfull')",
            display: true
          },
          {
            rule: "!fieldMap?.get('isUploadSuccessfull')",
            display: false
          }
        ]
      }
    ]
  }
}
