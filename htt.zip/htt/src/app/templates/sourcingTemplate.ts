export const sourcingTemplate = {
  product: {
    id: 'prodid',
    name: 'ACEPL',
    source: 'OPPS',
    action: 'SoucingDetailsData',
    templateName: 'sourcingDetailsTemplate',
    section: [
      {
        name: 'customerInformationDetails',
        type: 'customerInfo',
        field: [
          {
            name: 'avatar',
            type: 'Avatar',
            value: '#{avatar}'
          },
          {
            name: 'customerName',
            type: 'titleSubtitle',
            value: 'Customer Name',
            metadata: {
              subTitle: '#{customerName}',
              type: 'primary'
            }
          },
          {
            name: 'accountNumber',
            type: 'titleSubtitle',
            value: 'Account Number',
            metadata: {
              subTitle: '#{accountNumber}',
              type: 'primary'
            }
          },
          {
            name: 'accountType',
            type: 'titleSubtitle',
            value: 'Account Type',
            metadata: {
              subTitle: '#{accountType}',
              type: 'primary'
            }
          },
          {
            name: 'accountOpeningDate',
            type: 'titleSubtitle',
            value: 'Account Opening Date',
            metadata: {
              subTitle: '#{accountOpeningDate}',
              type: 'primary'
            }
          },
          {
            name: 'status',
            type: 'titleSubtitle',
            value: 'Status',
            metadata: {
              subTitle: '#{status}',
              type: 'secondary',
            }
          },
          {
            name: 'branchId',
            type: 'titleSubtitle',
            value: 'Branch ID',
            metadata: {
              subTitle: '#{branchId}',
              type: 'primary'
            }
          },
          {
            name: 'branchName',
            type: 'titleSubtitle',
            value: 'Branch Name',
            metadata: {
              subTitle: '#{branchName}',
              type: 'primary'
            }
          }
        ]
      },
      {
        name: 'keyInfo',
        type: 'accordion',
        value: 'Key Info',
        field: [

          {
            name: 'sourcingCode',
            type: 'textInput',
            value: '#{sourcingCode}',
            placeHolder: 'Source Code',
            metadata: { disabled: true }
          },

          {
            name: 'bankBranch',
            type: 'textInput',
            value: '#{bankBranch}',
            placeHolder: 'Bank Branch',
            metadata: { disabled: true }
          },

          {
            name: 'bankBrancCode',
            type: 'textInput',
            value: '#{bankBrancCode}',
            placeHolder: 'Bank Branch Code',
            metadata: { disabled: true }
          },
          {
            name: 'bankAmountRequested',
            type: 'textInput',
            value: '#{bankAmountRequested}',
            placeHolder: 'Bank Amount Requested',
            metadata: { disabled: true }
          },

          {
            name: 'dateOfReceipt',
            type: 'textInput',
            value: '#{dateOfReceipt}',
            placeHolder: 'Date of receipt',
            metadata: { disabled: true }
          },
          {
            name: 'relationshipOfficer',
            type: 'textInput',
            value: '#{relationshipOfficer}',
            placeHolder: 'Relationship Officer',
            metadata: { disabled: true }
          },

          {
            name: 'relationshipOfficerEmployeeCode',
            type: 'textInput',
            value: '#{relationshipOfficerEmployeeCode}',
            placeHolder: 'Relationship Officer Employee Code',
            metadata: { disabled: true }
          },
          {
            name: 'relationshipManagerName',
            type: 'textInput',
            value: '#{relationshipManagerName}',
            placeHolder: 'Relationship Manager name',
            metadata: { disabled: true }
          },
          {
            name: 'soEmployeeCode',
            type: 'textInput',
            value: '#{soEmployeeCode}',
            placeHolder: 'SO Employee Code',
            metadata: { disabled: true }
          },

          {
            name: 'soName',
            type: 'textInput',
            value: '#{soName}',
            placeHolder: 'So name',
            metadata: { disabled: true }
          },

        ]

      },
      {
        name: 'loanPurpose',
        type: 'accordion',
        value: 'Loan Purpose',
        field: [

          {
            name: 'loanPurpose',
            type: 'textInput',
            value: '#{loanPurpose}',
            placeHolder: 'Loan Purpose',
            metadata: { disabled: true }
          },

          {
            name: 'loanPurposeDescription',
            type: 'textInput',
            value: '#{loanPurposeDescription}',
            placeHolder: 'Loan Purpose Description',
            metadata: { disabled: true }
          },
        ]

      },
      {
        name: 'rbiClassification',
        type: 'accordion',
        value: 'RBI Classification',
        field: [

          {
            name: 'industryClassification',
            type: 'textInput',
            value: '#{industryClassification}',
            placeHolder: 'Industry Classification',
            metadata: { disabled: true }
          },
          {
            name: 'subIndustryClassification',
            type: 'textInput',
            value: '#{subIndustryClassification}',
            placeHolder: 'Sub Industry Classification',
            metadata: { disabled: true }
          },
          {
            name: 'bsrCode',
            type: 'textInput',
            value: '#{bsrCode}',
            placeHolder: 'BSR Code',
            metadata: { disabled: true }
          },

        ]

      },

    ]
  }
}


