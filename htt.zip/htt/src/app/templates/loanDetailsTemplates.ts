export const loanDetailsTemplate = {
  product: {
    id: 'prodid',
    name: 'ACEPL',
    source: 'OPPS',
    action: 'loanDetailsData',
    templateName: 'loanDetailsTemplate',
    section: [
      {
        name: 'customerInformationDetails',
        type: 'customerInfo',
        field: [
          {
            name: 'avatar',
            type: 'Avatar',
            value: '#{avatar}'
          },
          {
            name: 'customerName',
            type: 'titleSubtitle',
            value: 'Customer Name',
            metadata: {
              subTitle: '#{customerName}',
              type: 'primary'
            }
          },
          {
            name: 'accountNumber',
            type: 'titleSubtitle',
            value: 'Account Number',
            metadata: {
              subTitle: '#{accountNumber}',
              type: 'primary'
            }
          },
          {
            name: 'accountType',
            type: 'titleSubtitle',
            value: 'Account Type',
            metadata: {
              subTitle: '#{accountType}',
              type: 'primary'
            }
          },
          {
            name: 'accountOpeningDate',
            type: 'titleSubtitle',
            value: 'Account Opening Date',
            metadata: {
              subTitle: '#{accountOpeningDate}',
              type: 'primary'
            }
          },
          {
            name: 'status',
            type: 'titleSubtitle',
            value: 'Status',
            metadata: {
              subTitle: '#{status}',
              type: 'secondary',
            }
          },
          {
            name: 'branchId',
            type: 'titleSubtitle',
            value: 'Branch ID',
            metadata: {
              subTitle: '#{branchId}',
              type: 'primary'
            }
          },
          {
            name: 'branchName',
            type: 'titleSubtitle',
            value: 'Branch Name',
            metadata: {
              subTitle: '#{branchName}',
              type: 'primary'
            }
          }
        ]
      },
      {
        name: 'loanDetails',
        type: 'accordion',
        value: 'Loan Details',
        field: [
          {
            name: 'loanAccountNumber',
            type: 'textInput',
            value: '#{loanAccountNumber}',
            placeHolder: 'Loan Account Number',
            metadata: { disabled: true }
          },

          {
            name: 'applicationNumber',
            type: 'textInput',
            placeHolder: 'Application No.',
            value: '#{applicationNumber}',
            metadata: { disabled: true }
          },

          {
            name: 'loanPurpose',
            type: 'textInput',
            value: '#{loanPurpose}',
            placeHolder: 'Loan Purpose',
            metadata: { disabled: true }
          },
          {
            name: 'loanAmount',
            type: 'textInput',
            value: '#{loanAmount}',
            placeHolder: 'Loan Amount',
            metadata: { disabled: true }
          },
          {
            name: 'tenure',
            type: 'textInput',
            value: '#{tenure}',
            placeHolder: 'Tenure',
            metadata: { disabled: true }
          },
          {
            name: 'dueDate',
            type: 'textInput',
            value: '#{dueDate}',
            placeHolder: 'Due date',
            metadata: { disabled: true }
          },
          {
            name: 'disbursementAmount',
            type: 'textInput',
            value: '#{disbursementAmount}',
            placeHolder: 'Disbursement Amount',
            metadata: { disabled: true }
          },

          {
            name: 'emiAmount',
            type: 'textInput',
            value: '#{emiAmount}',
            placeHolder: 'EMI Amount',
            metadata: { disabled: true }
          },

          {
            name: 'effectiveRate',
            type: 'textInput',
            value: '#{effectiveRate}',
            placeHolder: 'Effective Rate',
            metadata: { disabled: true }
          },

          {
            name: 'flatRateLabel',
            type: 'textInput',
            value: '#{flatRateLabel}',
            placeHolder: 'Flat Rate',
            metadata: { disabled: true }
          },
          {
            name: 'partnerInterestReceivableAmount',
            type: 'textInput',
            value: '#{partnerInterestReceivableAmount}',
            placeHolder: 'Partner Interest Receivable Amount',
            metadata: { disabled: true }
          },

          {
            name: 'partnerInterestIncomeAccount',
            type: 'textInput',
            value: '#{partnerInterestIncomeAccount}',
            placeHolder: 'Partner Interest Income Amount',
            metadata: { disabled: true }
          },

          {
            name: 'nonNpaDebitFreeze',
            type: 'textInput',
            value: '#{nonNpaDebitFreeze}',
            placeHolder: 'Non-NPA Debit Freeze',
            metadata: { disabled: true }
          },

          {
            name: 'nonNpaDebitFreezeReason',
            type: 'textInput',
            value: '#{nonNpaDebitFreezeReason}',
            placeHolder: 'Reason',
            metadata: { disabled: true }
          },

          {
            name: 'npaDebitFreeze',
            type: 'textInput',
            value: '#{npaDebitFreeze}',
            placeHolder: 'NPA Debit Freeze',
            metadata: { disabled: true }
          },

          {
            name: 'reason',
            type: 'textInput',
            value: '#{reason}',
            placeHolder: 'Reason',
            metadata: { disabled: true }
          },

        ]
      },
      {
        name: 'scheme',
        type: 'accordion',
        value: 'Scheme',
        field: [
          {
            name: 'product',
            type: 'textInput',
            value: '#{product}',
            placeHolder: 'Product',
            metadata: { disabled: true }
          },

          {
            name: 'subProduct',
            type: 'textInput',
            value: '#{subProduct}',
            placeHolder: 'Sub Product',
            metadata: { disabled: true }
          },

          {
            name: 'schemeName',
            type: 'textInput',
            value: '#{schemeName}',
            placeHolder: 'Scheme Name',
            metadata: { disabled: true }
          },
          {
            name: 'partnerId',
            type: 'textInput',
            value: '#{partnerId}',
            placeHolder: 'Partner Id',
            metadata: { disabled: true }
          },

          {
            name: 'schemeCurrency',
            type: 'textInput',
            value: '#{schemeCurrency}',
            placeHolder: 'Scheme Currency',
            metadata: { disabled: true }
          },
          {
            name: 'repaymentFrequency',
            type: 'textInput',
            value: '#{repaymentFrequency}',
            placeHolder: 'Repayment Frequency',
            metadata: { disabled: true }
          },

          {
            name: 'repaymentPeriod',
            type: 'textInput',
            value: '#{repaymentPeriod}',
            placeHolder: 'Repayment Period',
            metadata: { disabled: true }
          },

          {
            name: 'npaProvisingAllowed',
            type: 'textInput',
            value: '#{npaProvisingAllowed}',
            placeHolder: 'NPA Provision Allowed',
            metadata: { disabled: true }
          },

          {
            name: 'schemeEmiAmount',
            type: 'textInput',
            value: '#{schemeEmiAmount}',
            placeHolder: 'EMI Amount',
            metadata: { disabled: true }
          },

          {
            name: 'autoNPAStageMarkingAllowedLabel',
            type: 'textInput',
            value: '#{autoNPAStageMarkingAllowedLabel}',
            placeHolder: 'Auto NPA stage marking allowed',
            metadata: { disabled: true }
          },
          {
            name: 'overdueMarkUp',
            type: 'textInput',
            value: '#{overdueMarkUp}',
            placeHolder: 'Overview Markup',
            metadata: { disabled: true }
          },
          {
            name: 'interestAccuralDaysInYear',
            type: 'textInput',
            value: '#{interestAccuralDaysInYear}',
            placeHolder: 'Interest Accural Days In Year',
            metadata: { disabled: true }
          },
          {
            name: 'interestSubVented',
            type: 'textInput',
            value: '#{interestSubVented}',
            placeHolder: 'Interest SubVented',
            metadata: { disabled: true }
          },
          {
            name: 'minDrawDownLimit',
            type: 'textInput',
            value: '#{minDrawDownLimit}',
            placeHolder: 'Min DrawDown Limit',
            metadata: { disabled: true }
          },

          {
            name: 'maxDrawDownLimit',
            type: 'textInput',
            value: '#{maxDrawDownLimit}',
            placeHolder: 'Max DrawDown Limit',
            metadata: { disabled: true }
          },
        ]
      },
      {
        name: 'deliquencySection',
        type: 'accordion',
        value: 'Deliquency Section',
        field: [
          {
            name: 'dpd',
            type: 'textInput',
            value: '#{dpd}',
            placeHolder: 'DPD',
            metadata: { disabled: true }
          },

          {
            name: 'dpdString',
            type: 'textInput',
            value: '#{dpdString}',
            placeHolder: 'DPD string',
            metadata: { disabled: true }
          },

          {
            name: 'dpdStringMonthEnd',
            type: 'textInput',
            value: '#{dpdStringMonthEnd}',
            placeHolder: 'DPD String Month End',
            metadata: { disabled: true }
          },
          {
            name: 'bucket',
            type: 'textInput',
            value: '#{bucket}',
            placeHolder: 'Bucket',
            metadata: { disabled: true }
          },
          {
            name: 'npaStage',
            type: 'textInput',
            value: '#{npaStage}',
            placeHolder: 'NPA Stage',
            metadata: { disabled: true }
          },
        ]
      },
    ]
  }
}

