export const customerInformationTemplate = {
  product: {
    id: 'prodid',
    name: 'ACEPL',
    source: 'OPPS',
    action: 'customerInformationData',
    templateName: 'customerInformationTemplate',
    section: [
      // Common customer Information
      {
        name: 'customerInformationDetails',
        type: 'customerInfo',
        value: 'Customer Information Details',
        field: [
          {
            name: 'avatar',
            type: 'avatar',
            value: 'SK'
          },
          {
            name: 'customerName',
            type: 'titleSubtitle',
            value: 'Customer Name',
            metadata: {
              subTitle: 'Sunil Shah',
              type: 'primary'
            }
          },
          {
            name: 'accountNumber',
            type: 'titleSubtitle',
            value: 'Account Number',
            metadata: {
              subTitle: '786352432356',
              type: 'primary'
            }
          },
          {
            name: 'accountType',
            type: 'titleSubtitle',
            value: 'Account Type',
            metadata: {
              subTitle: 'FK ACEPL',
              type: 'primary'
            }
          },
          {
            name: 'accountOpeningDate',
            type: 'titleSubtitle',
            value: 'Account Opening Date',
            metadata: {
              subTitle: '22 Apr, 2020',
              type: 'primary'
            }
          },
          {
            name: 'status',
            type: 'titleSubtitle',
            value: 'Status',
            metadata: {
              subTitle: 'Active',
              type: 'primary',
              color: 'Green'
            }
          },
          {
            name: 'branchId',
            type: 'titleSubtitle',
            value: 'Branch ID',
            metadata: {
              subTitle: '492',
              type: 'primary'
            }
          },
          {
            name: 'branchName',
            type: 'titleSubtitle',
            value: 'Branch Name',
            metadata: {
              subTitle: 'Indiranagar',
              type: 'primary'
            }
          }
        ]
      },
    ]
  }
}
//

