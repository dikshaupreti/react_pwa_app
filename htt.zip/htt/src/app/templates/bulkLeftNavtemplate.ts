
export const leftNavTemplate = {
  product: {
    id: 'prodid',
    name: 'ACEPL',
    source: 'OPPS',
    action: 'leftNavListData',
    templateName: 'leftNavList',
    section: [
      {
        name: 'leftNavList',
        type: 'leftMenuList',
        field: [
          {
            name: 'debitFreezeUnfreeze',
            type: 'navLink',
            value: 'Debit Freeze & Unfreeze',
            metadata: {
              active: true,
              endPoint: '/validate',
              method: 'POST',
              body: ['templateId'],
            }
          },
          {
            name: 'salesReversal',
            type: 'navLink',
            value: 'Sales Reversal',
            metadata: {
              active: false,
              endPoint: '',
              method: 'POST',
              body: ['templateId'],
            }
          },
          {
            name: 'repaymentUpdation',
            type: 'navLink',
            value: 'Repayment Updation',
            metadata: {
              active: false,
              endPoint: '',
              method: 'POST',
              body: ['workflowId'],
            }
          },
          {
            name: 'repaymentCancellation',
            type: 'navLink',
            value: 'Repayment Cancellation',
            metadata: {
              active: false,
              endPoint: '',
              method: 'POST',
              body: ['workflowId'],
            }
          },
          {
            name: 'chargePosting',
            type: 'navLink',
            value: 'Charge Posting',
            metadata: {
              active: false,
              endPoint: '',
              method: 'POST',
              body: ['workflowId'],
            }
          },
          {
            name: 'loanClosure',
            type: 'navLink',
            value: 'Loan Closure',
            metadata: {
              active: false,
              endPoint: '',
              method: 'POST',
              body: ['workflowId'],
            }
          },
          {
            name: 'loanCancellation',
            type: 'navLink',
            value: 'Loan Cancellation',
            metadata: {
              active: false,
              endPoint: '',
              method: 'POST',
              body: ['workflowId'],
            }
          },
          {
            name: 'waiver',
            type: 'navLink',
            value: 'Waiver',
            metadata: {
              active: false,
              endPoint: '',
              method: 'POST',
              body: ['workflowId'],
            }
          },
          {
            name: 'refund',
            type: 'navLink',
            value: 'Refund',
            metadata: {
              active: false,
              endPoint: '',
              method: 'POST',
              body: ['workflowId'],
            }
          },
          {
            name: 'pdeAddressContact',
            type: 'navLink',
            value: 'PDE Address and Contact',
            metadata: {
              active: false,
              endPoint: '',
              method: 'POST',
              body: ['workflowId'],
            }
          },
        ],
      }
    ]
  }

}
