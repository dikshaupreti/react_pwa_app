export const templateTwo = {
  product: {
    id: 'prodid',
    name: 'ACEPL',
    source: 'OPPS',
    action: 'bulkupload',
    templateName: 'bulkUploadTemplateTwo',
    section: [
      {
        name: 'bulkUploadHeader', // changed to bulkUploadHeader
        type: 'headerText', // change to headerText // changed
        field: [
          {
            name: 'debitFreezeeUnfreezeTitle',
            type: 'header',
            value: 'Debit Freeze & Unfreeze'
          }
        ]
      },
      {
        name: 'bulkUploadRightText',
        type: 'rightText',
        field: [
          {
            name: 'codeMasterHelp',
            type: 'link',
            value: 'Code Master Help',
            metadata: {
              type: 'primary',
              endPoint: '/help',
              method: 'POST'
            }
          }
        ]
      },
      {
        name: 'inputFileParameters',
        type: 'fileParameterInfo', // discuss if type-scope is wide enough
        field: [
          {
            name: 'noOfRecordsLabel', // change names // changed
            type: 'label', // label // changed to label
            value: 'Number of Records Required: ',
            metadata: {
              type: 'primary',
            }
          },
          {
            name: 'noOfRecordsValue',
            type: 'label',
            value: "fieldMap.get('noOfRecordsRequired')", // Read from api response and bind value
            metadata: {
              type: 'primaryBoldMedium',
              isExpression: true
            }
          },
          {
            name: 'recordsUploadedLabel',
            type: 'label',
            value: 'Number of records uploaded in file: ',
            metadata: {
              type: 'primary',
            }
          },
          {
            name: 'recordsUploadedValue',
            type: 'label',
            value: "fieldMap.get('noOfRecordsUploaded')", // Read from api response and bind value
            metadata: {
              type: 'primaryBoldMedium',
              isExpression: true
            }
          },
          {
            name: 'validRecordsLabel', // change names // changed
            type: 'label', // label // changed to label
            value: 'Valid Records: ',
            metadata: {
              type: 'primary',
            }
          },
          {
            name: 'validRecordsValue',
            type: 'label',
            value: "fieldMap.get('validRecords')", // Read from api response and bind value
            metadata: {
              type: 'primaryBoldMedium',
              isExpression: true
            }
          },
          {
            name: 'invalidRecordsLabel',
            type: 'label',
            value: 'Invalid Records: ',
            metadata: {
              type: 'primary',
            }
          },
          {
            name: 'invalidRecordsValue',
            type: 'label',
            value: "fieldMap.get('inValidRecords')", // Read from api response and bind value
            metadata: {
              type: 'primaryBoldMedium',
              isExpression: true
            }
          }
        ]
      },
      {
        name: 'fileValidateErrorLabelSection',
        type: 'errorSection',
        field: [
          {
            name: 'validError',
            type: 'label',
            value: 'We have found invalid entries in file . To view the errors, please download the file',
            metadata: {
              type: 'secondary'
            }
          },
        ],
        displayRule: [
          {
            rule: "fieldMap?.get('errorValue') && !fieldMap.get('isProceedFurther')",
            display: true
          },
          {
            rule: "!fieldMap?.get('errorValue')",
            display: false
          }
        ]
      },
      {
        name: 'uploadedFile',
        type: 'uploadedFileInfo', // change to a more expressive one
        field: [
          {
            name: 'fileIcon',
            type: 'fileIcon', // should be icon
            value: 'EXCEL', // Maintain an enum for pdf, excel, and email icons
            metadata: {
              type: 'fileIcon'
            }
          },
          {
            name: 'title',
            type: 'label',
            value: "fieldMap.get('uploadedFileName')", // read from state object
            metadata: {
              type: 'primaryBoldLarge',
              isExpression: true
            }
          },
        ]
      },
      {
        name: 'uploadedFileAction',
        type: 'uploadedFileInfoAction',
        field: [
          {
            name: 'downloadFile',
            type: 'dynamicDownload', // download // dynamic Download link -> read endpoint from metadata in this case // fieldMap.get(<key>)
            value: 'Download',
            metadata: { // metadata : type: dynamicLink and remove endpOint and method
              type: 'primary',
            }
          }
        ]
      },
      {
        name: 'proceedPromptSection',
        type: 'label',
        field: [
          {
            name: 'proceedPrompt',
            type: 'label',
            value: 'You can proceed with valid records, invalid entries will be ignored or you can cancel the process.',
            metadata: {
              type: 'primaryBold'
            }
          }
        ],
        displayRule: [
          {
            rule: "fieldMap.get('errorValue') && !fieldMap.get('isProceedFurther')",
            display: true
          },
          {
            rule: "!fieldMap.get('errorValue')",
            display: false
          }
        ]
      },
      {
        name: 'proceedCancelRequestActionButtons', // section to display proceed and cancel buttons at the end of the page
        type: 'buttonGroup',
        field: [
          {
            name: 'proceedBtn',
            type: 'button',
            value: 'Proceed',
            metadata: {
              type: 'primary',
            }
          },
          {
            name: 'cancelBtn',
            type: 'button',
            value: 'Cancel',
            metadata: {
              type: 'secondary',
            }
          }
        ],
        displayRule: [
          {
            rule: "fieldMap.get('errorValue') && !fieldMap.get('isProceedFurther')",
            display: true
          },
          {
            rule: "!fieldMap.get('errorValue')",
            display: false
          },
        ]
      },
      {
        name: 'uploadSupportingFiles',
        type: 'supportingFileUpload',
        field: [
          {
            name: 'uploadSupportingFilesPrompt',
            type: 'label',
            value: 'Upload supporting files (Upload only eml, jpg and pdf files)',
            metadata: {
              type: 'primaryBoldLarge',
            }
          },
          {
            name: 'supportedFileUploader',
            type: 'fileUploaderContainer',
            field: [
              {
                name: 'supportedFile',
                type: 'fileUploader',
                value: 'Upload File',
                metadata: {
                  secondaryValue: 'Upload more files',
                  maxFiles: 5,
                  minFiles: 1,
                  maxFileSize: 2097152, // Either pass this as a string or pass size in bytes: 2097152 bytes for 2MB
                  supportedFormats: ['.pdf', '.eml', '.jpg'],
                },
              }
            ] // type not generic enough, ask for ideas

          }
        ],
        displayRule: [
          {
            rule: "fieldMap.get('isProceedFurther')",
            display: true
          },
          {
            rule: "!fieldMap.get('isProceedFurther')",
            display: false
          }
        ]
      },
      {
        name: 'priorityAndRemarksInput',
        type: 'priorityRemark', // open for confirmation
        field: [
          {
            name: 'priorityInput',
            type: 'dropdown',
            placeHolder: 'Priority', // convert to camelCase
            metadata: {
              values: ['High', 'Medium', 'Low'],
            }
          },
          {
            name: 'remarksInput',
            type: 'textInput',
            placeHolder: 'Remark if any',
            validation: [
              {
                type: 'maxLength',
                pattern: '20',
                message: ''
              },
            ],
          }
        ],
        displayRule: [
          {
            rule: "fieldMap.get('isProceedFurther')",
            display: true
          },
          {
            rule: "!fieldMap.get('isProceedFurther')",
            display: false
          },
        ]
      },
      {
        name: 'requestActionButtons', // section to display submit and cancel buttons at the end of the page
        type: 'buttonGroup',
        field: [
          {
            name: 'submitBtn',
            type: 'button',
            value: 'Submit',
            metadata: {
              type: 'primary',
              endPoint: '/bulk/request',
              method: 'POST',
              displayRule: [
                {
                  rule: "fieldMap.get('uploadedSupportingFiles')?.length < fieldMap.get('minFiles') || !fieldMap.get('makerRemarks')?.length",
                  disabled: true
                },
                {
                  rule: "fieldMap.get('uploadedSupportingFiles')?.length >= fieldMap.get('minFiles') && fieldMap.get('makerRemarks')?.length",
                  disabled: false
                }
              ]
            }
          },
          {
            name: 'cancelBtn',
            type: 'button',
            value: 'Cancel',
            metadata: {
              type: 'secondary',
            }
          }
        ],
        displayRule: [
          {
            rule: "fieldMap.get('isProceedFurther')",
            display: true
          },
          {
            rule: "!fieldMap.get('isProceedFurther')",
            display: false
          },
        ]
      }
    ]
  }
}
