export const template = {
    product: {
      id: 'prodid',
      name: 'ACEPL',
      source: 'OPPS',
      action: 'accountDetailsData',
      templateName: 'addressAndContactTemplate',
      section: [
        {
          name: 'customerInformationDetails',
          type: 'customerInfo',
          field: [
            {
              name: 'avatar',
              type: 'Avatar',
              value: '#{avatar}'
            },
            {
              name: 'customerName',
              type: 'titleSubtitle',
              value: 'Customer Name',
              metadata: {
                subTitle: '#{customerName}',
                type: 'primary'
              }
            },
            {
              name: 'accountNumber',
              type: 'titleSubtitle',
              value: 'Account Number',
              metadata: {
                subTitle: '#{accountNumber}',
                type: 'primary'
              }
            },
            {
              name: 'accountType',
              type: 'titleSubtitle',
              value: 'Account Type',
              metadata: {
                subTitle: '#{accountType}',
                type: 'primary'
              }
            },
            {
              name: 'accountOpeningDate',
              type: 'titleSubtitle',
              value: 'Account Opening Date',
              metadata: {
                subTitle: '#{accountOpeningDate}',
                type: 'primary'
              }
            },
            {
              name: 'status',
              type: 'titleSubtitle',
              value: 'Status',
              metadata: {
                subTitle: '#{status}', //Active
                type: 'secondary',
              }
            },
            {
              name: 'branchId',
              type: 'titleSubtitle',
              value: 'Branch ID',
              metadata: {
                subTitle: '#{branchId}',
                type: 'primary'
              }
            },
            {
              name: 'branchName',
              type: 'titleSubtitle',
              value: 'Branch Name',
              metadata: {
                subTitle: '#{branchName}',
                type: 'primary'
              }
            }
          ]
        },
        {
          name: 'addressDetailsAccordion',
          type: 'tabs',
          tab: [
            {
              name: 'primaryApplicant',
              type: 'tab',
              value: 'Primary Applicant',
              section: [
                {
                  name: 'addressDetails',
                  type: 'accordionTab',
                  value: 'Address Details',
                  tab: [
                    {
                      name: 'residence',
                      type: 'tab',
                      value: 'Residence',
                      field: [
                        {
                          name: 'addressType',
                          type: 'textInput',
                          placeHolder: 'Address Type',
                          value: '#{addressType}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine1',
                          type: 'textInput',
                          placeHolder: 'Address Line 1',
                          value: '#{addressLine1}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine2',
                          type: 'textInput',
                          placeHolder: 'Address Line 2',
                          value: '#{addressLine2}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'landmark',
                          type: 'textInput',
                          placeHolder: 'Landmark',
                          value: '#{landmark}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'city',
                          type: 'textInput',
                          placeHolder: 'City',
                          value: '#{city}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'district',
                          type: 'textInput',
                          placeHolder: 'District',
                          value: '#{district}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'state',
                          type: 'textInput',
                          placeHolder: 'State',
                          value: '#{state}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'pinCode',
                          type: 'textInput',
                          placeHolder: 'Pin Code',
                          value: '#{pinCode}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'country',
                          type: 'textInput',
                          placeHolder: 'Country',
                          value: '#{country}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'mailingAddress',
                          type: 'textInput',
                          placeHolder: 'Mailing Address',
                          value: '#{mailingAddress}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'propertyStatus',
                          type: 'textInput',
                          placeHolder: 'Property Status',
                          value: '#{propertyStatus}',
                          metadata: {
                            disabled: true,
                          }
                        },
                      ]
                    },
                    {
                      name: 'permanent',
                      type: 'tab',
                      value: 'Permanent',
                      field: [
                        {
                          name: 'addressType',
                          type: 'textInput',
                          placeHolder: 'Address Type',
                          value: '#{addressType}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine1',
                          type: 'textInput',
                          placeHolder: 'Address Line 1',
                          value: '#{addressLine1}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine2',
                          type: 'textInput',
                          placeHolder: 'Address Line 2',
                          value: '#{addressLine2}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'landmark',
                          type: 'textInput',
                          placeHolder: 'Landmark',
                          value: '#{landmark}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'city',
                          type: 'textInput',
                          placeHolder: 'City',
                          value: '#{city}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'district',
                          type: 'textInput',
                          placeHolder: 'District',
                          value: '#{district}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'state',
                          type: 'textInput',
                          placeHolder: 'State',
                          value: '#{state}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'pinCode',
                          type: 'textInput',
                          placeHolder: 'Pin Code',
                          value: '#{pinCode}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'country',
                          type: 'textInput',
                          placeHolder: 'Country',
                          value: '#{country}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'mailingAddress',
                          type: 'textInput',
                          placeHolder: 'Mailing Address',
                          value: '#{mailingAddress}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'propertyStatus',
                          type: 'textInput',
                          placeHolder: 'Property Status',
                          value: '#{propertyStatus}',
                          metadata: {
                            disabled: true,
                          }
                        },
                      ]
                    },
                    {
                      name: 'gst',
                      type: 'tab',
                      value: 'GST',
                      field: [
                        {
                          name: 'addressType',
                          type: 'textInput',
                          placeHolder: 'Address Type',
                          value: '#{addressType}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine1',
                          type: 'textInput',
                          placeHolder: 'Address Line 1',
                          value: '#{addressLine1}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine2',
                          type: 'textInput',
                          placeHolder: 'Address Line 2',
                          value: '#{addressLine2}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'landmark',
                          type: 'textInput',
                          placeHolder: 'Landmark',
                          value: '#{landmark}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'city',
                          type: 'textInput',
                          placeHolder: 'City',
                          value: '#{city}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'district',
                          type: 'textInput',
                          placeHolder: 'District',
                          value: '#{district}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'state',
                          type: 'textInput',
                          placeHolder: 'State',
                          value: '#{state}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'pinCode',
                          type: 'textInput',
                          placeHolder: 'Pin Code',
                          value: '#{pinCode}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'country',
                          type: 'textInput',
                          placeHolder: 'Country',
                          value: '#{country}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'mailingAddress',
                          type: 'textInput',
                          placeHolder: 'Mailing Address',
                          value: '#{mailingAddress}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'propertyStatus',
                          type: 'textInput',
                          placeHolder: 'Property Status',
                          value: '#{propertyStatus}',
                          metadata: {
                            disabled: true,
                          }
                        },
                      ]
                    },
                    {
                      name: 'office',
                      type: 'tab',
                      value: 'Office',
                      field: [
                        {
                          name: 'addressType',
                          type: 'textInput',
                          placeHolder: 'Address Type',
                          value: '#{addressType}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine1',
                          type: 'textInput',
                          placeHolder: 'Address Line 1',
                          value: '#{addressLine1}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine2',
                          type: 'textInput',
                          placeHolder: 'Address Line 2',
                          value: '#{addressLine2}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'landmark',
                          type: 'textInput',
                          placeHolder: 'Landmark',
                          value: '#{landmark}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'city',
                          type: 'textInput',
                          placeHolder: 'City',
                          value: '#{city}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'district',
                          type: 'textInput',
                          placeHolder: 'District',
                          value: '#{district}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'state',
                          type: 'textInput',
                          placeHolder: 'State',
                          value: '#{state}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'pinCode',
                          type: 'textInput',
                          placeHolder: 'Pin Code',
                          value: '#{pinCode}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'country',
                          type: 'textInput',
                          placeHolder: 'Country',
                          value: '#{country}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'mailingAddress',
                          type: 'textInput',
                          placeHolder: 'Mailing Address',
                          value: '#{mailingAddress}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'propertyStatus',
                          type: 'textInput',
                          placeHolder: 'Property Status',
                          value: '#{propertyStatus}',
                          metadata: {
                            disabled: true,
                          }
                        },
                      ]
                    },
                  ]
                },
                {
                  name: 'contactDetails',
                  type: 'accordion',
                  value: 'Contact Details',
                  field: [
                    {
                      name: 'mobile1Primary',
                      type: 'textInput',
                      placeHolder: 'Mobile 1 (Primary)',
                      value: '#{mobile1Primary}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'mobile2Secondary',
                      type: 'textInput',
                      placeHolder: 'Mobile 2 (Secondary)',
                      value: '#{mobile2Secondary}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'smsFlag',
                      type: 'textInput',
                      placeHolder: 'SMS Flag',
                      value: '#{smsFlag}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'areaCode',
                      type: 'textInput',
                      placeHolder: 'Area Code',
                      value: '#{areaCode}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'phone',
                      type: 'textInput',
                      placeHolder: 'Phone',
                      value: '#{phone}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'personalEmailId',
                      type: 'textInput',
                      placeHolder: 'Personal Email ID',
                      value: '#{personalEmailId}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'officeEmailId',
                      type: 'textInput',
                      placeHolder: 'Office Email ID',
                      value: '#{officeEmailId}',
                      metadata: {
                        disabled: true,
                      }
                    },
                  ]
                },
                {
                  name: 'gstDetails',
                  type: 'accordion',
                  value: 'GST Details',
                  field: [
                    {
                      name: 'gstNumber',
                      type: 'textInput',
                      placeHolder: 'GST No.',
                      value: '#{gstNumber}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'mobile1Primary',
                      type: 'textInput',
                      placeHolder: 'Mobile 1 (Primary)',
                      value: '#{mobile1Primary}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'areaCode',
                      type: 'textInput',
                      placeHolder: 'Area Code',
                      value: '#{areaCode}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'phone',
                      type: 'textInput',
                      placeHolder: 'Phone No.',
                      value: '#{phone}',
                      metadata: {
                        disabled: true,
                      }
                    },
                  ]
                }
              ]
            },
            {
              name: 'secondaryApplicant',
              type: 'tab',
              value: 'Secondary Applicant',
              section: [
                {
                  name: 'addressDetails',
                  type: 'accordionTab',
                  value: 'Address Details',
                  tab: [
                    {
                      name: 'residence',
                      type: 'tab',
                      value: 'Residence',
                      field: [
                        {
                          name: 'addressType',
                          type: 'textInput',
                          placeHolder: 'Address Type',
                          value: '#{addressType}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine1',
                          type: 'textInput',
                          placeHolder: 'Address Line 1',
                          value: '#{addressLine1}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine2',
                          type: 'textInput',
                          placeHolder: 'Address Line 2',
                          value: '#{addressLine2}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'landmark',
                          type: 'textInput',
                          placeHolder: 'Landmark',
                          value: '#{landmark}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'city',
                          type: 'textInput',
                          placeHolder: 'City',
                          value: '#{city}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'district',
                          type: 'textInput',
                          placeHolder: 'District',
                          value: '#{district}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'state',
                          type: 'textInput',
                          placeHolder: 'State',
                          value: '#{state}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'pinCode',
                          type: 'textInput',
                          placeHolder: 'Pin Code',
                          value: '#{pinCode}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'country',
                          type: 'textInput',
                          placeHolder: 'Country',
                          value: '#{country}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'mailingAddress',
                          type: 'textInput',
                          placeHolder: 'Mailing Address',
                          value: '#{mailingAddress}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'propertyStatus',
                          type: 'textInput',
                          placeHolder: 'Property Status',
                          value: '#{propertyStatus}',
                          metadata: {
                            disabled: true,
                          }
                        },
                      ]
                    },
                    {
                      name: 'permanent',
                      type: 'tab',
                      value: 'Permanent',
                      field: [
                        {
                          name: 'addressType',
                          type: 'textInput',
                          placeHolder: 'Address Type',
                          value: '#{addressType}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine1',
                          type: 'textInput',
                          placeHolder: 'Address Line 1',
                          value: '#{addressLine1}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine2',
                          type: 'textInput',
                          placeHolder: 'Address Line 2',
                          value: '#{addressLine2}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'landmark',
                          type: 'textInput',
                          placeHolder: 'Landmark',
                          value: '#{landmark}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'city',
                          type: 'textInput',
                          placeHolder: 'City',
                          value: '#{city}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'district',
                          type: 'textInput',
                          placeHolder: 'District',
                          value: '#{district}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'state',
                          type: 'textInput',
                          placeHolder: 'State',
                          value: '#{state}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'pinCode',
                          type: 'textInput',
                          placeHolder: 'Pin Code',
                          value: '#{pinCode}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'country',
                          type: 'textInput',
                          placeHolder: 'Country',
                          value: '#{country}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'mailingAddress',
                          type: 'textInput',
                          placeHolder: 'Mailing Address',
                          value: '#{mailingAddress}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'propertyStatus',
                          type: 'textInput',
                          placeHolder: 'Property Status',
                          value: '#{propertyStatus}',
                          metadata: {
                            disabled: true,
                          }
                        },
                      ]
                    },
                    {
                      name: 'gst',
                      type: 'tab',
                      value: 'GST',
                      field: [
                        {
                          name: 'addressType',
                          type: 'textInput',
                          placeHolder: 'Address Type',
                          value: '#{addressType}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine1',
                          type: 'textInput',
                          placeHolder: 'Address Line 1',
                          value: '#{addressLine1}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine2',
                          type: 'textInput',
                          placeHolder: 'Address Line 2',
                          value: '#{addressLine2}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'landmark',
                          type: 'textInput',
                          placeHolder: 'Landmark',
                          value: '#{landmark}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'city',
                          type: 'textInput',
                          placeHolder: 'City',
                          value: '#{city}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'district',
                          type: 'textInput',
                          placeHolder: 'District',
                          value: '#{district}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'state',
                          type: 'textInput',
                          placeHolder: 'State',
                          value: '#{state}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'pinCode',
                          type: 'textInput',
                          placeHolder: 'Pin Code',
                          value: '#{pinCode}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'country',
                          type: 'textInput',
                          placeHolder: 'Country',
                          value: '#{country}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'mailingAddress',
                          type: 'textInput',
                          placeHolder: 'Mailing Address',
                          value: '#{mailingAddress}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'propertyStatus',
                          type: 'textInput',
                          placeHolder: 'Property Status',
                          value: '#{propertyStatus}',
                          metadata: {
                            disabled: true,
                          }
                        },
                      ]
                    },
                    {
                      name: 'office',
                      type: 'tab',
                      value: 'Office',
                      field: [
                        {
                          name: 'addressType',
                          type: 'textInput',
                          placeHolder: 'Address Type',
                          value: '#{addressType}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine1',
                          type: 'textInput',
                          placeHolder: 'Address Line 1',
                          value: '#{addressLine1}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine2',
                          type: 'textInput',
                          placeHolder: 'Address Line 2',
                          value: '#{addressLine2}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'landmark',
                          type: 'textInput',
                          placeHolder: 'Landmark',
                          value: '#{landmark}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'city',
                          type: 'textInput',
                          placeHolder: 'City',
                          value: '#{city}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'district',
                          type: 'textInput',
                          placeHolder: 'District',
                          value: '#{district}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'state',
                          type: 'textInput',
                          placeHolder: 'State',
                          value: '#{state}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'pinCode',
                          type: 'textInput',
                          placeHolder: 'Pin Code',
                          value: '#{pinCode}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'country',
                          type: 'textInput',
                          placeHolder: 'Country',
                          value: '#{country}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'mailingAddress',
                          type: 'textInput',
                          placeHolder: 'Mailing Address',
                          value: '#{mailingAddress}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'propertyStatus',
                          type: 'textInput',
                          placeHolder: 'Property Status',
                          value: '#{propertyStatus}',
                          metadata: {
                            disabled: true,
                          }
                        },
                      ]
                    },
                  ]
                },
                {
                  name: 'contactDetails',
                  type: 'accordion',
                  value: 'Contact Details',
                  field: [
                    {
                      name: 'mobile1Primary',
                      type: 'textInput',
                      placeHolder: 'Mobile 1 (Primary)',
                      value: '#{mobile1Primary}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'mobile2Secondary',
                      type: 'textInput',
                      placeHolder: 'Mobile 2 (Secondary)',
                      value: '#{mobile2Secondary}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'smsFlag',
                      type: 'textInput',
                      placeHolder: 'SMS Flag',
                      value: '#{smsFlag}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'areaCode',
                      type: 'textInput',
                      placeHolder: 'Area Code',
                      value: '#{areaCode}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'phone',
                      type: 'textInput',
                      placeHolder: 'Phone',
                      value: '#{phone}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'personalEmailId',
                      type: 'textInput',
                      placeHolder: 'Personal Email ID',
                      value: '#{personalEmailId}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'officeEmailId',
                      type: 'textInput',
                      placeHolder: 'Office Email ID',
                      value: '#{officeEmailId}',
                      metadata: {
                        disabled: true,
                      }
                    },
                  ]
                },
                {
                  name: 'gstDetails',
                  type: 'accordion',
                  value: 'GST Details',
                  field: [
                    {
                      name: 'gstNumber',
                      type: 'textInput',
                      placeHolder: 'GST No.',
                      value: '#{gstNumber}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'mobile1Primary',
                      type: 'textInput',
                      placeHolder: 'Mobile 1 (Primary)',
                      value: '#{mobile1Primary}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'areaCode',
                      type: 'textInput',
                      placeHolder: 'Area Code',
                      value: '#{areaCode}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'phone',
                      type: 'textInput',
                      placeHolder: 'Phone No.',
                      value: '#{phone}',
                      metadata: {
                        disabled: true,
                      }
                    },
                  ]
                }
              ]
            },
            {
              name: 'teritiaryApplicant',
              type: 'tab',
              value: 'Tertiary Applicant',
              section: [
                {
                  name: 'addressDetails',
                  type: 'accordionTab',
                  value: 'Address Details',
                  tab: [
                    {
                      name: 'residence',
                      type: 'tab',
                      value: 'Residence',
                      field: [
                        {
                          name: 'addressType',
                          type: 'textInput',
                          placeHolder: 'Address Type',
                          value: '#{addressType}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine1',
                          type: 'textInput',
                          placeHolder: 'Address Line 1',
                          value: '#{addressLine1}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine2',
                          type: 'textInput',
                          placeHolder: 'Address Line 2',
                          value: '#{addressLine2}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'landmark',
                          type: 'textInput',
                          placeHolder: 'Landmark',
                          value: '#{landmark}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'city',
                          type: 'textInput',
                          placeHolder: 'City',
                          value: '#{city}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'district',
                          type: 'textInput',
                          placeHolder: 'District',
                          value: '#{district}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'state',
                          type: 'textInput',
                          placeHolder: 'State',
                          value: '#{state}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'pinCode',
                          type: 'textInput',
                          placeHolder: 'Pin Code',
                          value: '#{pinCode}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'country',
                          type: 'textInput',
                          placeHolder: 'Country',
                          value: '#{country}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'mailingAddress',
                          type: 'textInput',
                          placeHolder: 'Mailing Address',
                          value: '#{mailingAddress}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'propertyStatus',
                          type: 'textInput',
                          placeHolder: 'Property Status',
                          value: '#{propertyStatus}',
                          metadata: {
                            disabled: true,
                          }
                        },
                      ]
                    },
                    {
                      name: 'permanent',
                      type: 'tab',
                      value: 'Permanent',
                      field: [
                        {
                          name: 'addressType',
                          type: 'textInput',
                          placeHolder: 'Address Type',
                          value: '#{addressType}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine1',
                          type: 'textInput',
                          placeHolder: 'Address Line 1',
                          value: '#{addressLine1}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine2',
                          type: 'textInput',
                          placeHolder: 'Address Line 2',
                          value: '#{addressLine2}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'landmark',
                          type: 'textInput',
                          placeHolder: 'Landmark',
                          value: '#{landmark}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'city',
                          type: 'textInput',
                          placeHolder: 'City',
                          value: '#{city}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'district',
                          type: 'textInput',
                          placeHolder: 'District',
                          value: '#{district}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'state',
                          type: 'textInput',
                          placeHolder: 'State',
                          value: '#{state}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'pinCode',
                          type: 'textInput',
                          placeHolder: 'Pin Code',
                          value: '#{pinCode}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'country',
                          type: 'textInput',
                          placeHolder: 'Country',
                          value: '#{country}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'mailingAddress',
                          type: 'textInput',
                          placeHolder: 'Mailing Address',
                          value: '#{mailingAddress}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'propertyStatus',
                          type: 'textInput',
                          placeHolder: 'Property Status',
                          value: '#{propertyStatus}',
                          metadata: {
                            disabled: true,
                          }
                        },
                      ]
                    },
                    {
                      name: 'gst',
                      type: 'tab',
                      value: 'GST',
                      field: [
                        {
                          name: 'addressType',
                          type: 'textInput',
                          placeHolder: 'Address Type',
                          value: '#{addressType}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine1',
                          type: 'textInput',
                          placeHolder: 'Address Line 1',
                          value: '#{addressLine1}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine2',
                          type: 'textInput',
                          placeHolder: 'Address Line 2',
                          value: '#{addressLine2}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'landmark',
                          type: 'textInput',
                          placeHolder: 'Landmark',
                          value: '#{landmark}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'city',
                          type: 'textInput',
                          placeHolder: 'City',
                          value: '#{city}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'district',
                          type: 'textInput',
                          placeHolder: 'District',
                          value: '#{district}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'state',
                          type: 'textInput',
                          placeHolder: 'State',
                          value: '#{state}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'pinCode',
                          type: 'textInput',
                          placeHolder: 'Pin Code',
                          value: '#{pinCode}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'country',
                          type: 'textInput',
                          placeHolder: 'Country',
                          value: '#{country}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'mailingAddress',
                          type: 'textInput',
                          placeHolder: 'Mailing Address',
                          value: '#{mailingAddress}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'propertyStatus',
                          type: 'textInput',
                          placeHolder: 'Property Status',
                          value: '#{propertyStatus}',
                          metadata: {
                            disabled: true,
                          }
                        },
                      ]
                    },
                    {
                      name: 'office',
                      type: 'tab',
                      value: 'Office',
                      field: [
                        {
                          name: 'addressType',
                          type: 'textInput',
                          placeHolder: 'Address Type',
                          value: '#{addressType}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine1',
                          type: 'textInput',
                          placeHolder: 'Address Line 1',
                          value: '#{addressLine1}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'addressLine2',
                          type: 'textInput',
                          placeHolder: 'Address Line 2',
                          value: '#{addressLine2}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'landmark',
                          type: 'textInput',
                          placeHolder: 'Landmark',
                          value: '#{landmark}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'city',
                          type: 'textInput',
                          placeHolder: 'City',
                          value: '#{city}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'district',
                          type: 'textInput',
                          placeHolder: 'District',
                          value: '#{district}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'state',
                          type: 'textInput',
                          placeHolder: 'State',
                          value: '#{state}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'pinCode',
                          type: 'textInput',
                          placeHolder: 'Pin Code',
                          value: '#{pinCode}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'country',
                          type: 'textInput',
                          placeHolder: 'Country',
                          value: '#{country}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'mailingAddress',
                          type: 'textInput',
                          placeHolder: 'Mailing Address',
                          value: '#{mailingAddress}',
                          metadata: {
                            disabled: true,
                          }
                        },
                        {
                          name: 'propertyStatus',
                          type: 'textInput',
                          placeHolder: 'Property Status',
                          value: '#{propertyStatus}',
                          metadata: {
                            disabled: true,
                          }
                        },
                      ]
                    },
                  ]
                },
                {
                  name: 'contactDetails',
                  type: 'accordion',
                  value: 'Contact Details',
                  field: [
                    {
                      name: 'mobile1Primary',
                      type: 'textInput',
                      placeHolder: 'Mobile 1 (Primary)',
                      value: '#{mobile1Primary}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'mobile2Secondary',
                      type: 'textInput',
                      placeHolder: 'Mobile 2 (Secondary)',
                      value: '#{mobile2Secondary}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'smsFlag',
                      type: 'textInput',
                      placeHolder: 'SMS Flag',
                      value: '#{smsFlag}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'areaCode',
                      type: 'textInput',
                      placeHolder: 'Area Code',
                      value: '#{areaCode}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'phone',
                      type: 'textInput',
                      placeHolder: 'Phone',
                      value: '#{phone}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'personalEmailId',
                      type: 'textInput',
                      placeHolder: 'Personal Email ID',
                      value: '#{personalEmailId}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'officeEmailId',
                      type: 'textInput',
                      placeHolder: 'Office Email ID',
                      value: '#{officeEmailId}',
                      metadata: {
                        disabled: true,
                      }
                    },
                  ]
                },
                {
                  name: 'gstDetails',
                  type: 'accordion',
                  value: 'GST Details',
                  field: [
                    {
                      name: 'gstNumber',
                      type: 'textInput',
                      placeHolder: 'GST No.',
                      value: '#{gstNumber}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'mobile1Primary',
                      type: 'textInput',
                      placeHolder: 'Mobile 1 (Primary)',
                      value: '#{mobile1Primary}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'areaCode',
                      type: 'textInput',
                      placeHolder: 'Area Code',
                      value: '#{areaCode}',
                      metadata: {
                        disabled: true,
                      }
                    },
                    {
                      name: 'phone',
                      type: 'textInput',
                      placeHolder: 'Phone No.',
                      value: '#{phone}',
                      metadata: {
                        disabled: true,
                      }
                    },
                  ]
                }
              ]
            }
          ]
        }
      ]
    }
  }
  