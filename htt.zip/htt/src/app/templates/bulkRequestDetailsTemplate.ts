export const requestDetailsTemplate = {
  product: {
    id: 'prodid',
    name: 'ACEPL',
    source: 'OPPS',
    action: 'requestDetailsChecker',
    templateName: 'bulkRequestDetailsTemplate',
    section: [
      {
        name: 'requestDetailsHeader',
        type: 'headerText',
        field: [
          {
            name: 'requestDetailsTitle',
            type: 'header',
            value: 'Request Details',
          },
        ],
      },
      {
        name: 'requestDetailsRightText',
        type: 'rightText',
        field: [
          {
            name: 'status',
            type: 'labelButton',
            value: 'APPROVED',
            metadata: {
              type: 'secondary',
              subTitle: ''// secondary and ternary
            },
          },
        ],
      },
      {
        name: 'requestDetailsDescription',
        type: 'description',
        field: [
          {
            name: 'batchIdLabel',
            type: 'titleSubtitle',
            value: 'Batch ID',
            metadata: {
              subTitle: 'BT234',
              type: 'primary'
            }
          },
          {
            name: 'totalBatchRecordsLabel',
            type: 'titleSubtitle',
            value: 'Records in Batch',
            metadata: {
              subTitle: '60',
              type: 'primary'
            }
          },
          {
            name: 'recordsSucceedLabel',
            type: 'titleSubtitle',
            value: 'Success Records',
            metadata: {
              subTitle: '57',
              type: 'primary'
            }
          },
          {
            name: 'recordsFailedLabel',
            type: 'titleSubtitle',
            value: 'Failure Records',
            metadata: {
              subTitle: '03',
              type: 'primary'
            }
          },
          {
            name: 'makerLabel',
            type: 'titleSubtitle',
            value: 'Maker',
            metadata: {
              subTitle: 'MI0002',
              type: 'primary'
            }
          },
          {
            name: 'checkerLabel',
            type: 'titleSubtitle',
            value: 'Checker',
            metadata: {
              subTitle: 'CI0002',
              type: 'primary'
            }
          },
          {
            name: 'dateCreatedLabel',
            type: 'titleSubtitle',
            value: 'Request Created On',
            metadata: {
              subTitle: '20 Aug 2022 | 4.34PM',
              type: 'primary'
            }
          },
          {
            name: 'makerRemarkLabel',
            type: 'titleSubtitle',
            value: 'Maker Remark',
            metadata: {
              subTitle: 'Debit Freeze & Un Freeze Bulk Upload',
              type: 'primary'
            }
          },
          {
            name: 'checkersRemarkLabel',
            type: 'titleSubtitle',
            value: 'Checker Remark',
            metadata: {
              subTitle: 'Approved',
              type: 'primary'
            }
          },
        ],
      },
      {
        name: 'requestDetailsAction',
        type: 'action',
        field: [
          {
            name: 'approve',
            type: 'button',
            value: 'Approve',
            metadata: {
              type: 'primary',
            },
          },
          {
            name: 'reject',
            type: 'button',
            value: 'Reject',
            metadata: {
              type: 'primary',
            },
          },
        ],
        displayRule: [
          {
            rule: "fieldMap?.get('checker') && fieldMap?.get('status') === 'PENDING'",
            display: true
          },
          {
            rule: "fieldMap?.get('maker') || fieldMap?.get('status') !== 'PENDING'",
            display: false
          }
        ]
      }

    ],
  }
}
