export const template = {
  product: {
    id: 'prodid',
    name: 'ACEPL',
    source: 'OPPS',
    action: 'acoountDetailsData',
    templateName: 'customerInformationTemplate',
    section: [
      {
        name: 'customerInformationDetails',
        type: 'customerInfo',
        field: [
          {
            name: 'avatar',
            type: 'Avatar',
            value: '#{avatar}'
          },
          {
            name: 'customerName',
            type: 'titleSubtitle',
            value: 'Customer Name',
            metadata: {
              subTitle: '#{customerName}',
              type: 'primary'
            }
          },
          {
            name: 'accountNumber',
            type: 'titleSubtitle',
            value: 'Account Number',
            metadata: {
              subTitle: '#{accountNumber}',
              type: 'primary'
            }
          },
          {
            name: 'accountType',
            type: 'titleSubtitle',
            value: 'Account Type',
            metadata: {
              subTitle: '#{accountType}',
              type: 'primary'
            }
          },
          {
            name: 'accountOpeningDate',
            type: 'titleSubtitle',
            value: 'Account Opening Date',
            metadata: {
              subTitle: '#{accountOpeningDate}',
              type: 'primary'
            }
          },
          {
            name: 'status',
            type: 'titleSubtitle',
            value: 'Status',
            metadata: {
              subTitle: '#{status}',
              type: 'secondary',
            }
          },
          {
            name: 'branchId',
            type: 'titleSubtitle',
            value: 'Branch ID',
            metadata: {
              subTitle: '#{branchId}',
              type: 'primary'
            }
          },
          {
            name: 'branchName',
            type: 'titleSubtitle',
            value: 'Branch Name',
            metadata: {
              subTitle: '#{branchName}',
              type: 'primary'
            }
          }
        ]
      },
      {
        name: 'PersonalDetails',
        type: 'accordion',
        value: 'Personal Details',
        field: [
          {
            name: 'crn',
            type: 'textInput',
            value: '#{crn}',
            placeHolder: 'CRN',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'customerType',
            type: 'textInput',
            value: '#{customerType}',
            placeHolder: 'Customer Type',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'applicantType',
            type: 'textInput',
            value: '#{applicantType}',
            placeHolder: 'Applicant Type',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'fullName',
            type: 'textInput',
            value: '#{fullName}',
            placeHolder: 'Full Name',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'dateOfBirth',
            type: 'textInput',
            value: '#{dateOfBirth}',
            placeHolder: 'Date of Birth',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'age',
            type: 'textInput',
            value: '#{age}',
            placeHolder: 'Age',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'gender',
            type: 'textInput',
            value: '#{gender}',
            placeHolder: 'Gender',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'placeOfBirth',
            type: 'textInput',
            value: '#{placeOfBirth}',
            placeHolder: 'Place of Birth',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'maritalStatus',
            type: 'textInput',
            value: '#{maritalStatus}',
            placeHolder: 'Marital Status',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'citizenship',
            type: 'textInput',
            value: '#{citizenship}',
            placeHolder: 'Citizenship',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'nationality',
            type: 'textInput',
            value: '#{nationality}',
            placeHolder: 'Nationality',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'educationalQualification',
            type: 'textInput',
            value: '#{educationalQualification}',
            placeHolder: 'Educational Qualification',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'professionalQualification',
            type: 'textInput',
            value: '#{professionalQualification}',
            placeHolder: 'Professional Qualification',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'religion',
            type: 'textInput',
            value: '#{religion}',
            placeHolder: 'Religion',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'numberOfDependants',
            type: 'textInput',
            value: '#{numberOfDependants}',
            placeHolder: 'No. of Dependants',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'riskCategory',
            type: 'textInput',
            value: '#{riskCategory}',
            placeHolder: 'Risk Category',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'occupation',
            type: 'textInput',
            value: '#{occupation}',
            placeHolder: 'Occupation',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'occupationType',
            type: 'textInput',
            value: '#{occupationType}',
            placeHolder: 'Occupation Type',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'maidenName',
            type: 'textInput',
            value: '#{maidenName}',
            placeHolder: 'Maiden Name',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'fathersName',
            type: 'textInput',
            value: '#{fathersName}',
            placeHolder: 'Father\'s Name',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'spousesName',
            type: 'textInput',
            value: '#{spousesName}',
            placeHolder: 'Spouse\'s Name',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'mothersMaidenName',
            type: 'textInput',
            value: '#{mothersMaidenName}',
            placeHolder: 'Mother\'s Maiden Name',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'nonNPADebitFreeze',
            type: 'textInput',
            value: '#{nonNPADebitFreeze}',
            placeHolder: 'Non-NPA Debit Freeze',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'nonNPADebitReasons',
            type: 'textInput',
            value: '#{nonNPADebitReasons}',
            placeHolder: 'Reasons',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'NPADebitFreeze',
            type: 'textInput',
            value: '#{NPADebitFreeze}',
            placeHolder: 'NPA Debit Freeze',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'NPADebitReasons',
            type: 'textInput',
            value: '#{NPADebitReasons}',
            placeHolder: 'Reasons',
            metadata: {
              disabled: true
            }
          }
        ]
      },
      {
        name: 'KYCDetails',
        type: 'accordion',
        value: 'KYC Details',
        field: [
          {
            name: 'panCardNumber',
            type: 'textInput',
            value: '#{panCardNumber}',
            placeHolder: 'PAN Card No.',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'nsdlFetchedName',
            type: 'textInput',
            value: '#{nsdlFetchedName}',
            placeHolder: 'NSDL Fetched Name',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'aadhaarNumber',
            type: 'textInput',
            value: '#{aadhaarNumber}',
            placeHolder: 'Aadhaar No.',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'aadhaarReferenceNumber',
            type: 'textInput',
            value: '#{aadhaarReferenceNumber}',
            placeHolder: 'Aadhaar Reference No.',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'drivingLicenseNumber',
            type: 'textInput',
            value: '#{drivingLicenseNumber}',
            placeHolder: 'Driving License No.',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'drivingLicenceIssueDate',
            type: 'textInput',
            value: '#{drivingLicenceIssueDate}',
            placeHolder: 'Driving License Issue Date',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'drivingLicenseIssuedAt',
            type: 'textInput',
            value: '#{drivingLicenseIssuedAt}',
            placeHolder: 'Driving License Issued At',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'drivingLicenseExpiryDate',
            type: 'textInput',
            value: '#{drivingLicenseExpiryDate}',
            placeHolder: 'Driving License Expiry Date',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'voterId',
            type: 'textInput',
            value: '#{voterId}',
            placeHolder: 'Voter ID',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'passportFileNumber',
            type: 'textInput',
            value: '#{passportFileNumber}',
            placeHolder: 'Passport File No.',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'passportNumber',
            type: 'textInput',
            value: '#{passportNumber}',
            placeHolder: 'Passport No.',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'passportIssueDate',
            type: 'textInput',
            value: '#{passportIssueDate}',
            placeHolder: 'Passport Issue Date',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'passportExpiryDate',
            type: 'textInput',
            value: '#{passportExpiryDate}',
            placeHolder: 'Passport Expiry Date',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'passportCountry',
            type: 'textInput',
            value: '#{passportCountry}',
            placeHolder: 'Passport Country',
            metadata: {
              disabled: true
            }
          },
          {
            name: 'naregaJobCard',
            type: 'textInput',
            value: '#{naregaJobCard}',
            placeHolder: 'Narega Job Card',
            metadata: {
              disabled: true
            }
          },
        ]
      },
    ]
  }
}
