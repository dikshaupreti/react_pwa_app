export const financialDetailsTemplate = {
  product: {
    id: 'prodid',
    name: 'ACEPL',
    source: 'OPPS',
    action: 'financialDetailsData',
    templateName: 'financialDetailsTemplate',
    section: [

      // Common customer Information
      {
        name: 'customerInformationDetails',
        type: 'customerInfo',
        field: [
          {
            name: 'avatar',
            type: 'Avatar',
            value: '#{avatar}'
          },
          {
            name: 'customerName',
            type: 'titleSubtitle',
            value: 'Customer Name',
            metadata: {
              subTitle: '#{customerName}',
              type: 'primary'
            }
          },
          {
            name: 'accountNumber',
            type: 'titleSubtitle',
            value: 'Account Number',
            metadata: {
              subTitle: '#{accountNumber}',
              type: 'primary'
            }
          },
          {
            name: 'accountType',
            type: 'titleSubtitle',
            value: 'Account Type',
            metadata: {
              subTitle: '#{accountType}',
              type: 'primary'
            }
          },
          {
            name: 'accountOpeningDate',
            type: 'titleSubtitle',
            value: 'Account Opening Date',
            metadata: {
              subTitle: '#{accountOpeningDate}',
              type: 'primary'
            }
          },
          {
            name: 'status',
            type: 'titleSubtitle',
            value: 'Status',
            metadata: {
              subTitle: '#{status}',
              type: 'secondary',
            }
          },
          {
            name: 'branchId',
            type: 'titleSubtitle',
            value: 'Branch ID',
            metadata: {
              subTitle: '#{branchId}',
              type: 'primary'
            }
          },
          {
            name: 'branchName',
            type: 'titleSubtitle',
            value: 'Branch Name',
            metadata: {
              subTitle: '#{branchName}',
              type: 'primary'
            }
          }
        ]
      },
      // Bank Details
      {
        name: 'bankDetailsAccordion',
        type: 'accordion',
        value: 'Bank Details',
        field: [
          {
            name: 'accountType',
            type: 'textInput',
            placeHolder: 'Account Type',
            value: '#{accountType}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'bankName',
            type: 'textInput',
            placeHolder: 'Bank Name',
            value: '#{bankName}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'ifscMicr',
            type: 'textInput',
            placeHolder: 'IFSC/MICR',
            value: '#{ifscMicr}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'accountNumber',
            type: 'textInput',
            placeHolder: 'Account No.',
            value: '#{accountNumber}',
            metadata: {
              disabled: true,
            }
          },
          {
            name: 'branchName',
            type: 'textInput',
            placeHolder: 'Branch Name',
            value: '#{branchName}',
            metadata: {
              disabled: true,
            }
          },
        ],
      },
    ]
  }
}
