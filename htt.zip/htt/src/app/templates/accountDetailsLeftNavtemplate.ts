
export const accountDetailsLeftNavTemplate = {
  product: {
    id: 'prodid',
    name: 'ACEPL',
    source: 'OPPS',
    action: 'accountDetailsListData',
    templateName: 'accountDetailsLeftNavList',
    section: [
      {
        name: 'accountDetailsList',
        type: 'leftMenuList',
        field: [
          {
            name: 'loanDetails',
            type: 'navLink',
            value: 'Loan Details',
            metadata: {
              active: true,
              endPoint: '',
              method: 'POST',
            }
          },
          {
            name: 'sourcing',
            type: 'navLink',
            value: 'Sourcing',
            metadata: {
              active: false,
              endPoint: '',
              method: 'POST',
            }
          },
          {
            name: 'limitDetails',
            type: 'navLink',
            value: 'Limit Details',
            metadata: {
              active: false,
              endPoint: '',
              method: 'POST',
            }
          },
          {
            name: 'feeDetails',
            type: 'navLink',
            value: 'Fee Details',
            metadata: {
              active: false,
              endPoint: '/feeDetails',
              method: 'POST',
            }
          },
          {
            name: 'customerInformation',
            type: 'navLink',
            value: 'Customer Information',
            metadata: {
              active: false,
              endPoint: '',
              method: 'POST',
            }
          },
          {
            name: 'addressAndContactDetails',
            type: 'navLink',
            value: 'Address And Contact Details',
            metadata: {
              active: false,
              endPoint: '',
              method: 'POST',
            }
          },
          {
            name: 'ckycSection',
            type: 'navLink',
            value: 'CKYC Section',
            metadata: {
              active: false,
              endPoint: '',
              method: 'POST',
            }
          },
          {
            name: 'financialDetails',
            type: 'navLink',
            value: 'Financial Details',
            metadata: {
              active: false,
              endPoint: '',
              method: 'POST',

            }
          },
        ],
      }
    ]
  }

}

