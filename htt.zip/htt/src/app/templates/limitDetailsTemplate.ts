export const limitDetailsTemplate = {
  product: {
    id: 'prodid',
    name: 'ACEPL',
    source: 'OPPS',
    action: 'limitDetailsData',
    templateName: 'limitDetailsTemplate',
    section: [
      {
        name: 'customerInformationDetails',
        type: 'customerInfo',
        field: [
          {
            name: 'avatar',
            type: 'Avatar',
            value: '#{avatar}'
          },
          {
            name: 'customerName',
            type: 'titleSubtitle',
            value: 'Customer Name',
            metadata: {
              subTitle: '#{customerName}',
              type: 'primary'
            }
          },
          {
            name: 'accountNumber',
            type: 'titleSubtitle',
            value: 'Account Number',
            metadata: {
              subTitle: '#{accountNumber}',
              type: 'primary'
            }
          },
          {
            name: 'accountType',
            type: 'titleSubtitle',
            value: 'Account Type',
            metadata: {
              subTitle: '#{accountType}',
              type: 'primary'
            }
          },
          {
            name: 'accountOpeningDate',
            type: 'titleSubtitle',
            value: 'Account Opening Date',
            metadata: {
              subTitle: '#{accountOpeningDate}',
              type: 'primary'
            }
          },
          {
            name: 'status',
            type: 'titleSubtitle',
            value: 'Status',
            metadata: {
              subTitle: '#{status}',
              type: 'secondary',
            }
          },
          {
            name: 'branchId',
            type: 'titleSubtitle',
            value: 'Branch ID',
            metadata: {
              subTitle: '#{branchId}',
              type: 'primary'
            }
          },
          {
            name: 'branchName',
            type: 'titleSubtitle',
            value: 'Branch Name',
            metadata: {
              subTitle: '#{branchName}',
              type: 'primary'
            }
          }
        ]
      },
      {
        name: 'limitDetails',
        type: 'accordion',
        value: 'Limit Details',
        field: [
          {
            name: 'limitSanctioned',
            type: 'textInput',
            value:  '#{limitSanctioned}',
            placeHolder: 'Loan Account Number',
            metadata: { disabled: true }
          },

          {
            name: 'limitConsumed',
            type: 'textInput',
            value:  '#{limitConsumed}',
            placeHolder: 'Limit Consumed',
            metadata: { disabled: true }
          },

          {
            name: 'limitBalanced',
            type: 'textInput',
            value:  '#{limitBalanced}',
            placeHolder: 'Limit Balance',
            metadata: { disabled: true }
          },

          {
            name: 'limitSanctionDate',
            type: 'textInput',
            value:  '#{limitSanctionDate}',
            placeHolder: 'Limit Sanction Date',
            metadata: { disabled: true }
          },
          {
            name: 'limitExpiryDate',
            type: 'textInput',
            value:  '#{limitExpiryDate}',
            placeHolder: 'Limit Balance',
            metadata: { disabled: true }
          },
          {
            name: 'limitNextReviewDate',
            type: 'textInput',
            value:  '#{limitNextReviewDate}',
            placeHolder: 'Limit Next Review Date',
            metadata: { disabled: true }
          },

        ]
      },

    ]
  }
}


