
export const bulkUploadSalesReversalTemplateOne = {
    product: {
      id: 'prodid',
      name: 'ACEPL',
      source: 'OPPS',
      action: 'accountDetails',
      templateName: 'feeDetails',
      section: [
        {
          name: 'customerInformationDetails',
          type: 'customerInfo',
          field: [
            {
              name: 'avatar',
              type: 'Avatar',
              value: '#{avatar}'
            },
            {
              name: 'customerName',
              type: 'titleSubtitle',
              value: 'Customer Name',
              metadata: {
                subTitle: '#{customerName}',
                type: 'primary'
              }
            },
            {
              name: 'accountNumber',
              type: 'titleSubtitle',
              value: 'Account Number',
              metadata: {
                subTitle: '#{accountNumber}',
                type: 'primary'
              }
            },
            {
              name: 'accountType',
              type: 'titleSubtitle',
              value: 'Account Type',
              metadata: {
                subTitle: '#{accountType}',
                type: 'primary'
              }
            },
            {
              name: 'accountOpeningDate',
              type: 'titleSubtitle',
              value: 'Account Opening Date',
              metadata: {
                subTitle: '#{accountOpeningDate}',
                type: 'primary'
              }
            },
            {
              name: 'status',
              type: 'titleSubtitle',
              value: 'Status',
              metadata: {
                subTitle: '#{status}',
                type: 'secondary',
              }
            },
            {
              name: 'branchId',
              type: 'titleSubtitle',
              value: 'Branch ID',
              metadata: {
                subTitle: '#{branchId}',
                type: 'primary'
              }
            },
            {
              name: 'branchName',
              type: 'titleSubtitle',
              value: 'Branch Name',
              metadata: {
                subTitle: '#{branchName}',
                type: 'primary'
              }
            }
          ]
        },
        {
          name: 'feeDetails',
          type: 'dynamicAccordion',
          value: 'Fee & Charges',
          data: [
            {
              name: 'leftSection',
              type: 'leftSection',
              field: [
                {
                  name: 'dateRange',
                  type: 'dateRange',
                  metadata: {
                    fromDate: '#{fromDate}',
                    toDate: '#{toDate}',
                    fromMaxDate:  '#{fromMaxDate}',
                    toMaxDate:  '#{toMaxDate}',
                  }
                },
                {
                  name: 'downLoadFeeDetails',
                  type: 'dropDownDownLoad',
                  metadata: {
                    supportedFormats: ['excel']
                  }
                }
              ]
            },
            {
              name: 'rightSection',
              type: 'rightSection',
              field: [
                {
                  name: 'feeDetailsFilter',
                  type: 'dropDown',
                  metadata: {
                    data: [
                      {
                        name: 'date',
                        value: 'Date'
                      },
                      {
                        name: 'chargeDescription',
                        value: 'Charge Description',
                        options: {
                          name: 'chargeDescriptionsMultiSelect',
                          type: 'multiselect',
                          value: [
                            'Late Payment',
                            'Check Bounce',
                            'Swap',
                            'EMI Bounce',
                            'Collection and Pickup',
                            'Excess',
                            'Other'
                          ]
                        }
                      }
                    ]
  
  
                  }
                },
                {
                  name: 'feeDetailsSearch',
                  type: 'search',
                  medatadata: {
                    value: "fieldMap.get('searchParam')"
                  }
                }
              ]
            },
            {
              name: 'feeDetailsTable',
              type: 'table',
              metadata: {
                columns: [
                  'Charge Date',
                  'Charge Description',
                  'Applicable Charges',
                  'GST',
                  'Total Charge',
                  'Amount of Waiver',
                  'Net Charges Due',
                  'Amount Paid',
                  'Amount Unpaid'
                ]
              }
            }
          ]
        }
      ]
    }
  }
  
  