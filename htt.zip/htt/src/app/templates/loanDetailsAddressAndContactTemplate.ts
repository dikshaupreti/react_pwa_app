export const template = {
  product: {
    id: 'prodid',
    name: 'ACEPL',
    source: 'OPPS',
    action: 'batchrecords',
    templateName: 'bulkBatchRecordsTemplate',
    section: [
      {
        name: 'batchRecordsTabs',
        type: 'tabs',
        field: [
          {
            name: 'batchRecordDetails',
            type: 'tab',
            value: 'Batch Records Details',
            metadata: {
              type: 'batchRecords',
              endPoint: '/bulk/batchrecorddetails',
              method: 'POST'
            }
          }, {
            name: 'attachment',
            type: 'tab',
            value: 'Attachment',
            metadata: {
              type: 'attachment',
              endPoint: '/documents',
              method: 'POST',
            }
          }, {
            name: 'activityDetails',
            type: 'tab',
            value: 'Activity Details',
            metadata: {
              type: 'activityDetails',
              endPoint: '/viewactivity',
              method: 'POST'
            }
          }
        ]
      },
      {
        name: 'batchRecordsFilterText',
        type: 'filterText',
        field: [
          {
            name: 'filterByAll',
            type: 'filterBtn',
            value: 'All'
          }, {
            name: 'filterBySuccess',
            type: 'filterBtn',
            value: 'Success'
          }, {
            name: 'filterByFailure',
            type: 'filterBtn',
            value: 'Failure'
          }
        ],
        displayRules: [
          {
            rule: "fieldMap?.get('isStatusApproved')",
            display: true
          },
          {
            rule: "!fieldMap?.get('isStatusApproved')",
            display: false
          }
        ]
      },
      {
        name: 'batchRecordsRightText',
        type: 'rightText',
        field: [
          {
            name: 'refresh',
            type: 'link',
            value: 'Refresh',
            metadata: {
              type: 'primary',
              endPoint: '/bulk/batchrecorddetails',
              method: 'POST'
            }
          },
          {
            name: 'download',
            type: 'downLoad',
            value: 'Download in Excel',
            metadata: {
              type: 'primary',
              endPoint: '/download/sample',
              method: 'POST'
            }
          }
        ]
      },
      {
        name: 'batchRecordsColumnNames',
        type: 'columnName',
        field: [
          {
            name: 'requestId',
            type: 'label',
            value: 'Request ID',
          },
          {
            name: 'accountNo',
            type: 'label',
            value: 'Account No.',
          }, {
            name: 'debitFreezeFlag',
            type: 'label',
            value: 'Debit Freeze Flag',
          }, {
            name: 'reasons',
            type: 'label',
            value: 'Reasons',
          }, {
            name: 'requestStatus',
            type: 'label',
            value: 'Request Status',
          }, {
            name: 'transactionStatus',
            type: 'label',
            value: 'Transaction Status',
          }
        ]
      },
    ]
  }
}


