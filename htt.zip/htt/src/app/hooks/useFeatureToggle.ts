import { useContext } from 'react'
import { FeatureToggleContext } from '_context/FeatureToggleContext'

export const useFeatureToggle = () => {
  const { enabledFeatures } = useContext(FeatureToggleContext)
  const isEnabled = (featureName: string) => enabledFeatures.includes(featureName)
  return [
    isEnabled,
  ]
}
