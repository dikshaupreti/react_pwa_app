import React, { ReactElement } from 'react'
import { FeatureToggleContext } from '_context/FeatureToggleContext'
import { IFeatureToggleContext, IFeatureToggleProvider } from '_context/types'
import { renderHook } from '_jest/CustomRender'
import { useFeatureToggle } from './useFeatureToggle'

const FeatureToggleProvider = ({ children, value }: IFeatureToggleProvider) => (
  <FeatureToggleContext.Provider value={value}>
    {children}
  </FeatureToggleContext.Provider>
)

const initialValue: IFeatureToggleContext = {
  enabledFeatures: []
}

describe('set isEnabled', () => {
  it('Should verify isEnabled is false', () => {
    const wrapper = ({ children }: { children: ReactElement }) => (
      <FeatureToggleProvider value={initialValue}>
        {children}
      </FeatureToggleProvider>
    )
    const { result } = renderHook(() => useFeatureToggle(), { wrapper })
    const [isEnabled] = result.current
    const resValue = isEnabled('FeatureOne')
    expect(resValue).toBeFalsy()
  })
  it('Should verify isEnabled is true', () => {
    const wrapper = ({ children }: { children: ReactElement }) => (
      <FeatureToggleProvider value={{ ...initialValue, enabledFeatures: ['FeatureOne'] }}>
        {children}
      </FeatureToggleProvider>
    )
    const { result } = renderHook(() => useFeatureToggle(), { wrapper })
    const [isEnabled] = result.current
    const resValue = isEnabled('FeatureOne')
    expect(resValue).toBeTruthy()
  })
})
