// TODO constants
// Request Details TODD::
export const identifier = 'cds-case-mgmt-service/api/v1/makerchecker/casedetails/id'
export const requestId = 'OPSBID000000009'
export const action = 'ACCOUNT'
export const checkerId = '987654'
export const checkerName = 'Nikhil_checker'
export const version = 0
export const uuid = 'bharath-cwe23-ed3d3-ec231'
export const todoConstants = {
  ACCOUNT_OPENING_YEAR: 40,
  MAKER_ID: '123456789',
  MAKER_NAME: 'Bharath',
  REQUEST_ID: 'OPSREQ000000927',
  ACCOUNT_NUMBER: '786352432356',
  APPLICATION_NUMBER: '786352432356908',
  LOAN_ACCOUNT_NUMBER: '786352432356',
  CUSTOMER_NAME: 'Amit Kumar',
  CRN: '123456',
  ACCOUNT_NUMBER2: '987654321',
  RESPONSE_FIELDS_LIST: ['makerId', 'batchId', 'recordsInBatch', 'recordsSuccessfullyUploaded'],
  HEADER_NAME: 'User Name',
  PAN_NUMBER: 'DCFPA3715N'
}
