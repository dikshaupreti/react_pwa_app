export const TEMPLATE = {
  BULK_UPLOAD_TEMPLATE_ONE: 'bulkUploadTemplateOne',
  BULK_UPLOAD_TEMPLATE_TWO: 'bulkUploadTemplateTwo',
  BULK_REQUEST_DETAILS_TEMPLATE: 'bulkRequestDetailsTemplate',
  BULK_RIGHT_MODEL_TEMPLATE: 'bulkRightModalTemplate',
  BULK_BATCH_RECORDS_TEMPLATE: 'bulkBatchRecordsTemplate',
  CKYC_SECTION_TEMPLATE: 'ckycSectionTemplate',
  FINANCIAL_DETAILS_TEMPLATE: 'financialDetailsTemplate',
  CUSTOMER_INFORMATION_TEMPLATE: 'customerInformationTemplate'
}

export const OPERATION_TYPE = {
  BULK: 'BULK'
}

export const sectionType = {
  accordionTab: 'accordionTab',
  accordion: 'accordion'
}
