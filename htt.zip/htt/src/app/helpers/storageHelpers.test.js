import '../../../tests/mocks/localStorage'
import { getLocalStorage, setLocalStorage } from './storageHelpers'

describe('local storage helper', () => {
  afterEach(() => {
    jest.clearAllMocks()
  })

  it('should set value in Async Storage with expiry duration', () => {
    jest.spyOn(localStorage, 'setItem')
    jest.spyOn(Date, 'now').mockImplementation(() => 1583122705421)

    const duration = 10
    const expiryDuration = Math.round(Date.now() / 1000) + duration
    const expected = `Personal Details%expiry%${expiryDuration}`
    setLocalStorage('activeScreen', 'Personal Details', duration)

    // expect(setItemSpy).toHaveBeenCalledTimes(1);
    expect(localStorage.setItem).toHaveBeenCalledWith('activeScreen', expected)
  })

  it('should set value in Async Storage without expiry duration', async () => {
    const expected = 'Personal Details'

    jest.spyOn(localStorage, 'setItem').mockResolvedValue()
    setLocalStorage('activeScreen', 'Personal Details')
    expect(localStorage.setItem).toHaveBeenCalledTimes(1)
    expect(localStorage.setItem).toHaveBeenCalledWith('activeScreen', expected)
  })

  it('should remove value and return null for expired values in localStorage', async () => {
    jest.spyOn(localStorage, 'removeItem')
    const expiryDuration = 1583122700
    const value = `Personal Details%expiry%${expiryDuration}`
    jest.spyOn(localStorage, 'getItem').mockImplementation(() => value)
    // expect(getLocalStorage('activeScreen')).toBeNull();
    // expect(localStorage.removeItem).toHaveBeenCalledTimes(1);
  })

  it('should return localStorage value when expiry is not crossed', async () => {
    jest.spyOn(localStorage, 'removeItem')
    const expiryDuration = 1683122700
    jest.spyOn(Date, 'now').mockImplementation(() => 1583122705421)
    const value = `Personal Details%expiry%${expiryDuration}`
    jest.spyOn(localStorage, 'getItem').mockImplementation(() => value)
    expect(getLocalStorage('activeScreen')).toBe('Personal Details')
    expect(localStorage.removeItem).not.toHaveBeenCalled()
  })

  it('should return localStorage value when no expiry is set', async () => {
    const value = 'Personal Details'
    jest.spyOn(localStorage, 'getItem').mockImplementation(() => value)
    expect(getLocalStorage('activeScreen')).toBe('Personal Details')
  })

  it('should return null when the data is not present in localstorage', async () => {
    jest.spyOn(localStorage, 'getItem').mockImplementation(() => null)
    expect(getLocalStorage('activeScreen')).toBeNull()
  })
})
