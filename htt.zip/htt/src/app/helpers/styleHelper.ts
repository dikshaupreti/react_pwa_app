import { keyframes } from 'styled-components'
import { generateMedia } from 'styled-media-query'
import { breakpoints } from '_ccl'

/*
  Usage

  const Wrapper = styled.div`
    // @media (max-width: 719px)
    ${mediaquery.mobile`
      width: 719px;
    `};
  `;

  const Wrapper = styled.div`
    // @media (min-width: 720px)
    ${mediaquery.tablet`
      width: 720px;
    `};
  `;

  const Wrapper = styled.div`
    // @media (min-width: 1280px)
    ${mediaquery.desktop`
      width: 1280px;
    `};
  `;

  const Wrapper = styled.div`
    // @media (max-width: 1680px)
    ${mediaquery.desktopMax`
      width: 1680px;
    `};
  `;
*/
const mq = generateMedia(breakpoints)

export const mediaquery: any = {}

//  @media (max-width: 719px) { ... }
mediaquery.mobile = mq.lessThan('smallMax')

//  @media (min-width: 720px) { ... }
mediaquery.tablet = mq.greaterThan('medium')

//  @media (min-width: 1280px) { ... }
mediaquery.desktop = mq.greaterThan('large')

//  @media (max-width: 1680px) { ... }
mediaquery.desktopMax = mq.lessThan('largeMax')

export const slideIn = keyframes`
  from {transform:translateX(100%);}
  to {transform:translateX(0%)}
`

export const slideOut = keyframes`
   from {transform:translateX(0%);}
    to {transform:translateX(100%)}
`

export const fadeIn = keyframes`
  from {opacity:0;}
  to {opacity:1;}
`

export const fadeOut = keyframes`
from {opacity:1;}
to {opacity:0;}
`

export const slideInReverse = keyframes`
  from {transform:translateX(-100%);}
  to {transform:translateX(0%)}
`

export const slideOutReverse = keyframes`
   from {transform:translateX(0%);}
    to {transform:translateX(-100%)}
`

const NavLinkWidth = 120
const TabletBreakpoint = parseInt(breakpoints.medium, 10)

export const NavLinkLevels = {
  level1: TabletBreakpoint,
  level2: TabletBreakpoint + NavLinkWidth,
  level3: TabletBreakpoint + 2 * NavLinkWidth,
  level4: TabletBreakpoint + 2.25 * NavLinkWidth,
}

export const PrimaryNavLevels = {
  level1: `${NavLinkLevels.level1}px`,
  level1Max: `${NavLinkLevels.level2 - 1}px`,
  level2: `${NavLinkLevels.level2}px`,
  level2Max: `${NavLinkLevels.level3 - 1}px`,
  level3: `${NavLinkLevels.level3}px`,
  level3Max: `${NavLinkLevels.level4 - 1}px`,
  level4: `${NavLinkLevels.level4}px`,
}

export const PrimaryNavQueries = [
  {
    name: 'isTabletLevel1',
    value: `(min-width: ${PrimaryNavLevels.level1}) and (max-width: ${PrimaryNavLevels.level1Max})`,
  },
  {
    name: 'isTabletLevel2',
    value: `(min-width: ${PrimaryNavLevels.level2}) and (max-width: ${PrimaryNavLevels.level2Max})`,
  },
  {
    name: 'isTabletLevel3',
    value: `(min-width: ${PrimaryNavLevels.level3}) and (max-width: ${PrimaryNavLevels.level3Max})`,
  },
  {
    name: 'isTabletLevel4',
    value: `(min-width: ${PrimaryNavLevels.level4}) and (max-width: ${breakpoints.mediumMax})`,
  },
]

export const getSizeValues = (sizes: any) => sizes.reduce(
  (result: any, size: any) => ({
    ...result,
    [size.name]: window.matchMedia(`only screen and ${size.value}`).matches,
  }),
  {},
)
