const setLocalStorage = (key: any, value:any, durationInSec = 0) => {
  const expiryTime = Math.round(Date.now() / 1000) + durationInSec
  let val = typeof value === 'string' ? value : JSON.stringify(value)
  val = durationInSec === 0 ? val : `${val}%expiry%${expiryTime}`
  localStorage.setItem(key, val)
}

const getLocalStorage = (key: any) => {
  const storedData:any = localStorage.getItem(key)
  let val = storedData
  if (val !== null) {
    const valueFromStorage = storedData.split('%expiry%')
    // eslint-disable-next-line prefer-destructuring
    val = valueFromStorage[0]
    if (valueFromStorage.length === 2 && Date.now() / 1000 > valueFromStorage[1]) {
      localStorage.removeItem(key)
      val = null
    }
  }
  return val
}

export { setLocalStorage, getLocalStorage }
