const downloadFile = (response : any, fileName: any) => {
  const { navigator }: {navigator: any} = window
  if (!navigator.msSaveBlob) {
    const link = document.createElement('a')
    link.href = window.URL.createObjectURL(response.data)
    link.download = fileName
    link.click()
  } else {
    navigator.msSaveBlob(response.data, fileName)
  }
}

export default downloadFile
