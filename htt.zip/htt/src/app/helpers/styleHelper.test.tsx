import React from 'react'
import styled from 'styled-components'
import { breakpoints } from '_ccl'
import { render } from '_jest/CustomRender'
import '../../../tests/mocks/matchMedia'
import { mediaquery } from './styleHelper'

describe.skip('mediaquery', () => {
  let Wrapper : any

  beforeAll(() => {
    Wrapper = styled.div`
        color: red;

        ${mediaquery.mobile`
          color: blue;
        `}

        ${mediaquery.tablet`
          color: yellow;
        `}

        ${mediaquery.desktop`
          color: orange;
        `}

        ${mediaquery.desktopMax`
          color: violet;
        `}
      `
  })

  it('should apply styles for mobile breakpoint', () => {
    const { container } = render(<Wrapper />)

    expect(container.firstChild).toHaveStyleRule('color', 'blue', { media: `(max-width:${breakpoints.smallMax})` })
  })

  it('should apply styles for tablet breakpoint', () => {
    const { container } = render(<Wrapper />)

    expect(container.firstChild).toHaveStyleRule('color', 'yellow', { media: `(min-width:${breakpoints.medium})` })
  })

  it('should apply styles for desktop min', () => {
    const { container } = render(<Wrapper />)

    expect(container.firstChild).toHaveStyleRule('color', 'orange', {
      media: `(min-width:${breakpoints.large})`,
    })
  })

  it('should apply styles for desktop max', () => {
    const { container } = render(<Wrapper />)

    expect(container.firstChild).toHaveStyleRule('color', 'violet', {
      media: `(max-width:${breakpoints.largeMax})`,
    })
  })
})
