import React from 'react'
import { Routes } from 'react-router-dom'
import { render, screen, waitFor } from '_jest/CustomRender'
import Page from './Page'

const mockProps = {
  children: <Routes />
}
jest.useFakeTimers()
describe('Unit testing for <Page> component', () => {
  beforeEach(() => {
    jest.clearAllTimers()
    jest.clearAllMocks()
  })
  it('Page Component Should be defined ', () => {
    expect(

      <Page {...mockProps} />
    ).toBeDefined()
  })
  test('Page Component Should be defined ', async () => {
    render(<Page {...mockProps} />)
    const containerElement = await waitFor(() => screen.getByTestId('container-rendered'))
    expect(containerElement).toBeInTheDocument()
    const wrapperElement = await screen.getByTestId('page-wrapper-rendered')
    expect(wrapperElement).toBeInTheDocument()
  })
})
