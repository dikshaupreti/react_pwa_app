import '@idfc/ccl-web/components/external.css'
import PropTypes from 'prop-types'
import React from 'react'
import { DesktopApplicationGlobalStyles, ScreenSizeProvider } from '_ccl'
import ThemeProvider from '_themes/ThemeProvider'
import allowedFeatureToggles from '../../../config/allowedFeatureToggles.json'
import { FeatureToggle } from './FeatureToggle'

function BasePresentationLayer({ children }) {
  const enabledFeatures = allowedFeatureToggles.features
  return (
    <ThemeProvider>
      <DesktopApplicationGlobalStyles />
      <ScreenSizeProvider>
        <FeatureToggle enabledFeatures={enabledFeatures}>
          {children}
        </FeatureToggle>
      </ScreenSizeProvider>
    </ThemeProvider>
  )
}

BasePresentationLayer.propTypes = {
  children: PropTypes.oneOfType([PropTypes.node, PropTypes.arrayOf(PropTypes.node)]).isRequired,
}

export default BasePresentationLayer
