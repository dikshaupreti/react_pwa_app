import styled from 'styled-components'
import { StyledText } from '_ccl'
import { mediaquery } from '_helpers/styleHelper'
import { OPS_COLOR } from '_styles/colors'
import { CONTAINER_SPACE } from '_styles/margins'

const CommonPageWrapper = styled.div`
  ${mediaquery.tablet`
    padding:24px;
  `}
  ${mediaquery.desktop`
    padding: 36px;
    height: 100%;
    overflow-y: auto;
    flex-grow:1;
  `}
`

const PageWrapper = styled.div`
  padding: 30px;
  flex-grow: 1;
  overflow-y: auto;
  height: 100%;
  font-size: 17px;
  line-height: 24px;
  letter-spacing: -0.6px;
  max-height: 100%;
  
  ${mediaquery.desktop`
    padding: 5px;
    overflow: hidden;
    overflow-y: auto;
    @media (min-width: 1500px) {
      zoom: 0.85;
    }
    @media (min-width: 1700px) {
      zoom: 1;
    }
   `}
   
   
  padding:0;
  color: ${OPS_COLOR.NEW_GREY_800};
`

const Container = styled.div`
  display: flex;
  font-family: 'Inter var', sans-serif;
  color: ${OPS_COLOR.NEW_GREY_800};
  position: fixed;
  left: 0;
  top: 80px;
  height: calc(100% - 80px);
  width: 100%;
  z-index: 10;
`
const CommonTitle = styled(StyledText)`
  padding: 0;
  margin: 0;
  font-size: 26px;
  font-weight: 400;
  line-height: 36px;
  color: ${OPS_COLOR.NEW_GREY_800};
`
const CommonSubTitle = styled(StyledText)`
  padding: 0;
  margin: 0;
  font-size: 21px;
  font-weight: 400;
  color: ${OPS_COLOR.NEW_GREY_800};
  `
const InputWrapper = styled.div`
  input[type='text']::-webkit-input-placeholder {
    font-size: 17px;
    color: ${OPS_COLOR.NEW_GREY_800};
    font-weight: 400;
  }
  ${mediaquery.desktop`
      width: 25%;
      margin-bottom:0px;
    `}
  div {
    margin-top: 0px !important;
  }
  width: 100%;
  margin-bottom: 16px;
    ${mediaquery.desktop`
      margin-bottom:0;
    `}
`
const WrapperAcc = styled.div``

const AccrodianChildWrap = styled.div`
  .primary-nav-tabs-content > div > span{
    padding-top:0px;
  }
`
const AccordionWrapper = styled.div`
  width: 100%;
  > div {
    margin-bottom:1px;
  }
  .accordion__panel{
  background-color: ${OPS_COLOR.NEW_WHITE_100};
  }
  .primary-nav-tabs-content{
    height: fit-content;
  }
}`
const BOX_SHADOW = {
  value: '0px 4px 8px #25243b0d',
}
export const ARROW_SHADOW = {
  value: '-1px 3px 3px -1px #05050533',
}

export const ViewWrapper = styled.div`
  display: flex;
  height: 100%;
  position: relative;
  ${mediaquery.tablet`
    width:100%;
    align-items: start;
    justify-content: flex-start;
    margin:0px 0px 0px ${CONTAINER_SPACE.SPACING_8}px;
  `}
  ${mediaquery.desktop`
    width:25%;
    margin-right: ${CONTAINER_SPACE.SPACING_24}px;
    margin-left: auto;
    justify-content: flex-end;
    align-items: center;
  `}
`
export const RightAlign = styled.div`
  display: flex;
  justify-content: flex-end;
  align-items: center;
  WIDTH:100%
`

export {
  CommonPageWrapper, PageWrapper, Container, CommonTitle, InputWrapper, CommonSubTitle, WrapperAcc, AccrodianChildWrap, AccordionWrapper, BOX_SHADOW,
}

