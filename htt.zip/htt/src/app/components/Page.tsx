import React, { lazy } from 'react'
import { OpsProvider } from '_context/OpsProvider'
import { renderChildren } from '_modules/renderChildren'
import { ReactChildren } from '_modules/types/common'
import { Container, PageWrapper } from './CommonStyle.styles'

const LeftNavBar = lazy(
  () => import('_components/LeftNavBar').then((module) => ({ default: module.LeftNavBar }))
)
const Header = lazy(
  () => import('./Header').then((module) => ({ default: module.Header }))
)
interface IStandardPage {
    children: ReactChildren
}
function Page(props: IStandardPage) {
  const { children } = props
  return (
    <>
      <Header />
      <Container data-testid="container-rendered">
        <OpsProvider>
          <LeftNavBar />
          <PageWrapper data-testid="page-wrapper-rendered">{renderChildren(children)}</PageWrapper>
        </OpsProvider>
      </Container>
    </>
  )
}


export default Page
