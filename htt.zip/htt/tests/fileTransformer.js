const path = require('path');

module.exports = {
  process(src, filename) {
    if (filename.startsWith('@idfc')) {
      return src;
    }

    return `module.exports = ${JSON.stringify(path.basename(filename))};`;
  },
};
