/* eslint-disable import/no-extraneous-dependencies */
const path = require('path');
const { transform } = require('@babel/core');
const jestPreset = require('babel-preset-jest');

module.exports = {
  process(src, filename) {
    if (filename.includes('@idfc/ccl-commons/assets/logos/')) {
      const SvgComponentName = path.parse(filename).name;
      const MockSVGComponent = `
        const React = require('react');
        module.exports = function ${SvgComponentName} (props) {
          return <svg data-component={${JSON.stringify(SvgComponentName)}} {...props} />;
        };
      `;

      const result = transform(MockSVGComponent, {
        filename,
        presets: [jestPreset],
      });

      return result;
    }

    if (filename.startsWith('@idfc')) {
      return src;
    }

    return `module.exports = ${JSON.stringify(path.basename(filename))};`;
  },
};
