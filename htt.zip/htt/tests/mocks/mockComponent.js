/* eslint-disable react/prop-types, no-unused-vars, react/button-has-type */
import React from 'react';

export function MockProcessStatus({ variant, brandHeroSize, ...rest }) {
  return (
    <div
      data-variant={variant}
      data-brand-hero-size={brandHeroSize}
      {...rest}
    />
  )
}

export function MockIcon({
  size, title, primaryColor, accentColor, name, ...rest
}) {
  return (
    <svg
      width={size}
      height={size}
      aria-hidden={title}
      aria-label={title || name}
      data-primary-color={primaryColor}
      data-accent-color={accentColor}
      role="img"
      data-name={name}
      data-component="Icon"
      data-testid={rest['data-testid'] || `Icon${name}`}
      {...rest}
    />
  )
}

export function MockBrandHero({ animationData, size, ...rest }) {
  return (
    <svg
      width={size}
      height={size}
      data-testid={rest['brand-hero-id']}
      {...rest}
    />
  )
}

export function MockIconButton({
  buttonType = 'primary',
  buttonSize = 'default',
  label,
  isInline,
  iconName,
  transparent,
  iconSize,
  disabled,
  children,
  labelColor = 'gray',
  fontWeight = 'normal',
  iconColor,
  iconText,
  accessibilityText,
  accentColor,
  disabledIconColor,
  labelFontSize,
  iconStyle,
  onClick,
  style,
  ...rest
}) {
  return (
    <button
      data-component="IconButton"
      data-transparent={transparent}
      aria-label={label || accessibilityText || iconName}
      data-button-type={buttonType}
      data-is-inline={isInline}
      data-button-size={buttonSize}
      data-icon-size={iconSize}
      disabled={disabled}
      data-accessibility-text={accessibilityText}
      data-testid={rest['data-testid'] || 'IconButton'}
      onClick={onClick}
      style={style}
      {...rest}
    >
      <span>
        <MockIcon
          name={iconName}
          size={iconSize}
          title={label}
        />
        {children || label}
      </span>
    </button>
  )
}
