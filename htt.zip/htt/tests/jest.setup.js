import '@testing-library/jest-dom/extend-expect'

import 'jest-styled-components'

import 'jest-canvas-mock'

import './mocks/matchMedia'

import {
  MockBrandHero, MockIcon, MockIconButton, MockProcessStatus
} from './mocks/mockComponent'

jest.mock('@idfc/ccl-web/components/ProcessStatus', () => MockProcessStatus)

jest.mock('@idfc/ccl-web/components/Icon', () => MockIcon)

jest.mock('@idfc/ccl-web/components/BrandHero', () => MockBrandHero)

jest.mock('@idfc/ccl-web/components/IconButton', () => MockIconButton)

jest.mock('@idfc/ccl-web/components/Avatar', () => MockIconButton)

// TODO : Handle NavigationHeader Header.js for eliminating <LogoFull.svg /> is using incorrect casing.-
// -Use PascalCase for React components, or lowercase for HTML elements.
