module.exports = (globalConfig) => {
  process.env.TZ = 'Asia/Kolkata';
  process.env.NODE_ICU_DATA = 'node_modules/full-icu';

  process.on('unhandledRejection', (err) => {
    console.error(err);
    process.exit(1);
  });
};
