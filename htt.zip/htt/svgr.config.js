module.exports = {
  icon: true,
  svgo: false,
};
