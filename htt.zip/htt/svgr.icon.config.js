// Value of palette.ICON_DEFAULT_PRIMARY_COLOR
// (for some reason requiring palette doesn't work here)
const ICON_DEFAULT_PRIMARY_COLOR = '#787878';
const ICON_DEFAULT_ACCENT_COLOR = '#ffcb05';

const componentTemplate = (
  { template },
  opts,
  // eslint-disable-next-line no-unused-vars
  { imports, componentName, props, jsx, exports }
) => template.ast`
  import * as React from 'react';
  import PropTypes from 'prop-types';

  const ${componentName} = ({ primaryColor, accentColor, ...props }) => ${jsx}

  ${componentName}.propTypes = {
    primaryColor: PropTypes.string,
    accentColor: PropTypes.string,
  };

  ${componentName}.defaultProps = {
    primaryColor: '${ICON_DEFAULT_PRIMARY_COLOR}',
  };

  ${exports};
`;

module.exports = {
  icon: true,
  replaceAttrValues: {
    [ICON_DEFAULT_PRIMARY_COLOR.toLowerCase()]: '{primaryColor}',
    [ICON_DEFAULT_PRIMARY_COLOR.toUpperCase()]: '{primaryColor}',
    [ICON_DEFAULT_ACCENT_COLOR.toLowerCase()]: '{accentColor}',
    [ICON_DEFAULT_ACCENT_COLOR.toUpperCase()]: '{accentColor}',
  },
  template: componentTemplate,
};
