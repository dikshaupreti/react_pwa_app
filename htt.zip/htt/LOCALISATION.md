React multi language methods
-> Constant changes
* Store all constants in a single file with different JS Objects; eg: 
    * englishConst = {const1: val1, const2: val2...}
    * hindiConst = {const1: वैल्चू1, const2: वैल्चू2…}
* Then using a hook like useLanguage to set applicationWide language:
    * const [constant, setConstant] = useState(englishConst) // Can be changed as per location
    * return {constant, setConstant}
* Use setConstant anywhere to change the language from english to hindi as setConstant({…constant, …hindiConstant}) // Spread being used to ensure that if a certain constant does not exist in hindiConstant declaration, it will render its English counterpart.
* Extract constant from useLanguage hook across all all components and hooks and use the values as constant.const1 or constant.const2
* Drawbacks:
    * Need to create constants for all languages, including future languages - needs to be re-written always
    * Heavily dependant on BE as API need to send data in the set language.
    * Needs entire constant object in the memory; thus space complex
* Advantages:
    * No third party dependancy
    * All constant can be stored at a single place, hence, constant redundancy can also be avoided.
* Guidelines with this approach
    * Constant in the object should be declared in alphabetical order to avoid redundant constants.
    * There should be a single object for a language, if needed, other groups can be made as follows:
        * englishConst = {const1: val1, const2: {const3: val2, const4: val3}} 
* Alternate approach involving constant changes - Declare the constants for different languages in the current constant files as follows:
    * const MAKER_CHECKER_STRING = {english:  ‘Maker Checker’, hindi: ‘मॆकर चॆकर’}
    * Then use the existing const changes as MAKER_CHECKER_STRING[setLanguage] // setLanguage can be a context
    * This approach will not be able to completely eradicate constant redundancy and will involve a lot of files, thus making it hard to keep a track of all constants for all languages.

->  react-i18next
* I18next is a popular third party, crowd maintained open source localisation library; react-i18next is an extension used for react applications
* https://locize.com/blog/react-i18next/ for complete beginner doc on using this library
* Drawbacks:
    * Third party implementation
    * Need to still declare all the constants in all the languages
* Advantages:
    * Big user-base
    * Considers things like pluralisation and also allows styling of particular constants
* YT Tutorial Link: https://www.youtube.com/watch?v=kGFEvphB5G0
* Note: This library can support automatic translation through some workarounds but are usually not very accurate

-> react-auto-translate
* Uses google translate APIs to translate.
* https://www.npmjs.com/package/react-auto-translate
* Drawbacks: 
    * Real time translations may not be 100% accurate
    * Third party implementation. Not as popular either
* Advantages
    * No need to declare translations or constant file on our own
    * Not dependant on BE.
